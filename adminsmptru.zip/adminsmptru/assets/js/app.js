document.addEventListener('DOMContentLoaded', function(){
  // Convert table headers into data-labels for the mobile card layout.
  document.querySelectorAll('.table-wrap table').forEach(function(table){
    const headers = Array.from(table.querySelectorAll('thead th')).map(function(th){
      return (th.textContent || '').replace(/\s+/g,' ').trim();
    });
    if(!headers.length) return;
    table.querySelectorAll('tbody tr').forEach(function(row){
      Array.from(row.children).forEach(function(cell, index){
        if(cell.tagName !== 'TD') return;
        if(!cell.hasAttribute('data-label')){
          cell.setAttribute('data-label', headers[index] || 'Data');
        }
      });
    });
  });
});
