<?php
if (!defined('APP_NAME')) define('APP_NAME', 'ADMIN SMPTRU');
if (!defined('APP_SLOGAN')) define('APP_SLOGAN', 'Mie Pedas No. 1 di Indonesia');
