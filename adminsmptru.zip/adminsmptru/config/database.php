<?php
// Konfigurasi default XAMPP. Ubah sesuai hosting/server Anda.
$host = getenv('SMPTRU_DB_HOST') ?: 'localhost';
$user = getenv('SMPTRU_DB_USER') ?: 'root';
$pass = getenv('SMPTRU_DB_PASS') ?: '';
$db   = getenv('SMPTRU_DB_NAME') ?: 'adminsmptru';

$conn = @new mysqli($host, $user, $pass, $db);
$db_error = $conn->connect_errno ? $conn->connect_error : null;

if (!$conn->connect_errno) {
    $conn->set_charset('utf8mb4');
}

function db_ready(): bool
{
    global $conn;
    return isset($conn) && $conn instanceof mysqli && !$conn->connect_errno;
}

function db_error_message(): string
{
    global $db_error;
    return $db_error ? (string)$db_error : '';
}
