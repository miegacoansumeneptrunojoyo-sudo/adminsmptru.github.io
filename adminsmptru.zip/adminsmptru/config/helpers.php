<?php
function e($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function redirect_to(string $location): void
{
    header('Location: ' . $location);
    exit;
}

function flash_message(string $type, string $message): string
{
    $class = $type === 'success' ? 'alert-success' : 'alert-error';
    return '<div class="alert '.$class.'">'.e($message).'</div>';
}
