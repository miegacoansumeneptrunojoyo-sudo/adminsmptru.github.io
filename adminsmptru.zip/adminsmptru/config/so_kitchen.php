<?php
/**
 * Master definition SO Kitchen.
 * Sumber daftar barang mengikuti form yang dikirim user.
 */

function so_kitchen_stations(): array
{
    return [
        'kasir' => [
            'name' => 'Kasir',
            'icon' => '🧾',
            'description' => 'Stock kebutuhan kasir',
            'columns' => ['pcs_gram', 'pack'],
            'items' => [
                'KERTAS THERMAL PRINTER',
            ],
        ],
        'noodle' => [
            'name' => 'Noodle',
            'icon' => '🍜',
            'description' => 'Stock kebutuhan noodle',
            'columns' => ['pcs_gram', 'pack'],
            'items' => [
                'CABE RAWIT',
                'MIE',
                'KECAP',
                'BASIC MIE',
                'AYAM CINCANG',
                'BAWANG GORENG',
                'MINYAK MIE',
                'PANGSIT GORENG',
                'DAUN BAWANG',
                'KERUPUK',
                'FOAM MIE',
            ],
        ],
        'presenter' => [
            'name' => 'Presenter',
            'icon' => '🧑‍🍳',
            'description' => 'Stock kebutuhan presenter',
            'columns' => ['pcs_gram', 'pack'],
            'items' => [
                'SEDOTAN BUBBLE',
                'SEDOTAN HITAM',
                'SENDOK PLASTIK',
                'SUMPIT',
                'KERTAS BAKPAO',
                'KRESEK KECIL',
                'KRESEK SEDANG',
                'KRESEK BESAR',
                'KRESEK JUMBO',
                'DIPPING FINNA',
                'KARET',
                'PLASTIK 1/2 KG',
                'HANDGLOVE PLASTIK',
                'HANDGLOVE KARET',
            ],
        ],
        'dimsum' => [
            'name' => 'Dimsum',
            'icon' => '🥟',
            'description' => 'Stock kebutuhan dimsum',
            'columns' => ['pcs_gram', 'pack'],
            'items' => [
                'PENTOLAN',
                'UDANG KEJU',
                'UDANG RAMBUTAN',
                'SURAI',
                'KEJU',
                'TEPUNG PANIR',
                'SIOMAY',
                'BATTER',
                'LUMPIA UDANG',
                'MINYAK GORENG',
                'FOAM DIMSUM',
            ],
        ],
        'bar' => [
            'name' => 'Bar',
            'icon' => '🥤',
            'description' => 'Stock kebutuhan bar',
            'columns' => ['pcs_gram', 'pack', 'biang'],
            'items' => [
                'AIR MINERAL',
                'LEMON TEA',
                'ORANGE',
                'SIRUP LECHY',
                'SIRUP MOCCA',
                'SIRUP ROSE',
                'SUNQUICK',
                'TEA TARIK',
                'VANILLA LATTE',
                'SUSU KENTAL MANIS (SKM)',
                'SUSU UHT',
                'BUAH APEL',
                'BUAH BELIMBING',
                'BUAH PEER',
                'BUAH STRAWBERRY',
                'CINCAU',
                'JELLY BUBBLE',
                'JELLY MIE',
                'NATA DE COCO',
                'BLACK THAI TEA',
                'CREAMER',
                'GREEN THAI TEA',
                'MILO/COKLAT',
                'EVAPORASI',
                'JERUK NIPIS',
                'GULA',
                'TEA GOPEK',
                'TEA NAGA',
                'GALON',
                'ES TUBE',
                'CUP 12',
                'CUP 14',
                'CUP 16',
                'CUP SEALER',
                'CUP SEALER',
            ],
        ],
        'produksi' => [
            'name' => 'Produksi',
            'icon' => '🏭',
            'description' => 'Stock dan proses produksi',
            'columns' => ['pcs_gram', 'pack', 'ball'],
            'items' => [
                'ADONAN PANGSIT',
                'CABE UTUH',
                'AYAM CINCANG',
                'KULIT PANGSIT',
                'KERUPUK MIE MENTAH',
                'MINYAK GORENG',
                'LPG',
            ],
            'has_process' => true,
        ],
    ];
}

function so_kitchen_station(string $key): ?array
{
    $stations = so_kitchen_stations();
    return $stations[$key] ?? null;
}

function so_kitchen_columns(array $station): array
{
    $map = [
        'pcs_gram' => 'Pcs/Gram',
        'pack' => 'Pack',
        'ball' => 'Ball',
        'biang' => 'Biang',
    ];
    $columns = [];
    foreach ($station['columns'] as $column) {
        $columns[$column] = $map[$column];
    }
    return $columns;
}

function so_harian_date(?string $value = null): string
{
    if ($value && preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
        return $value;
    }
    return date('Y-m-d');
}

function so_display_number($value): string
{
    if ($value === null || $value === '') {
        return '';
    }
    $number = (float)$value;
    if ((int)$number == $number) {
        return (string)(int)$number;
    }
    return rtrim(rtrim(number_format($number, 2, ',', '.'), '0'), ',');
}

function so_input_value($value): string
{
    if ($value === null || $value === '') {
        return '';
    }
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
