</div>
</main>
</div>
<script src="<?=($assetBase ?? '')?>assets/js/app.js"></script>
</body>
</html>
