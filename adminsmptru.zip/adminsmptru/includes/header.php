<?php
require_once __DIR__ . '/../config.php';
if (!isset($pageTitle)) $pageTitle = 'Admin SMPTRU';
$script = str_replace('\\', '/', parse_url($_SERVER['SCRIPT_NAME'] ?? '', PHP_URL_PATH) ?: '');
$projectRoot = basename(dirname(__DIR__));
$needle = '/' . $projectRoot . '/';
$relativeScript = $script;
if (($pos = strpos($script, $needle)) !== false) {
    $relativeScript = substr($script, $pos + strlen($needle));
} else {
    $relativeScript = ltrim($script, '/');
}
$relativeDir = dirname($relativeScript);
$assetBase = '';
if ($relativeDir !== '.' && $relativeDir !== '') {
    $segments = array_values(array_filter(explode('/', str_replace('\\', '/', $relativeDir)), static fn($v) => $v !== ''));
    $assetBase = str_repeat('../', count($segments));
}
$path = strtolower($script);
$isStocker = basename($script) === 'stocker.php' || str_contains($path, '/stocker/');
$isQC = basename($script) === 'qualitycontrol.php' || str_contains($path, '/quality_control/');
$isSOKitchen = basename($script) === 'sokitchen.php' || str_contains($path, '/so_kitchen/');
$isSOHarian = basename($script) === 'soharian.php' || str_contains($path, '/so_harian/');
$isDashboard = basename($script) === 'index.php';
$isSubPage = str_contains($path, '/stocker/') || str_contains($path, '/quality_control/') || str_contains($path, '/so_kitchen/') || str_contains($path, '/so_harian/');
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=htmlspecialchars($pageTitle)?> - Admin SMPTRU</title>
<link rel="stylesheet" href="<?=$assetBase?>assets/css/style.css">
</head>
<body>
<div class="app-shell">
  <aside class="sidebar">
    <div class="brand">SMPTRU<small>SUMENEP TRUNOJOYO</small></div>
    <nav>
      <a class="<?= $isDashboard ? 'active' : '' ?>" href="<?=$assetBase?>index.php">⌂ <span>Dashboard</span></a>
      <a class="<?= $isStocker ? 'active' : '' ?>" href="<?=$assetBase?>stocker.php">▣ <span>Stocker</span></a>
      <a class="<?= $isQC ? 'active' : '' ?>" href="<?=$assetBase?>qualitycontrol.php">✓ <span>Quality Control</span></a>
      <a class="<?= $isSOKitchen ? 'active' : '' ?>" href="<?=$assetBase?>sokitchen.php">♨ <span>SO Kitchen</span></a>
      <a class="<?= $isSOHarian ? 'active' : '' ?>" href="<?=$assetBase?>soharian.php">📋 <span>SO Harian</span></a>
    </nav>
    <div class="sidebar-slogan">Mie Pedas<br><strong>No. 1 di Indonesia</strong></div>
  </aside>
  <main class="main">
    <header class="topbar">
      <button class="hamburger" onclick="document.body.classList.toggle('menu-open')">☰</button>
      <div class="search">⌕ <input placeholder="Cari menu atau data..."></div>
      <div class="top-actions"><span>🔔</span><span class="avatar">A</span><span class="admin-name">Admin</span></div>
    </header>
    <div class="content">
