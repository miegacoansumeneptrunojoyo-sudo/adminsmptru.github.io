<?php
$pageTitle = 'Dashboard';
require __DIR__.'/includes/header.php';
?>
<section class="hero">
  <div class="hero-copy">
    <span class="eyebrow">SUMENEP TRUNOJOYO</span>
    <h1>ADMIN SMPTRU</h1>
    <p>Sistem Administrasi Operasional</p>
    <span class="pill pink">Mie Pedas No. 1 di Indonesia</span>
  </div>
  <div class="hero-quote">Mie Pedas<br><strong>No. 1 di Indonesia</strong></div>
</section>
<section class="cards grid4">
  <a class="menu-card blue" href="stocker.php"><span class="icon">▣</span><div><h3>STOCKER</h3><p>Kelola data stocker dengan lebih mudah</p><span class="count">4 Menu</span></div><span class="arrow">›</span></a>
  <a class="menu-card pink" href="qualitycontrol.php"><span class="icon">✓</span><div><h3>QUALITY CONTROL</h3><p>Pastikan kualitas selalu terjaga</p><span class="count">7 Menu</span></div><span class="arrow">›</span></a>
  <a class="menu-card blue" href="sokitchen.php"><span class="icon">♨</span><div><h3>SO KITCHEN</h3><p>Monitoring stock setiap station</p><span class="count">6 Menu</span></div><span class="arrow">›</span></a>
  <a class="menu-card pink" href="soharian.php"><span class="icon">📋</span><div><h3>SO HARIAN</h3><p>Kelola stock opname harian dengan mudah</p><span class="count">6 Station</span></div><span class="arrow">›</span></a>
</section>
<?php require __DIR__.'/includes/footer.php'; ?>
