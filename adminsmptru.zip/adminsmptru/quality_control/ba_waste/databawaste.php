<?php
$pageTitle = 'Data BA Waste';
require_once __DIR__ . '/../../config.php';
$pdo = db();

$pdo->exec("CREATE TABLE IF NOT EXISTS `ba_waste` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `tanggal` DATE NOT NULL,
  `resto` VARCHAR(180) NOT NULL DEFAULT 'Sumenep Trunojoyo',
  `quality_control` VARCHAR(50) NOT NULL DEFAULT 'Atika',
  `nama_barang` VARCHAR(180) NOT NULL,
  `waste_gram` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `timbangan_foto` VARCHAR(255) NOT NULL,
  `kronologi_waste` TEXT NOT NULL,
  `pemusnahan_foto` VARCHAR(255) NOT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_ba_waste_tanggal` (`tanggal`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$cols = $pdo->query("SHOW COLUMNS FROM `ba_waste`")->fetchAll();
$existing = [];
foreach ($cols as $c) $existing[$c['Field']] = true;
$alter = [];
if (!isset($existing['resto'])) $alter[] = "ADD COLUMN `resto` VARCHAR(180) NOT NULL DEFAULT 'Sumenep Trunojoyo' AFTER `tanggal`";
if (!isset($existing['quality_control'])) $alter[] = "ADD COLUMN `quality_control` VARCHAR(50) NOT NULL DEFAULT 'Atika' AFTER `resto`";
if (!isset($existing['updated_at'])) $alter[] = "ADD COLUMN `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`";
if ($alter) $pdo->exec('ALTER TABLE `ba_waste` ' . implode(', ', $alter));

$today = date('Y-m-d');
$selectedDate = (string)($_GET['tanggal'] ?? $today);
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate)) $selectedDate = $today;
$stmt = $pdo->prepare("SELECT id,nama_barang,waste_gram,kronologi_waste,timbangan_foto,pemusnahan_foto,resto,quality_control FROM ba_waste WHERE tanggal=? ORDER BY id DESC");
$stmt->execute([$selectedDate]);
$rows = $stmt->fetchAll();
require __DIR__ . '/../../includes/header.php';
?>
<style>
  .qc-data-page {
    max-width: 1500px;
    margin: 0 auto
  }

  .qc-data-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 14px;
    margin-bottom: 18px
  }

  .qc-data-head h2 {
    margin: 0;
    color: #123f78;
    font-size: 28px;
    font-weight: 900
  }

  .qc-data-actions {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap
  }

  .qc-date-label {
    font-size: 13px;
    font-weight: 800;
    color: #365171;
    display: flex;
    align-items: center;
    gap: 8px
  }

  .qc-date-label input {
    height: 42px;
    border: 1.5px solid #d0deed;
    border-radius: 11px;
    background: #fff;
    padding: 0 12px;
    color: #203c60;
    outline: none
  }

  .qc-date-label input:focus {
    border-color: #2180ef;
    box-shadow: 0 0 0 3px rgba(33, 128, 239, .1)
  }

  .qc-btn {
    min-height: 42px;
    padding: 10px 15px;
    border-radius: 11px;
    border: 1px solid #d7e3f4;
    background: #fff;
    color: #2454a5;
    font-weight: 800;
    font-size: 13px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer
  }

  .qc-btn.primary {
    border-color: transparent;
    background: linear-gradient(90deg, #2563eb, #ec4899);
    color: #fff
  }

  .qc-btn.back {
    background: #f6f9ff;
    color: #31577f
  }

  .qc-empty {
    background: #fff;
    border: 1px solid #e5ebf5;
    border-radius: 20px;
    min-height: 190px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    box-shadow: 0 8px 20px rgba(38, 66, 116, .06)
  }

  .qc-empty h3 {
    margin: 0 0 8px;
    color: #123f78
  }

  .qc-empty p {
    margin: 0;
    color: #71839d
  }

  .qc-data-card {
    background: #fff;
    border: 1px solid #e5ebf5;
    border-radius: 20px;
    box-shadow: 0 8px 22px rgba(38, 66, 116, .06);
    overflow: hidden
  }

  .qc-table-wrap {
    width: 100%;
    overflow: auto
  }

  .qc-table {
    width: 100%;
    border-collapse: collapse;
    min-width: 980px
  }

  .qc-table th,
  .qc-table td {
    padding: 13px 12px;
    border-bottom: 1px solid #edf1f7;
    font-size: 13px;
    vertical-align: top
  }

  .qc-table th {
    background: #f8fbff;
    color: #56708f;
    font-size: 12px;
    text-transform: uppercase;
    letter-spacing: .25px;
    text-align: center
  }

  .qc-table td:nth-child(1),
  .qc-table td:nth-child(3) {
    text-align: center
  }

  .qc-table tbody tr:hover td {
    background: #fbfdff
  }

  .qc-photo {
    width: 78px;
    height: 62px;
    object-fit: cover;
    border-radius: 10px;
    border: 1px solid #dbe7f4;
    display: block;
    margin: 0 auto 5px
  }

  .qc-photo-link {
    display: inline-flex;
    font-size: 11px;
    color: #2563eb;
    font-weight: 800
  }

  .qc-actions {
    display: flex;
    gap: 7px;
    flex-wrap: wrap
  }

  .qc-no {
    display: inline-grid;
    place-items: center;
    width: 30px;
    height: 30px;
    border-radius: 9px;
    background: #eaf4ff;
    color: #176fd8;
    font-weight: 900
  }

  .qc-muted {
    color: #71839d
  }

  .qc-krono {
    white-space: pre-wrap;
    max-width: 430px;
    line-height: 1.5
  }

  .qc-meta {
    font-size: 11px;
    color: #8292a8;
    margin-top: 3px
  }

  @media(max-width:760px) {
    .qc-data-head {
      align-items: flex-start;
      flex-direction: column
    }

    .qc-data-actions {
      width: 100%;
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px
    }

    .qc-data-actions .qc-btn {
      width: 100%
    }

    .qc-date-label {
      grid-column: 1/-1;
      justify-content: space-between
    }

    .qc-date-label input {
      flex: 1
    }

    .qc-table {
      min-width: 0
    }

    .qc-table thead {
      display: none
    }

    .qc-table,
    .qc-table tbody,
    .qc-table tr,
    .qc-table td {
      display: block;
      width: 100%
    }

    .qc-table tbody tr {
      border: 1px solid #e3ebf5;
      border-radius: 16px;
      margin-bottom: 12px;
      padding: 8px 12px;
      background: #fff
    }

    .qc-table td {
      display: grid;
      grid-template-columns: 110px minmax(0, 1fr);
      gap: 10px;
      padding: 10px 0;
      border-bottom: 1px dashed #e6edf5
    }

    .qc-table td:last-child {
      border-bottom: 0
    }

    .qc-table td::before {
      content: attr(data-label);
      font-weight: 800;
      color: #68809c
    }

    .qc-table td:nth-child(1) {
      text-align: left
    }

    .qc-table td:nth-child(3) {
      text-align: left
    }

    .qc-photo {
      margin: 0
    }

    .qc-krono {
      max-width: none
    }

    .qc-actions {
      justify-content: flex-start
    }
  }
</style>
<div class="qc-data-page">
  <div class="qc-data-head">
    <h2>Data BA Waste</h2>
    <div class="qc-data-actions">
      <a class="qc-btn back" href="../../qualitycontrol.php">← Kembali</a>
      <label class="qc-date-label"><input type="date" id="tanggal" value="<?= e($selectedDate) ?>"></label>
      <button class="qc-btn primary" type="button" id="showBtn">Tampilkan</button>
      <a class="qc-btn primary" href="inputbawaste.php">＋ Input Data</a>
    </div>
  </div>
  <?php if (!$rows): ?>
    <section class="qc-empty">
      <div>
        <h3>Belum ada data BA Waste</h3>
      </div>
    </section>
  <?php else: ?>
    <section class="qc-data-card">
      <div class="qc-table-wrap">
        <table class="qc-table">
          <thead>
            <tr>
              <th>No</th>
              <th>Nama Barang</th>
              <th>Waste (Gram)</th>
              <th>Kronologi Waste</th>
              <th>Timbangan</th>
              <th>Pemusnahan</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($rows as $i => $r): ?>
              <tr>
                <td data-label="No"><span class="qc-no"><?= e($i + 1) ?></span></td>
                <td data-label="Nama Barang"><strong><?= e($r['nama_barang']) ?></strong>
                  <div class="qc-meta"><?= e($r['quality_control']) ?></div>
                </td>
                <td data-label="Waste (Gram)"><?= e(number_format((float)$r['waste_gram'], 2, ',', '.')) ?></td>
                <td data-label="Kronologi Waste" class="qc-krono"><?= e($r['kronologi_waste']) ?></td>
                <td data-label="Timbangan"><?php if ($r['timbangan_foto']): ?><a href="../../<?= e($r['timbangan_foto']) ?>" target="_blank" rel="noopener"><img class="qc-photo" src="../../<?= e($r['timbangan_foto']) ?>" alt="Timbangan"><span class="qc-photo-link">Lihat Foto</span></a><?php else: ?><span class="qc-muted">—</span><?php endif; ?></td>
                <td data-label="Pemusnahan"><?php if ($r['pemusnahan_foto']): ?><a href="../../<?= e($r['pemusnahan_foto']) ?>" target="_blank" rel="noopener"><img class="qc-photo" src="../../<?= e($r['pemusnahan_foto']) ?>" alt="Pemusnahan"><span class="qc-photo-link">Lihat Foto</span></a><?php else: ?><span class="qc-muted">—</span><?php endif; ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </section>
  <?php endif; ?>
</div>
<script>
  document.getElementById('showBtn').addEventListener('click', function() {
    const d = document.getElementById('tanggal').value;
    if (d) location.href = 'databawaste.php?tanggal=' + encodeURIComponent(d);
  });
</script>
<?php require __DIR__ . '/../../includes/footer.php'; ?>