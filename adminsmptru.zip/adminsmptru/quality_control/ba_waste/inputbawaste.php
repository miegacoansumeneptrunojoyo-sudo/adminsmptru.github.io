<?php
$pageTitle = 'Input BA Waste';
require_once __DIR__ . '/../../config.php';

define('BA_WASTE_DIR', UPLOAD_DIR . 'ba_waste/');


function ensure_ba_waste_schema(PDO $pdo): void
{
    $pdo->exec("CREATE TABLE IF NOT EXISTS `ba_waste` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `tanggal` DATE NOT NULL,
        `resto` VARCHAR(180) NOT NULL DEFAULT 'Sumenep Trunojoyo',
        `quality_control` ENUM('Atika','Ega','Luluk') NOT NULL,
        `nama_barang` VARCHAR(180) NOT NULL,
        `waste_gram` DECIMAL(12,2) NOT NULL DEFAULT 0,
        `timbangan_foto` VARCHAR(255) NOT NULL,
        `kronologi_waste` TEXT NOT NULL,
        `pemusnahan_foto` VARCHAR(255) NOT NULL,
        `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `idx_ba_waste_tanggal` (`tanggal`),
        KEY `idx_ba_waste_barang` (`nama_barang`),
        KEY `idx_ba_waste_qc` (`quality_control`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $cols = $pdo->query("SHOW COLUMNS FROM `ba_waste`")->fetchAll();
    $existing = [];
    foreach ($cols as $c) $existing[$c['Field']] = true;
    $alter = [];
    if (!isset($existing['resto'])) $alter[] = "ADD COLUMN `resto` VARCHAR(180) NOT NULL DEFAULT 'Sumenep Trunojoyo' AFTER `tanggal`";
    if (!isset($existing['quality_control'])) $alter[] = "ADD COLUMN `quality_control` VARCHAR(50) NOT NULL DEFAULT 'Atika' AFTER `resto`";
    if (!isset($existing['updated_at'])) $alter[] = "ADD COLUMN `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`";
    if ($alter) $pdo->exec('ALTER TABLE `ba_waste` ' . implode(', ', $alter));
}

function upload_ba_waste_photo(array $file, string $prefix): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Foto wajib diupload.');
    }
    if (($file['size'] ?? 0) > MAX_FILE_SIZE) {
        throw new RuntimeException('Ukuran foto maksimal 5 MB.');
    }
    $tmp = (string)($file['tmp_name'] ?? '');
    if (!is_uploaded_file($tmp)) throw new RuntimeException('File upload tidak valid.');
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmp);
    $ext = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$mime] ?? null;
    if ($ext === null) throw new RuntimeException('Format foto harus JPG, PNG, atau WEBP.');

    if (!is_dir(BA_WASTE_DIR) && !mkdir(BA_WASTE_DIR, 0775, true) && !is_dir(BA_WASTE_DIR)) {
        throw new RuntimeException('Folder upload tidak dapat dibuat.');
    }
    $name = $prefix . '_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    if (!move_uploaded_file($tmp, BA_WASTE_DIR . $name)) throw new RuntimeException('Foto gagal disimpan.');
    return 'uploads/ba_waste/' . $name;
}

$pdo = db();
ensure_ba_waste_schema($pdo);
$today = date('Y-m-d');
$error = '';
$qcOptions = ['Atika','Ega','Luluk'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        check_csrf();
        $tanggal = $today;
        $resto = 'Sumenep Trunojoyo';
        $qc = trim((string)($_POST['quality_control'] ?? ''));
        $namaBarang = trim((string)($_POST['nama_barang'] ?? ''));
        $wasteGram = trim((string)($_POST['waste_gram'] ?? ''));
        $kronologi = trim((string)($_POST['kronologi_waste'] ?? ''));

        if (!in_array($qc, $qcOptions, true)) throw new RuntimeException('Quality Control wajib dipilih.');
        if ($namaBarang === '') throw new RuntimeException('Nama Barang wajib diisi.');
        if ($wasteGram === '' || !is_numeric($wasteGram) || (float)$wasteGram < 0) throw new RuntimeException('Waste (Gram) harus berupa angka 0 atau lebih.');
        if ($kronologi === '') throw new RuntimeException('Kronologi Waste wajib diisi.');

        $timbangan = upload_ba_waste_photo($_FILES['timbangan_foto'] ?? [], 'timbangan');
        try {
            $pemusnahan = upload_ba_waste_photo($_FILES['pemusnahan_foto'] ?? [], 'pemusnahan');
        } catch (Throwable $e) {
            @unlink(__DIR__ . '/../../' . $timbangan);
            throw $e;
        }

        try {
            $stmt = $pdo->prepare("INSERT INTO ba_waste (tanggal,resto,quality_control,nama_barang,waste_gram,timbangan_foto,kronologi_waste,pemusnahan_foto) VALUES (?,?,?,?,?,?,?,?)");
            $stmt->execute([$tanggal,$resto,$qc,$namaBarang,(float)$wasteGram,$timbangan,$kronologi,$pemusnahan]);
        } catch (Throwable $e) {
            @unlink(__DIR__ . '/../../' . $timbangan);
            @unlink(__DIR__ . '/../../' . $pemusnahan);
            throw $e;
        }

        redirect('databawaste.php?tanggal=' . urlencode($tanggal));
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

require __DIR__ . '/../../includes/header.php';
?>
<style>
.qc-form-page{max-width:1180px;margin:0 auto;padding:0 0 28px}
.qc-form-head{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;margin-bottom:18px}
.qc-form-head h1{margin:0;font-size:30px;color:#123f78;font-weight:900}.qc-form-head p{margin:5px 0 0;color:#71839d;font-size:13px}
.qc-card{background:#fff;border:1px solid #dbe7f4;border-radius:20px;box-shadow:0 10px 32px rgba(32,74,124,.07);overflow:hidden}
.qc-card-title{padding:14px 20px;background:linear-gradient(110deg,#0f83ee,#196edc);color:#fff;font-weight:900}
.qc-form-body{padding:20px}.qc-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}
.qc-field{display:flex;flex-direction:column;gap:8px;font-size:13px;font-weight:800;color:#37526f;min-width:0}.qc-field.full{grid-column:1/-1}
.qc-field input,.qc-field select,.qc-field textarea{width:100%;min-width:0;box-sizing:border-box;border:1.5px solid #d0deed;border-radius:12px;background:#fbfdff;color:#203c60;min-height:46px;padding:0 13px;outline:none}
.qc-field textarea{padding:12px;min-height:140px;resize:vertical;line-height:1.5}
.qc-field input:focus,.qc-field select:focus,.qc-field textarea:focus{border-color:#2180ef;box-shadow:0 0 0 3px rgba(33,128,239,.1);background:#fff}
.qc-field input[readonly]{background:#f2f6fb;color:#55708d;cursor:not-allowed}
.qc-select-wrap{position:relative}.qc-select-wrap select{appearance:none;padding-right:42px}.qc-select-wrap:after{content:'⌄';position:absolute;right:14px;top:50%;transform:translateY(-50%);color:#6c85a3;font-size:18px;pointer-events:none}
.upload-box{border:1.5px dashed #9fc1e7;border-radius:14px;background:linear-gradient(180deg,#f8fbff,#fff);padding:14px}.upload-box input{border:0;padding:0;min-height:auto;background:transparent;cursor:pointer}.upload-box small{display:block;color:#8092a8;margin-top:8px;font-weight:600}
.preview{display:none;margin-top:10px;border:1px solid #dbe7f4;border-radius:12px;overflow:hidden;background:#f7fbff}.preview img{display:block;width:100%;height:180px;object-fit:cover}
.qc-form-footer{display:flex;justify-content:flex-end;gap:10px;padding:16px 20px;border-top:1px solid #e6eef7;background:#fbfdff}.btn-qc{border:0;border-radius:12px;min-height:44px;padding:11px 18px;font-weight:900;display:inline-flex;align-items:center;justify-content:center;cursor:pointer}.btn-qc.secondary{background:#eef3fa;color:#4c5f78}.btn-qc.primary{background:linear-gradient(135deg,#286fe9,#c63d9e);color:#fff}
.qc-alert{margin:0 20px 16px;padding:12px 14px;border:1px solid #fecaca;background:#fff1f2;color:#b91c1c;border-radius:12px;font-weight:700}
@media(max-width:760px){.qc-form-page{padding:0 0 20px}.qc-form-head{flex-direction:column;align-items:flex-start}.qc-form-head h1{font-size:24px}.qc-grid{grid-template-columns:1fr}.qc-field.full{grid-column:auto}.qc-form-body{padding:14px}.qc-form-footer{padding:12px 14px}.qc-form-footer .btn-qc{flex:1}.preview img{height:150px}}
</style>
<div class="qc-form-page">
  <div class="qc-form-head">
    <div><h1>Input BA Waste</h1><p>Berita Acara Waste · Pencatatan dan dokumentasi waste</p></div>
    <a class="btn-qc secondary" href="databawaste.php">← Kembali</a>
  </div>
  <section class="qc-card">
    <div class="qc-card-title">Informasi BA Waste</div>
    <?php if ($error !== ''): ?><div class="qc-alert"><?=e($error)?></div><?php endif; ?>
    <form method="post" enctype="multipart/form-data" id="baWasteForm" class="qc-form-body">
      <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
      <div class="qc-grid">
        <label class="qc-field">Tanggal<input type="date" value="<?=e($today)?>" readonly></label>
        <label class="qc-field">Resto<input type="text" value="Sumenep Trunojoyo" readonly></label>
        <label class="qc-field">Quality Control
          <span class="qc-select-wrap"><select name="quality_control" required><option value="">Pilih Quality Control</option><?php foreach($qcOptions as $q): ?><option value="<?=e($q)?>" <?=((string)($_POST['quality_control'] ?? '')===$q?'selected':'')?>><?=e($q)?></option><?php endforeach; ?></select></span>
        </label>
        <label class="qc-field">Nama Barang<input type="text" name="nama_barang" maxlength="180" placeholder="Masukkan nama barang" required value="<?=e($_POST['nama_barang'] ?? '')?>"></label>
        <label class="qc-field">Waste (Gram)<input type="number" name="waste_gram" min="0" step="0.01" inputmode="decimal" placeholder="Contoh: 250" required value="<?=e($_POST['waste_gram'] ?? '')?>"></label>
        <label class="qc-field">Dokumentasi Timbangan
          <span class="upload-box"><input type="file" name="timbangan_foto" accept="image/jpeg,image/png,image/webp" required data-preview="previewTimbangan"><small>JPG, PNG, WEBP · maksimal 5 MB</small><span class="preview" id="previewTimbangan"><img alt="Preview timbangan"></span></span>
        </label>
        <label class="qc-field">Dokumentasi Pemusnahan
          <span class="upload-box"><input type="file" name="pemusnahan_foto" accept="image/jpeg,image/png,image/webp" required data-preview="previewPemusnahan"><small>JPG, PNG, WEBP · maksimal 5 MB</small><span class="preview" id="previewPemusnahan"><img alt="Preview pemusnahan"></span></span>
        </label>
        <label class="qc-field full">Kronologi Waste<textarea name="kronologi_waste" maxlength="5000" placeholder="Jelaskan kronologi terjadinya waste, penyebab, dan proses pemusnahan..." required><?=e($_POST['kronologi_waste'] ?? '')?></textarea></label>
      </div>
    </form>
    <div class="qc-form-footer"><button class="btn-qc secondary" type="reset" form="baWasteForm">Reset</button><button class="btn-qc primary" type="submit" form="baWasteForm">Simpan Data</button></div>
  </section>
</div>
<script>
(function(){
 document.querySelectorAll('input[type=file][data-preview]').forEach(function(input){input.addEventListener('change',function(){const box=document.getElementById(input.dataset.preview),img=box&&box.querySelector('img');if(!box||!img||!input.files||!input.files[0])return;const reader=new FileReader();reader.onload=function(e){img.src=e.target.result;box.style.display='block'};reader.readAsDataURL(input.files[0]);});});
})();
</script>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
