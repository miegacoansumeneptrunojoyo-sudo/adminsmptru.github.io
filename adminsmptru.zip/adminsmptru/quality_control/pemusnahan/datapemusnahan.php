<?php
$pageTitle = 'Data Pemusnahan';
require_once __DIR__ . '/../../config.php';

function ensure_pemusnahan_schema(PDO $pdo): void
{
  $pdo->exec("CREATE TABLE IF NOT EXISTS `pemusnahan` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      `tanggal` DATE NOT NULL,
      `nama_produk` VARCHAR(180) NOT NULL,
      `kode_produksi` VARCHAR(120) NOT NULL,
      `tgl_produksi` DATE NULL,
      `tgl_expired` DATE NULL,
      `jumlah_produk` VARCHAR(120) NOT NULL,
      `metode_pemusnahan` VARCHAR(180) NOT NULL,
      `alasan_pemusnahan` TEXT NOT NULL,
      `pemusnahan_at` DATETIME NOT NULL,
      `nama_qc` VARCHAR(50) NOT NULL,
      `nama_saksi` VARCHAR(180) NOT NULL,
      `manager_ic` VARCHAR(180) NOT NULL DEFAULT 'Alvin Zakaria',
      `dokumentasi` VARCHAR(255) DEFAULT NULL,
      `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (`id`), KEY `idx_pemusnahan_tanggal` (`tanggal`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
  $cols = $pdo->query("SHOW COLUMNS FROM `pemusnahan`")->fetchAll();
  $existing = [];
  foreach ($cols as $c) $existing[$c['Field']] = true;
  $defs = ['tgl_produksi' => "ADD COLUMN `tgl_produksi` DATE NULL AFTER `kode_produksi`", 'tgl_expired' => "ADD COLUMN `tgl_expired` DATE NULL AFTER `tgl_produksi`", 'nama_saksi' => "ADD COLUMN `nama_saksi` VARCHAR(180) NOT NULL DEFAULT '' AFTER `nama_qc`", 'manager_ic' => "ADD COLUMN `manager_ic` VARCHAR(180) NOT NULL DEFAULT 'Alvin Zakaria' AFTER `nama_saksi`", 'dokumentasi' => "ADD COLUMN `dokumentasi` VARCHAR(255) DEFAULT NULL AFTER `manager_ic`", 'updated_at' => "ADD COLUMN `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`", 'pemusnahan_at' => "ADD COLUMN `pemusnahan_at` DATETIME NULL AFTER `alasan_pemusnahan`"];
  $alter = [];
  foreach ($defs as $n => $sql) if (!isset($existing[$n])) $alter[] = $sql;
  if ($alter) $pdo->exec('ALTER TABLE `pemusnahan` ' . implode(', ', $alter));
}
function pemusnahan_delete(PDO $pdo, int $id): void
{
  $s = $pdo->prepare('SELECT dokumentasi FROM pemusnahan WHERE id=?');
  $s->execute([$id]);
  $r = $s->fetch();
  if (!$r) throw new RuntimeException('Data tidak ditemukan.');
  $d = $pdo->prepare('DELETE FROM pemusnahan WHERE id=?');
  $d->execute([$id]);
  if (!empty($r['dokumentasi'])) @unlink(__DIR__ . '/../../' . $r['dokumentasi']);
}
$pdo = db();
ensure_pemusnahan_schema($pdo);
$today = date('Y-m-d');
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
  try {
    check_csrf();
    pemusnahan_delete($pdo, (int)$_POST['delete_id']);
    flash('success', 'Data pemusnahan berhasil dihapus.');
  } catch (Throwable $e) {
    flash('error', $e->getMessage());
  }
  redirect('datapemusnahan.php?tanggal=' . urlencode($_POST['tanggal_filter'] ?? $today));
}
$selectedDate = (string)($_GET['tanggal'] ?? $today);
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate)) $selectedDate = $today;
$s = $pdo->prepare('SELECT * FROM pemusnahan WHERE tanggal=? ORDER BY id DESC');
$s->execute([$selectedDate]);
$rows = $s->fetchAll();
require __DIR__ . '/../../includes/header.php';
$flash = get_flash();
?>
<style>
  .pm-data-page {
    max-width: 1500px;
    margin: 0 auto
  }

  .pm-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 14px;
    margin-bottom: 18px
  }

  .pm-head h2 {
    margin: 0;
    color: #123f78;
    font-size: 28px;
    font-weight: 900
  }

  .pm-actions {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap
  }

  .pm-date {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    font-weight: 800;
    color: #365171
  }

  .pm-date input {
    height: 42px;
    border: 1.5px solid #d0deed;
    border-radius: 11px;
    padding: 0 12px;
    color: #203c60;
    background: #fff;
    outline: none
  }

  .pm-date input:focus {
    border-color: #2180ef;
    box-shadow: 0 0 0 3px rgba(33, 128, 239, .1)
  }

  .pm-btn {
    min-height: 42px;
    padding: 10px 15px;
    border-radius: 11px;
    border: 1px solid #d7e3f4;
    background: #fff;
    color: #2454a5;
    font-weight: 800;
    font-size: 13px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    text-decoration: none
  }

  .pm-btn.primary {
    border-color: transparent;
    background: linear-gradient(90deg, #2563eb, #ec4899);
    color: #fff
  }

  .pm-btn.back {
    background: #f6f9ff;
    color: #31577f
  }

  .pm-btn.danger {
    background: #fff1f2;
    color: #be123c;
    border-color: #fecdd3
  }

  .pm-empty {
    background: #fff;
    border: 1px solid #e5ebf5;
    border-radius: 20px;
    min-height: 190px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center
  }

  .pm-empty h3 {
    margin: 0 0 8px;
    color: #123f78
  }

  .pm-empty p {
    margin: 0;
    color: #71839d
  }

  .pm-card {
    background: #fff;
    border: 1px solid #e5ebf5;
    border-radius: 20px;
    box-shadow: 0 8px 22px rgba(38, 66, 116, .06);
    overflow: hidden
  }

  .pm-wrap {
    width: 100%;
    overflow: auto
  }

  .pm-table {
    width: 100%;
    border-collapse: collapse;
    min-width: 1320px
  }

  .pm-table th,
  .pm-table td {
    padding: 12px 10px;
    border-bottom: 1px solid #edf1f7;
    font-size: 12.5px;
    vertical-align: top
  }

  .pm-table th {
    background: #f8fbff;
    color: #56708f;
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: .25px;
    text-align: center
  }

  .pm-table tbody tr:hover td {
    background: #fbfdff
  }

  .pm-table td {
    text-align: center
  }

  .pm-table td.product,
  .pm-table td.reason {
    text-align: left
  }

  .pm-code small,
  .pm-meta {
    display: block;
    color: #8090a8;
    font-size: 10.5px;
    margin-top: 2px
  }

  .pm-doc {
    width: 72px;
    height: 56px;
    object-fit: cover;
    border: 1px solid #dbe7f4;
    border-radius: 9px;
    display: block;
    margin: 0 auto 4px
  }

  .pm-link {
    font-size: 10.5px;
    color: #2563eb;
    font-weight: 800
  }

  .pm-actions-cell {
    display: flex;
    gap: 6px;
    justify-content: center;
    flex-wrap: wrap
  }

  .pm-flash {
    margin-bottom: 14px;
    padding: 12px 14px;
    border-radius: 12px;
    font-weight: 700
  }

  .pm-flash.success {
    background: #ecfdf3;
    color: #166534;
    border: 1px solid #bbf7d0
  }

  .pm-flash.error {
    background: #fff1f2;
    color: #9f1239;
    border: 1px solid #fecdd3
  }

  @media(max-width:760px) {
    .pm-head {
      align-items: flex-start;
      flex-direction: column
    }

    .pm-actions {
      width: 100%;
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px
    }

    .pm-actions .pm-btn {
      width: 100%
    }

    .pm-date {
      grid-column: 1/-1;
      justify-content: space-between
    }

    .pm-date input {
      flex: 1
    }

    .pm-table {
      min-width: 0
    }

    .pm-table thead {
      display: none
    }

    .pm-table,
    .pm-table tbody,
    .pm-table tr,
    .pm-table td {
      display: block;
      width: 100%
    }

    .pm-table tbody tr {
      border: 1px solid #e3ebf5;
      border-radius: 16px;
      margin-bottom: 12px;
      padding: 8px 12px
    }

    .pm-table td {
      display: grid;
      grid-template-columns: 125px minmax(0, 1fr);
      gap: 10px;
      text-align: left !important;
      padding: 10px 0;
      border-bottom: 1px dashed #e6edf5
    }

    .pm-table td:last-child {
      border-bottom: 0
    }

    .pm-table td:before {
      content: attr(data-label);
      font-weight: 800;
      color: #68809c
    }

    .pm-doc {
      margin: 0
    }
  }
</style>
<div class="pm-data-page">
  <div class="pm-head">
    <h2>Data Pemusnahan</h2>
    <div class="pm-actions"><a class="pm-btn back" href="../../qualitycontrol.php">← Kembali</a><label class="pm-date"><input type="date" id="pmTanggal" value="<?= e($selectedDate) ?>"></label><button class="pm-btn primary" id="pmShow" type="button">Tampilkan</button><a class="pm-btn primary" href="inputpemusnahan.php">＋ Input Data</a></div>
  </div>
  <?php if ($flash): ?><div class="pm-flash <?= e($flash['type']) ?>"><?= e($flash['message']) ?></div><?php endif; ?>
  <?php if (!$rows): ?><section class="pm-empty">
      <div>
        <h3>Belum ada data Pemusnahan</h3>
      </div>
    </section><?php else: ?>
    <section class="pm-card">
      <div class="pm-wrap">
        <table class="pm-table">
          <thead>
            <tr>
              <th>No.</th>
              <th>Nama Produk</th>
              <th>Kode Produk<br>(Tgl Produksi / Tgl Expired)</th>
              <th>Jumlah Produk</th>
              <th>Metode Pemusnahan</th>
              <th>Alasan Pemusnahan</th>
              <th>Jam &amp; Tgl Pemusnahan</th>
              <th>Nama QC</th>
              <th>Manager IC</th>
              <th>Dokumentasi</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($rows as $i => $r): ?><tr>
                <td data-label="No."><?= e($i + 1) ?></td>
                <td data-label="Nama Produk" class="product"><strong><?= e($r['nama_produk']) ?></strong><span class="pm-meta">Kode: <?= e($r['kode_produksi']) ?></span></td>
                <td data-label="Kode Produk" class="pm-code"><?= e($r['kode_produksi']) ?><small>Produksi: <?= e($r['tgl_produksi'] ?? '—') ?></small><small>Expired: <?= e($r['tgl_expired'] ?? '—') ?></small></td>
                <td data-label="Jumlah Produk"><?= e($r['jumlah_produk']) ?></td>
                <td data-label="Metode Pemusnahan"><?= e($r['metode_pemusnahan']) ?></td>
                <td data-label="Alasan Pemusnahan" class="reason"><?= e($r['alasan_pemusnahan']) ?></td>
                <td data-label="Jam & Tgl Pemusnahan"><?= e(date('d/m/Y H:i', strtotime($r['pemusnahan_at']))) ?></td>
                <td data-label="Nama QC"><?= e($r['nama_qc']) ?></td>
                <td data-label="Manager IC"><?= e($r['manager_ic']) ?></td>
                <td data-label="Dokumentasi"><?php if (!empty($r['dokumentasi'])): ?><a href="../../<?= e($r['dokumentasi']) ?>" target="_blank" rel="noopener"><img class="pm-doc" src="../../<?= e($r['dokumentasi']) ?>" alt="Dokumentasi"><span class="pm-link">Lihat Foto</span></a><?php else: ?><span>—</span><?php endif; ?></td>
                <td data-label="Action">
                  <div class="pm-actions-cell"><a class="pm-btn" href="editpemusnahan.php?id=<?= e($r['id']) ?>">✏️ Edit</a>
                    <form method="post" onsubmit="return confirm('Hapus data pemusnahan ini?')"><input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>"><input type="hidden" name="delete_id" value="<?= e($r['id']) ?>"><input type="hidden" name="tanggal_filter" value="<?= e($selectedDate) ?>"><button class="pm-btn danger" type="submit">🗑️ Hapus</button></form>
                  </div>
                </td>
              </tr><?php endforeach; ?></tbody>
        </table>
      </div>
    </section>
  <?php endif; ?>
</div>
<script>
  document.getElementById('pmShow').addEventListener('click', function() {
    const d = document.getElementById('pmTanggal').value;
    if (d) location.href = 'datapemusnahan.php?tanggal=' + encodeURIComponent(d);
  });
</script>
<?php require __DIR__ . '/../../includes/footer.php'; ?>