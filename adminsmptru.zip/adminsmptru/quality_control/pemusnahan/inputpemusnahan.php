<?php
$pageTitle='Input Pemusnahan';
require_once __DIR__ . '/../../config.php';

function ensure_pemusnahan_schema(PDO $pdo): void
{
    $pdo->exec("CREATE TABLE IF NOT EXISTS `pemusnahan` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      `tanggal` DATE NOT NULL,
      `nama_produk` VARCHAR(180) NOT NULL,
      `kode_produksi` VARCHAR(120) NOT NULL,
      `tgl_produksi` DATE NULL,
      `tgl_expired` DATE NULL,
      `jumlah_produk` VARCHAR(120) NOT NULL,
      `metode_pemusnahan` VARCHAR(180) NOT NULL,
      `alasan_pemusnahan` TEXT NOT NULL,
      `pemusnahan_at` DATETIME NOT NULL,
      `nama_qc` ENUM('Atika','Ega','Luluk') NOT NULL,
      `nama_saksi` VARCHAR(180) NOT NULL,
      `manager_ic` VARCHAR(180) NOT NULL DEFAULT 'Alvin Zakaria',
      `dokumentasi` VARCHAR(255) DEFAULT NULL,
      `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (`id`),
      KEY `idx_pemusnahan_tanggal` (`tanggal`),
      KEY `idx_pemusnahan_qc` (`nama_qc`),
      KEY `idx_pemusnahan_at` (`pemusnahan_at`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    $cols=$pdo->query("SHOW COLUMNS FROM `pemusnahan`")->fetchAll(); $existing=[]; foreach($cols as $c)$existing[$c['Field']]=true;
    $alter=[];
    $defs=[
      'tgl_produksi'=>"ADD COLUMN `tgl_produksi` DATE NULL AFTER `kode_produksi`",
      'tgl_expired'=>"ADD COLUMN `tgl_expired` DATE NULL AFTER `tgl_produksi`",
      'nama_saksi'=>"ADD COLUMN `nama_saksi` VARCHAR(180) NOT NULL DEFAULT '' AFTER `nama_qc`",
      'manager_ic'=>"ADD COLUMN `manager_ic` VARCHAR(180) NOT NULL DEFAULT 'Alvin Zakaria' AFTER `nama_saksi`",
      'dokumentasi'=>"ADD COLUMN `dokumentasi` VARCHAR(255) DEFAULT NULL AFTER `manager_ic`",
      'updated_at'=>"ADD COLUMN `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`",
      'pemusnahan_at'=>"ADD COLUMN `pemusnahan_at` DATETIME NULL AFTER `alasan_pemusnahan`",
    ];
    foreach($defs as $name=>$sql)if(!isset($existing[$name]))$alter[]=$sql;
    if($alter)$pdo->exec('ALTER TABLE `pemusnahan` '.implode(', ',$alter));
}

function upload_pemusnahan_photo(array $file, string $prefix): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) throw new RuntimeException('Dokumentasi wajib diupload.');
    if (($file['size'] ?? 0) > MAX_FILE_SIZE) throw new RuntimeException('Ukuran foto maksimal 5 MB.');
    $tmp=(string)($file['tmp_name'] ?? ''); if(!is_uploaded_file($tmp))throw new RuntimeException('File upload tidak valid.');
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($tmp); $ext=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'][$mime]??null;
    if($ext===null)throw new RuntimeException('Format dokumentasi harus JPG, PNG, atau WEBP.');
    $dir=UPLOAD_DIR.'pemusnahan/'; if(!is_dir($dir)&&!mkdir($dir,0775,true)&&!is_dir($dir))throw new RuntimeException('Folder upload tidak dapat dibuat.');
    $name=$prefix.'_'.date('Ymd_His').'_'.bin2hex(random_bytes(4)).'.'.$ext;
    if(!move_uploaded_file($tmp,$dir.$name))throw new RuntimeException('Dokumentasi gagal disimpan.');
    return 'uploads/pemusnahan/'.$name;
}

$pdo=db(); ensure_pemusnahan_schema($pdo);
$today=date('Y-m-d'); $error=''; $qcOptions=['Atika','Ega','Luluk'];

if($_SERVER['REQUEST_METHOD']==='POST'){
  try{
    check_csrf();
    $tanggal=$today;
    $namaProduk=trim((string)($_POST['nama_produk']??''));
    $kodeProduksi=trim((string)($_POST['kode_produksi']??''));
    $tglProduksi=trim((string)($_POST['tgl_produksi']??''));
    $tglExpired=trim((string)($_POST['tgl_expired']??''));
    $jumlahProduk=trim((string)($_POST['jumlah_produk']??''));
    $metode=trim((string)($_POST['metode_pemusnahan']??''));
    $alasan=trim((string)($_POST['alasan_pemusnahan']??''));
    $pemusnahanAt=trim((string)($_POST['pemusnahan_at']??''));
    $namaQc=trim((string)($_POST['nama_qc']??''));
    $namaSaksi=trim((string)($_POST['nama_saksi']??''));
    if($namaProduk==='')throw new RuntimeException('Nama Produk wajib diisi.');
    if($kodeProduksi==='')throw new RuntimeException('Kode Produksi wajib diisi.');
    if($jumlahProduk==='')throw new RuntimeException('Jumlah Produk wajib diisi.');
    if($metode==='')throw new RuntimeException('Metode Pemusnahan wajib diisi.');
    if($alasan==='')throw new RuntimeException('Alasan Pemusnahan wajib diisi.');
    if($pemusnahanAt==='')throw new RuntimeException('Jam & Tanggal Pemusnahan wajib diisi.');
    $dt=DateTime::createFromFormat('Y-m-d\\TH:i',$pemusnahanAt); if(!$dt)throw new RuntimeException('Format Jam & Tanggal Pemusnahan tidak valid.');
    if(!in_array($namaQc,$qcOptions,true))throw new RuntimeException('Nama QC wajib dipilih.');
    if($namaSaksi==='')throw new RuntimeException('Nama Saksi wajib diisi.');

    $doc=upload_pemusnahan_photo($_FILES['dokumentasi']??[],'pemusnahan');
    try{
      $stmt=$pdo->prepare("INSERT INTO pemusnahan (tanggal,nama_produk,kode_produksi,tgl_produksi,tgl_expired,jumlah_produk,metode_pemusnahan,alasan_pemusnahan,pemusnahan_at,nama_qc,nama_saksi,manager_ic,dokumentasi) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
      $stmt->execute([$tanggal,$namaProduk,$kodeProduksi,($tglProduksi!==''?$tglProduksi:null),($tglExpired!==''?$tglExpired:null),$jumlahProduk,$metode,$alasan,$dt->format('Y-m-d H:i:s'),$namaQc,$namaSaksi,'Alvin Zakaria',$doc]);
    }catch(Throwable $e){@unlink(__DIR__.'/../../'.$doc);throw $e;}
    redirect('datapemusnahan.php?tanggal='.urlencode($tanggal));
  }catch(Throwable $e){$error=$e->getMessage();}
}

require __DIR__.'/../../includes/header.php';
?>
<style>
.pemus-page{max-width:1180px;margin:0 auto;padding-bottom:28px}.pemus-head{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;margin-bottom:18px}.pemus-head h1{margin:0;color:#123f78;font-size:30px;font-weight:900}.pemus-head p{margin:5px 0 0;color:#71839d;font-size:13px}
.pemus-card{background:#fff;border:1px solid #dbe7f4;border-radius:20px;overflow:hidden;box-shadow:0 10px 32px rgba(32,74,124,.07)}.pemus-banner{background:linear-gradient(110deg,#0f83ee,#196edc);color:#fff;font-weight:900;padding:14px 20px}.pemus-body{padding:20px}.pemus-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}.pemus-field{display:flex;flex-direction:column;gap:8px;font-size:13px;font-weight:800;color:#37526f;min-width:0}.pemus-field.full{grid-column:1/-1}.pemus-field input,.pemus-field select,.pemus-field textarea{width:100%;min-width:0;box-sizing:border-box;border:1.5px solid #d0deed;border-radius:12px;background:#fbfdff;color:#203c60;min-height:46px;padding:0 13px;outline:none}.pemus-field textarea{padding:12px;min-height:120px;resize:vertical}.pemus-field input:focus,.pemus-field select:focus,.pemus-field textarea:focus{border-color:#2180ef;box-shadow:0 0 0 3px rgba(33,128,239,.1);background:#fff}.pemus-field input[readonly]{background:#f2f6fb;color:#55708d;cursor:not-allowed}.pemus-select{position:relative}.pemus-select select{appearance:none;padding-right:42px}.pemus-select:after{content:'⌄';position:absolute;right:14px;top:50%;transform:translateY(-50%);color:#6c85a3;font-size:18px;pointer-events:none}.upload-box{border:1.5px dashed #9fc1e7;border-radius:14px;padding:14px;background:linear-gradient(180deg,#f8fbff,#fff)}.upload-box input{border:0;padding:0;min-height:auto;background:transparent}.upload-box small{display:block;margin-top:8px;color:#8092a8}.preview{display:none;margin-top:10px;overflow:hidden;border:1px solid #dbe7f4;border-radius:12px}.preview img{display:block;width:100%;height:190px;object-fit:cover}.pemus-actions{display:flex;justify-content:flex-end;gap:10px;padding:16px 20px;border-top:1px solid #e6eef7;background:#fbfdff}.pemus-btn{border:0;border-radius:12px;min-height:44px;padding:11px 18px;font-weight:900;display:inline-flex;align-items:center;justify-content:center;cursor:pointer}.pemus-btn.secondary{background:#eef3fa;color:#4c5f78}.pemus-btn.primary{background:linear-gradient(135deg,#286fe9,#c63d9e);color:#fff}.pemus-alert{margin:0 20px 16px;padding:12px 14px;background:#fff1f2;color:#b91c1c;border:1px solid #fecaca;border-radius:12px;font-weight:700}
@media(max-width:760px){.pemus-head{align-items:flex-start;flex-direction:column}.pemus-head h1{font-size:24px}.pemus-grid{grid-template-columns:1fr}.pemus-field.full{grid-column:auto}.pemus-body{padding:14px}.pemus-actions{padding:12px 14px}.pemus-actions .pemus-btn{flex:1}.preview img{height:160px}}
</style>
<div class="pemus-page">
<div class="pemus-head"><div><h1>Input Pemusnahan</h1><p>Dokumentasi dan pencatatan proses pemusnahan produk</p></div><a class="pemus-btn secondary" href="datapemusnahan.php">← Kembali</a></div>
<section class="pemus-card"><div class="pemus-banner">Informasi Pemusnahan</div>
<?php if($error!==''): ?><div class="pemus-alert"><?=e($error)?></div><?php endif; ?>
<form method="post" enctype="multipart/form-data" id="pemusForm" class="pemus-body"><input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
<div class="pemus-grid">
<label class="pemus-field">Tanggal<input type="date" value="<?=e($today)?>" readonly></label>
<label class="pemus-field">Nama Produk<input type="text" name="nama_produk" required maxlength="180" placeholder="Masukkan nama produk" value="<?=e($_POST['nama_produk']??'')?>"></label>
<label class="pemus-field">Kode Produksi<input type="text" name="kode_produksi" required maxlength="120" placeholder="Masukkan kode produksi" value="<?=e($_POST['kode_produksi']??'')?>"></label>
<label class="pemus-field">Tanggal Produksi<input type="date" name="tgl_produksi" value="<?=e($_POST['tgl_produksi']??'')?>"></label>
<label class="pemus-field">Tanggal Expired<input type="date" name="tgl_expired" value="<?=e($_POST['tgl_expired']??'')?>"></label>
<label class="pemus-field">Jumlah Produk<input type="text" name="jumlah_produk" required maxlength="120" placeholder="Contoh: 5 kg / 10 pcs / 2 pack" value="<?=e($_POST['jumlah_produk']??'')?>"></label>
<label class="pemus-field">Metode Pemusnahan<input type="text" name="metode_pemusnahan" required maxlength="180" placeholder="Contoh: Dimusnahkan dengan metode ..." value="<?=e($_POST['metode_pemusnahan']??'')?>"></label>
<label class="pemus-field">Jam &amp; Tanggal Pemusnahan<input type="datetime-local" name="pemusnahan_at" required value="<?=e($_POST['pemusnahan_at']??'')?>"></label>
<label class="pemus-field">Nama QC<span class="pemus-select"><select name="nama_qc" required><option value="">Pilih Nama QC</option><?php foreach($qcOptions as $q): ?><option value="<?=e($q)?>" <?=((string)($_POST['nama_qc']??'')===$q?'selected':'')?>><?=e($q)?></option><?php endforeach; ?></select></span></label>
<label class="pemus-field">Nama Saksi<input type="text" name="nama_saksi" required maxlength="180" placeholder="Masukkan nama saksi" value="<?=e($_POST['nama_saksi']??'')?>"></label>
<label class="pemus-field">Manager IC<input type="text" value="Alvin Zakaria" readonly></label>
<label class="pemus-field">Dokumentasi<span class="upload-box"><input type="file" name="dokumentasi" accept="image/jpeg,image/png,image/webp" required data-preview="previewDoc"><small>JPG, PNG, WEBP · maksimal 5 MB</small><span class="preview" id="previewDoc"><img alt="Preview dokumentasi"></span></span></label>
<label class="pemus-field full">Alasan Pemusnahan<textarea name="alasan_pemusnahan" required maxlength="5000" placeholder="Jelaskan alasan produk dimusnahkan..." ><?=e($_POST['alasan_pemusnahan']??'')?></textarea></label>
</div></form>
<div class="pemus-actions"><button type="reset" class="pemus-btn secondary" form="pemusForm">Reset</button><button type="submit" class="pemus-btn primary" form="pemusForm">Simpan Data</button></div>
</section></div>
<script>(function(){document.querySelectorAll('input[type=file][data-preview]').forEach(function(input){input.addEventListener('change',function(){const box=document.getElementById(input.dataset.preview),img=box&&box.querySelector('img');if(!box||!img||!input.files||!input.files[0])return;const r=new FileReader();r.onload=function(e){img.src=e.target.result;box.style.display='block'};r.readAsDataURL(input.files[0]);});});})();</script>
<?php require __DIR__.'/../../includes/footer.php'; ?>
