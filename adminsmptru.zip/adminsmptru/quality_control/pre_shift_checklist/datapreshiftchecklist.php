<?php
$pageTitle = 'Data Pre-Shift Checklist';
require_once __DIR__ . '/../../config.php';
$pdo = db();
$pdo->exec("CREATE TABLE IF NOT EXISTS `pre_shift_checklists` (
  `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `tanggal` DATE NOT NULL,
  `shift` ENUM('Prepare','Middle','Closing') NOT NULL,
  `nama_qc` VARCHAR(50) NOT NULL,
  `procedures_json` LONGTEXT NOT NULL,
  `inspections_json` LONGTEXT NOT NULL,
  `feedback` TEXT NULL,
  `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`), KEY `idx_pre_shift_tanggal` (`tanggal`), KEY `idx_pre_shift_shift` (`shift`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
$today = date('Y-m-d');
$selectedDate = (string)($_GET['tanggal'] ?? $today);
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate)) $selectedDate = $today;
$stmt = $pdo->prepare("SELECT * FROM pre_shift_checklists WHERE tanggal=? ORDER BY id DESC");
$stmt->execute([$selectedDate]);
$rows = $stmt->fetchAll();
foreach ($rows as &$r) {
  $r['procedures'] = json_decode($r['procedures_json'] ?? '[]', true) ?: [];
  $r['inspections'] = json_decode($r['inspections_json'] ?? '[]', true) ?: [];
}
unset($r);
require __DIR__ . '/../../includes/header.php';
?>
<style>
  .ps-data {
    max-width: 1320px;
    margin: 0 auto;
    padding-bottom: 30px
  }

  .ps-data-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 14px;
    margin-bottom: 18px
  }

  .ps-data-head h2 {
    margin: 0;
    color: #123f78;
    font-size: 28px;
    font-weight: 900
  }

  .ps-data-actions {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap
  }

  .ps-date {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    font-weight: 800;
    color: #355170
  }

  .ps-date input {
    height: 42px;
    border: 1.5px solid #d0deed;
    border-radius: 11px;
    padding: 0 12px;
    color: #203c60;
    background: #fff;
    outline: none
  }

  .ps-btn {
    min-height: 42px;
    padding: 10px 15px;
    border-radius: 11px;
    border: 1px solid #d7e3f4;
    background: #fff;
    color: #2454a5;
    font-weight: 800;
    font-size: 13px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    text-decoration: none
  }

  .ps-btn.primary {
    border-color: transparent;
    background: linear-gradient(90deg, #2563eb, #ec4899);
    color: #fff
  }

  .ps-empty {
    background: #fff;
    border: 1px solid #e5ebf5;
    border-radius: 20px;
    min-height: 190px;
    display: flex;
    align-items: center;
    justify-content: center;
    text-align: center;
    box-shadow: 0 8px 20px rgba(38, 66, 116, .06)
  }

  .ps-empty h3 {
    margin: 0 0 8px;
    color: #123f78
  }

  .ps-empty p {
    margin: 0;
    color: #71839d
  }

  .ps-record {
    background: #fff;
    border: 1px solid #e0e8f3;
    border-radius: 18px;
    box-shadow: 0 8px 22px rgba(38, 66, 116, .06);
    margin-bottom: 16px;
    overflow: hidden
  }

  .ps-record-head {
    display: grid;
    grid-template-columns: 80px 140px 130px 1fr auto;
    gap: 12px;
    align-items: center;
    padding: 14px 16px;
    background: linear-gradient(90deg, #f7fbff, #fff7fb);
    border-bottom: 1px solid #e5edf6
  }

  .ps-record-head .label {
    font-size: 10px;
    color: #74889f;
    font-weight: 900;
    text-transform: uppercase
  }

  .ps-record-head strong {
    display: block;
    color: #173d68;
    margin-top: 4px
  }

  .ps-pill {
    display: inline-flex;
    padding: 6px 10px;
    border-radius: 999px;
    background: #edf5ff;
    color: #1d4ed8;
    font-size: 11px;
    font-weight: 900
  }

  .ps-detail {
    padding: 16px
  }

  .ps-section-title {
    font-size: 14px;
    font-weight: 900;
    color: #1d4771;
    margin: 0 0 10px
  }

  .ps-table-wrap {
    overflow: auto
  }

  .ps-table {
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed;
    min-width: 780px
  }

  .ps-table th,
  .ps-table td {
    padding: 10px;
    border-bottom: 1px solid #e9eff5;
    font-size: 12px;
    vertical-align: top
  }

  .ps-table th {
    background: #f8fbff;
    color: #607691;
    font-size: 11px;
    text-align: left
  }

  .ps-table td strong {
    color: #1f3d67
  }

  .ps-status {
    display: inline-flex;
    padding: 4px 8px;
    border-radius: 999px;
    font-size: 10px;
    font-weight: 900
  }

  .ps-ac {
    background: #dcfce7;
    color: #166534
  }

  .ps-un {
    background: #fee2e2;
    color: #b91c1c
  }

  .ps-na {
    background: #f1f5f9;
    color: #64748b
  }

  .ps-feedback {
    margin-top: 14px;
    padding: 12px 14px;
    border-radius: 12px;
    background: #fbfdff;
    border: 1px solid #e1e9f3;
    color: #415d7a;
    font-size: 12px;
    white-space: pre-wrap
  }

  .ps-inspection-card {
    border: 1px solid #dde7f2;
    border-radius: 14px;
    padding: 12px;
    margin-top: 10px
  }

  .ps-inspection-card-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 10px;
    margin-bottom: 9px
  }

  .ps-inspection-card-head strong {
    color: #234a74
  }

  .ps-meta {
    font-size: 11px;
    color: #74889f
  }

  .ps-product-grid {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 8px
  }

  .ps-product {
    border: 1px solid #e2eaf3;
    background: #fbfdff;
    border-radius: 10px;
    padding: 8px;
    font-size: 11px;
    color: #526f8e;
    display: flex;
    justify-content: space-between;
    gap: 7px
  }

  .ps-no {
    width: 30px;
    height: 30px;
    border-radius: 9px;
    background: #eaf4ff;
    color: #176fd8;
    display: grid;
    place-items: center;
    font-weight: 900
  }

  @media(max-width:1000px) {
    .ps-record-head {
      grid-template-columns: 55px 1fr 1fr auto
    }

    .ps-record-head .summary-wide {
      grid-column: 2/-1
    }

    .ps-product-grid {
      grid-template-columns: repeat(2, minmax(0, 1fr))
    }
  }

  @media(max-width:760px) {
    .ps-data-head {
      align-items: flex-start;
      flex-direction: column
    }

    .ps-data-actions {
      width: 100%;
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 8px
    }

    .ps-date {
      grid-column: 1/-1;
      justify-content: space-between
    }

    .ps-date input {
      flex: 1
    }

    .ps-record-head {
      grid-template-columns: 42px 1fr 1fr;
      align-items: start
    }

    .ps-record-head .summary-wide {
      grid-column: 1/-1
    }

    .ps-detail {
      padding: 12px
    }

    .ps-product-grid {
      grid-template-columns: 1fr
    }

    .ps-table {
      min-width: 0
    }

    .ps-table,
    .ps-table tbody,
    .ps-table tr,
    .ps-table td {
      display: block;
      width: 100%
    }

    .ps-table thead {
      display: none
    }

    .ps-table tbody tr {
      border: 1px solid #e1eaf4;
      border-radius: 12px;
      margin-bottom: 10px;
      padding: 8px
    }

    .ps-table td {
      display: grid;
      grid-template-columns: 120px minmax(0, 1fr);
      gap: 8px;
      border: 0;
      border-bottom: 1px dashed #e9eef4
    }

    .ps-table td:last-child {
      border-bottom: 0
    }

    .ps-table td::before {
      content: attr(data-label);
      font-weight: 800;
      color: #72869d;
      font-size: 10px;
      text-transform: uppercase
    }

    .ps-detail .ps-table-wrap {
      overflow: visible
    }
  }
</style>
<div class="ps-data">
  <div class="ps-data-head">
    <h2>Data Pre-Shift Checklist</h2>
    <div class="ps-data-actions"><a class="ps-btn" href="../../qualitycontrol.php">← Kembali</a><label class="ps-date"><input type="date" id="tanggal" value="<?= e($selectedDate) ?>"></label><button type="button" class="ps-btn primary" id="showBtn">Tampilkan</button><a class="ps-btn primary" href="inputpreshiftchecklist.php">＋ Input Data</a></div>
  </div>
  <?php if (!$rows): ?><section class="ps-empty">
      <div>
        <h3>Belum ada data Pre-Shift Checklist</h3>
      </div>
    </section>
    <?php else: foreach ($rows as $i => $r): ?>
      <section class="ps-record">
        <div class="ps-record-head">
          <span class="ps-no"><?= e($i + 1) ?></span>
          <div><span class="label">Tanggal</span><strong><?= e(date('d/m/Y', strtotime($r['tanggal']))) ?></strong></div>
          <div><span class="label">Shift</span><strong><span class="ps-pill"><?= e($r['shift']) ?></span></strong></div>
          <div class="summary-wide"><span class="label">Nama QC</span><strong><?= e($r['nama_qc']) ?></strong></div>
          <span></span>
        </div>
        <div class="ps-detail">
          <h3 class="ps-section-title">Pengecekan Prosedure Inspeksi Produk</h3>
          <div class="ps-table-wrap">
            <table class="ps-table">
              <thead>
                <tr>
                  <th>Procedure</th>
                  <th>Standard dan Critical Control Point</th>
                  <th>Hasil</th>
                  <th>Catatan</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($r['procedures'] as $p): $res = $p['hasil'] ?? ''; ?><tr>
                    <td data-label="Procedure"><strong><?= e($p['procedure'] ?? '') ?></strong></td>
                    <td data-label="Standard dan Critical Control Point"><?= e($p['standard'] ?? '') ?></td>
                    <td data-label="Hasil"><span class="ps-status <?= ($res === 'AC' ? 'ps-ac' : ($res === 'UN' ? 'ps-un' : 'ps-na')) ?>"><?= e($res !== '' ? $res : 'Belum diisi') ?></span></td>
                    <td data-label="Catatan"><?= nl2br(e($p['catatan'] ?? '')) ?></td>
                  </tr><?php endforeach; ?></tbody>
            </table>
          </div>
          <h3 class="ps-section-title" style="margin-top:18px">Temperature Inspection</h3>
          <?php foreach ($r['inspections'] as $j => $ins): ?><div class="ps-inspection-card">
              <div class="ps-inspection-card-head"><strong>Jam <?= e($ins['jam'] ?? '') ?> · QC <?= e($ins['nama_qc'] ?? '-') ?></strong><span class="ps-meta">Inspeksi <?= e($j + 1) ?></span></div>
              <div class="ps-product-grid"><?php foreach (($ins['produk'] ?? []) as $prod => $res): ?><div class="ps-product"><span><?= e($prod) ?></span><span class="ps-status <?= ($res === 'AC' ? 'ps-ac' : ($res === 'UN' ? 'ps-un' : 'ps-na')) ?>"><?= e($res !== '' ? $res : '—') ?></span></div><?php endforeach; ?></div><?php if (trim((string)($ins['keterangan'] ?? '')) !== ''): ?><div class="ps-feedback"><strong>Keterangan:</strong><br><?= nl2br(e($ins['keterangan'])) ?></div><?php endif; ?>
            </div><?php endforeach; ?>
          <div class="ps-feedback"><strong>Feedback Shift:</strong><br><?= nl2br(e($r['feedback'] ?? '')) ?></div>
        </div>
      </section>
  <?php endforeach;
  endif; ?>
</div>
<script>
  document.getElementById('showBtn').addEventListener('click', () => {
    const d = document.getElementById('tanggal').value;
    if (d) location.href = 'datapreshiftchecklist.php?tanggal=' + encodeURIComponent(d);
  });
</script>
<?php require __DIR__ . '/../../includes/footer.php'; ?>