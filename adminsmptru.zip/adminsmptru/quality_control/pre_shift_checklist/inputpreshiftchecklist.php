<?php
$pageTitle = 'Input Pre-Shift Checklist';
require_once __DIR__ . '/../../config.php';

$today = date('Y-m-d');
$shiftOptions = ['Prepare', 'Middle', 'Closing'];
$qcOptions = ['Atika', 'Ega', 'Luluk'];
$timeOptions = ['02:00','03:00','04:00','05:00','06:00','07:00','08:00','09:00','10:00','15:00','16:00','21:00','22:00'];

$procedures = [
    ['Kulit Pangsit', 'Tidak berbau, tidak lengket, ukuran 12 x 12cm, perlembar 13 gr - 17 gr (66 lembar/kg)'],
    ['Pentol Thawing', 'Suhu 0-4 derajat, berat 25gr/pcs, berat total 600 gr (berat yang dapat ditoleransi 588-612gr per pack). tidak berair / tidak berlendir'],
    ['Mie Thawing', 'Suhu 0-4 derajat, Random sampling, berat 80-90 gr, diameter 1,5-1,6mm, panjang 30-35 cm'],
    ['Cabe Merah', 'Cabe yang telah melalui proses perendaman, tidak berulat, tidak busuk, 85% cabai merah'],
    ['Belimbing', 'Warna hijau kekuningan, tidak busuk, 1 kg 4-5 biji'],
    ['Strawberry', 'sudah melalui proses perendaman , kondisi fresh , tidak busuk , tekstur tidak lembek , tidak terdapat ulat'],
    ['Siomay', 'Berat 30gr /pcs , Berat yang dapat di toleransi 705 gr - 735 gr , tampilan bagus , kulit tidak mengelupas , tidak menempel , jamur tidak terlihat'],
    ['Adonan Pangsit', 'Tidak berair, Tidak bocor, Tidak menggelembung, Tidak berbuih'],
    ['Surai Naga', 'Tidak Berbau, Tidak Lengket,'],
];
$products = ['Mie Thawingan','Kulit pangsit','Adonan Pangsit','Surai Naga','Pentol Thawing','Siomay','Cabe','Belimbing','Strawberry'];

function ensure_schema(PDO $pdo): void {
    $pdo->exec("CREATE TABLE IF NOT EXISTS `pre_shift_checklists` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
      `tanggal` DATE NOT NULL,
      `shift` ENUM('Prepare','Middle','Closing') NOT NULL,
      `nama_qc` VARCHAR(50) NOT NULL,
      `procedures_json` LONGTEXT NOT NULL,
      `inspections_json` LONGTEXT NOT NULL,
      `feedback` TEXT NULL,
      `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      PRIMARY KEY (`id`), KEY `idx_pre_shift_tanggal` (`tanggal`), KEY `idx_pre_shift_shift` (`shift`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
}

$pdo = db();
ensure_schema($pdo);
$error = '';
$oldShift = $_POST['shift'] ?? '';
$oldQc = $_POST['nama_qc'] ?? '';
$oldFeedback = $_POST['feedback'] ?? '';
$oldProcedures = $_POST['procedure_result'] ?? [];
$oldNotes = $_POST['procedure_note'] ?? [];
$oldInspections = $_POST['inspections'] ?? [
    ['jam'=>'','nama_qc'=>'','produk'=>array_fill_keys($products,''),'keterangan'=>'']
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        check_csrf();
        if (!in_array($oldShift, $shiftOptions, true)) throw new RuntimeException('Shift wajib dipilih.');
        if (!in_array($oldQc, $qcOptions, true)) throw new RuntimeException('Nama QC wajib dipilih.');

        $procedureRows = [];
        foreach ($procedures as $i => $p) {
            $result = trim((string)($oldProcedures[$i] ?? ''));
            $note = trim((string)($oldNotes[$i] ?? ''));
            if ($result !== '' || $note !== '') {
                if ($result !== '' && !in_array($result, ['AC','UN'], true)) throw new RuntimeException('Hasil prosedur tidak valid.');
            }
            $procedureRows[] = ['procedure'=>$p[0], 'standard'=>$p[1], 'hasil'=>$result, 'catatan'=>$note];
        }

        $inspectionRows = [];
        foreach ((array)($_POST['inspections'] ?? []) as $row) {
            $jam = trim((string)($row['jam'] ?? ''));
            $qc = trim((string)($row['nama_qc'] ?? ''));
            $ket = trim((string)($row['keterangan'] ?? ''));
            $produkIn = (array)($row['produk'] ?? []);
            $produk = [];
            $hasAny = ($jam !== '' || $qc !== '' || $ket !== '');
            foreach ($products as $product) {
                $v = trim((string)($produkIn[$product] ?? ''));
                if ($v !== '' && !in_array($v, ['AC','UN'], true)) throw new RuntimeException('Hasil temperature inspection tidak valid.');
                $produk[$product] = $v;
                if ($v !== '') $hasAny = true;
            }
            if ($hasAny) {
                if ($jam === '') throw new RuntimeException('Jam inspeksi wajib diisi pada setiap baris yang digunakan.');
                if (!in_array($jam, $timeOptions, true)) throw new RuntimeException('Jam inspeksi tidak valid.');
                if ($qc !== '' && !in_array($qc, $qcOptions, true)) throw new RuntimeException('Nama QC inspeksi tidak valid.');
                $inspectionRows[] = ['jam'=>$jam,'nama_qc'=>$qc,'produk'=>$produk,'keterangan'=>$ket];
            }
        }
        if (!$inspectionRows) throw new RuntimeException('Minimal satu baris Temperature Inspection harus diisi.');

        $stmt = $pdo->prepare("INSERT INTO pre_shift_checklists (tanggal,shift,nama_qc,procedures_json,inspections_json,feedback) VALUES (?,?,?,?,?,?)");
        $stmt->execute([$today,$oldShift,$oldQc,json_encode($procedureRows, JSON_UNESCAPED_UNICODE),json_encode($inspectionRows, JSON_UNESCAPED_UNICODE),trim((string)$oldFeedback)]);
        redirect('datapreshiftchecklist.php?tanggal=' . urlencode($today));
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

require __DIR__ . '/../../includes/header.php';
?>
<style>
.ps-page{max-width:1320px;margin:0 auto;padding-bottom:30px}.ps-head{display:flex;justify-content:space-between;align-items:flex-end;gap:16px;margin-bottom:18px}.ps-head h1{margin:0;color:#123f78;font-size:30px;font-weight:900}.ps-head p{margin:5px 0 0;color:#71839d;font-size:13px}.ps-card{background:#fff;border:1px solid #dbe7f4;border-radius:20px;box-shadow:0 10px 28px rgba(32,74,124,.07);overflow:hidden;margin-bottom:18px}.ps-title{background:linear-gradient(110deg,#0f83ee,#196edc);color:#fff;font-weight:900;padding:15px 20px}.ps-body{padding:20px}.ps-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}.ps-field{display:flex;flex-direction:column;gap:7px;color:#37526f;font-size:13px;font-weight:800;min-width:0}.ps-field input,.ps-field select,.ps-field textarea{width:100%;min-width:0;box-sizing:border-box;border:1.5px solid #cfddec;border-radius:12px;background:#fbfdff;color:#203c60;padding:11px 13px;outline:none;font:inherit;min-height:46px}.ps-field select{appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%23647792' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 14px center;background-size:16px;padding-right:42px}.ps-field textarea{min-height:100px;resize:vertical}.ps-field input[readonly]{background:#f2f6fb;color:#55708d}.ps-field input:focus,.ps-field select:focus,.ps-field textarea:focus{border-color:#3784ef;box-shadow:0 0 0 3px rgba(37,99,235,.1);background:#fff}.ps-full{grid-column:1/-1}.ps-note{color:#6f839e;font-size:12px;line-height:1.5;margin:0 0 14px}.ps-table-wrap{overflow:auto}.ps-table{width:100%;border-collapse:separate;border-spacing:0;table-layout:fixed}.ps-table th,.ps-table td{border-bottom:1px solid #e8eef5;padding:11px 10px;vertical-align:top;font-size:12px}.ps-table th{background:#f7fbff;color:#55708f;text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:.03em}.ps-table th:nth-child(1){width:18%}.ps-table th:nth-child(2){width:42%}.ps-table th:nth-child(3){width:16%}.ps-table th:nth-child(4){width:24%}.ps-table td strong{color:#1f3d67;font-size:13px}.ps-table td .ps-input{width:100%;min-width:0;border:1.4px solid #d4e1ef;border-radius:10px;background:#fff;padding:10px 11px;box-sizing:border-box;font:inherit;color:#244160;outline:none}.ps-table td .ps-input:focus{border-color:#3b82f6;box-shadow:0 0 0 3px rgba(37,99,235,.08)}.ps-table td textarea.ps-input{min-height:72px;resize:vertical}.ps-select{appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='%23647792' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 10px center;background-size:14px;padding-right:32px!important}.ps-inspection{border:1px solid #dce7f3;border-radius:16px;background:#fff;overflow:hidden;margin-top:14px}.ps-inspection-head{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:13px 15px;background:linear-gradient(90deg,#eff6ff,#fdf2f8);border-bottom:1px solid #e4ebf5}.ps-inspection-head strong{color:#21466f;font-size:13px}.ps-inspection-body{padding:15px}.ps-inspection-grid{display:grid;grid-template-columns:160px 160px minmax(0,1fr);gap:12px;margin-bottom:14px}.ps-product-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}.ps-product{border:1px solid #dfe9f4;background:#fbfdff;border-radius:12px;padding:10px;min-width:0}.ps-product label{display:flex;align-items:center;justify-content:space-between;gap:10px;color:#55708f;font-size:11px;font-weight:800;min-width:0}.ps-product label span{min-width:0;flex:1}.ps-product select{width:112px;min-width:0;box-sizing:border-box;height:40px;border:1.5px solid #cfddec;border-radius:10px;background:#fbfdff;color:#203c60;padding:0 36px 0 11px;outline:none;font:inherit;appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='14' height='14' viewBox='0 0 24 24' fill='none' stroke='%23647792' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'%3E%3Cpath d='m6 9 6 6 6-6'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 11px center;background-size:14px;cursor:pointer}.ps-product select:hover{border-color:#b9cce4;background-color:#fff}.ps-product select:focus{border-color:#3784ef;box-shadow:0 0 0 3px rgba(37,99,235,.1);background-color:#fff}.ps-product select option{color:#203c60;font-weight:700}.ps-add{display:flex;justify-content:center;margin-top:14px}.ps-add button,.ps-remove{border:1px solid #cfe0f5;background:#fff;color:#2155a0;border-radius:11px;padding:10px 14px;font-weight:900;cursor:pointer}.ps-remove{color:#b91c1c;border-color:#fecaca;background:#fff5f5}.ps-actions{display:flex;justify-content:flex-end;gap:10px;padding:16px 20px;border-top:1px solid #e7eef5;background:#fbfdff}.ps-btn{min-height:44px;border:0;border-radius:12px;padding:11px 18px;font-weight:900;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;text-decoration:none}.ps-btn.secondary{background:#eef3fa;color:#4c5f78}.ps-btn.primary{background:linear-gradient(135deg,#286fe9,#c63d9e);color:#fff}.ps-alert{margin:0 20px 16px;padding:12px 14px;border:1px solid #fecaca;background:#fff1f2;color:#b91c1c;border-radius:12px;font-weight:700}.ps-shift-pill{display:inline-flex;padding:5px 10px;border-radius:999px;background:#edf5ff;color:#1d4ed8;font-size:11px;font-weight:900}
@media(max-width:900px){.ps-grid{grid-template-columns:1fr 1fr}.ps-inspection-grid{grid-template-columns:1fr 1fr}.ps-product-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:760px){.ps-product label{align-items:stretch}.ps-product select{width:100%;height:44px}.ps-head{align-items:flex-start;flex-direction:column}.ps-head h1{font-size:24px}.ps-grid{grid-template-columns:1fr}.ps-body{padding:14px}.ps-table-wrap{overflow:visible}.ps-table,.ps-table tbody,.ps-table tr,.ps-table td{display:block;width:100%;table-layout:auto}.ps-table thead{display:none}.ps-table tbody tr{border:1px solid #e0e8f2;border-radius:14px;margin-bottom:12px;padding:8px 10px;background:#fff}.ps-table td{display:grid;grid-template-columns:90px minmax(0,1fr);gap:8px;border:0;border-bottom:1px dashed #e9eef4;padding:8px 0}.ps-table td:last-child{border-bottom:0}.ps-table td::before{content:attr(data-label);color:#6b809a;font-size:10px;font-weight:900;text-transform:uppercase}.ps-inspection-grid{grid-template-columns:1fr}.ps-product-grid{grid-template-columns:1fr}.ps-actions{padding:12px 14px}.ps-actions .ps-btn{flex:1}.ps-product select{width:100%}}
</style>
<div class="ps-page">
  <div class="ps-head"><div><h1>Input Pre-Shift Checklist</h1><p>Checklist inspeksi produk dan temperature sesuai form Pre-Shift Checklist</p></div><a class="ps-btn secondary" href="datapreshiftchecklist.php">← Kembali</a></div>
  <?php if ($error !== ''): ?><div class="ps-alert"><?=e($error)?></div><?php endif; ?>
  <form method="post" id="preShiftForm">
    <input type="hidden" name="csrf" value="<?=e(csrf_token())?>">
    <section class="ps-card">
      <div class="ps-title">Informasi Checklist</div>
      <div class="ps-body">
        <div class="ps-grid">
          <label class="ps-field">Tanggal<input type="date" value="<?=e($today)?>" readonly></label>
          <label class="ps-field">Shift<select name="shift" required><option value="">Pilih Shift</option><?php foreach($shiftOptions as $s): ?><option value="<?=e($s)?>" <?=($oldShift===$s?'selected':'')?>><?=e($s)?></option><?php endforeach; ?></select></label>
          <label class="ps-field">Nama QC<select name="nama_qc" required><option value="">Pilih Nama QC</option><?php foreach($qcOptions as $q): ?><option value="<?=e($q)?>" <?=($oldQc===$q?'selected':'')?>><?=e($q)?></option><?php endforeach; ?></select></label>
        </div>
      </div>
    </section>

    <section class="ps-card">
      <div class="ps-title">Pengecekan Prosedure Inspeksi Produk</div>
      <div class="ps-body">
        <p class="ps-note">Lakukan pengecekan prosedure inspeksi produk yang akan disajikan kepada konsumen. Hasil diisi <strong>AC</strong> bila sesuai dan <strong>UN</strong> bila tidak sesuai.</p>
        <div class="ps-table-wrap"><table class="ps-table"><thead><tr><th>Procedure</th><th>Standard dan Critical Control Point</th><th>Hasil</th><th>Catatan</th></tr></thead><tbody>
        <?php foreach($procedures as $i=>$p): ?><tr>
          <td data-label="Procedure"><strong><?=e($p[0])?></strong></td>
          <td data-label="Standard dan Critical Control Point"><?=e($p[1])?></td>
          <td data-label="Hasil"><select class="ps-input ps-select" name="procedure_result[<?=$i?>]"><option value="">Pilih Hasil</option><option value="AC" <?=((($oldProcedures[$i]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($oldProcedures[$i]??'')==='UN')?'selected':'')?>>UN</option></select></td>
          <td data-label="Catatan"><textarea class="ps-input" name="procedure_note[<?=$i?>]" placeholder="Catatan dan langkah koreksi..."><?=e($oldNotes[$i]??'')?></textarea></td>
        </tr><?php endforeach; ?></tbody></table></div>
      </div>
    </section>

    <section class="ps-card">
      <div class="ps-title">Temperature Inspection</div>
      <div class="ps-body">
        <p class="ps-note">Lakukan pengecekan temperature produk setelah dimasak setiap satu jam sekali untuk masing-masing produk. Pengecekan realtime dilakukan sesaat setelah produk mencapai waktu yang ditentukan.</p>
        <div id="inspectionRows">
          <?php foreach((array)$oldInspections as $idx=>$row): $rProducts=(array)($row['produk']??[]); ?>
          <div class="ps-inspection" data-index="<?=$idx?>">
            <div class="ps-inspection-head"><strong>Jam Inspeksi <?=($idx+1)?></strong><button type="button" class="ps-remove" data-remove>Hapus Baris</button></div>
            <div class="ps-inspection-body">
              <div class="ps-inspection-grid">
                <label class="ps-field">Jam Inspeksi<select name="inspections[<?=$idx?>][jam]" required><option value="">Pilih Jam</option><?php foreach($timeOptions as $t): ?><option value="<?=e($t)?>" <?=((($row['jam']??'')===$t)?'selected':'')?>><?=e($t)?></option><?php endforeach; ?></select></label>
                <label class="ps-field">Nama QC<select name="inspections[<?=$idx?>][nama_qc]"><option value="">Pilih QC</option><?php foreach($qcOptions as $q): ?><option value="<?=e($q)?>" <?=((($row['nama_qc']??'')===$q)?'selected':'')?>><?=e($q)?></option><?php endforeach; ?></select></label>
                <label class="ps-field">Keterangan<textarea name="inspections[<?=$idx?>][keterangan]" placeholder="Catatan dan langkah koreksi..."><?=e($row['keterangan']??'')?></textarea></label>
              </div>
              <div class="ps-product-grid">
                <?php foreach($products as $product): $val=$rProducts[$product]??''; ?><div class="ps-product"><label><span><?=e($product)?></span><select name="inspections[<?=$idx?>][produk][<?=e($product)?>]" class="ps-input ps-select"><option value="">Pilih</option><option value="AC" <?=($val==='AC'?'selected':'')?>>AC</option><option value="UN" <?=($val==='UN'?'selected':'')?>>UN</option></select></label></div><?php endforeach; ?>
              </div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <div class="ps-add"><button type="button" id="addInspection">＋ Tambah Jam Inspeksi</button></div>
      </div>
    </section>

    <section class="ps-card">
      <div class="ps-title">Feedback</div>
      <div class="ps-body"><label class="ps-field">Feedback / Catatan Shift<textarea name="feedback" placeholder="Tuliskan feedback atau langkah koreksi shift..."><?=e($oldFeedback)?></textarea></label></div>
      <div class="ps-actions"><a class="ps-btn secondary" href="datapreshiftchecklist.php">Batal</a><button class="ps-btn primary" type="submit">Simpan Data</button></div>
    </section>
  </form>
</div>
<script>
const times = <?=json_encode($timeOptions,JSON_UNESCAPED_UNICODE)?>;
const qcs = <?=json_encode($qcOptions,JSON_UNESCAPED_UNICODE)?>;
const products = <?=json_encode($products,JSON_UNESCAPED_UNICODE)?>;
const container=document.getElementById('inspectionRows');
function options(list, placeholder){ return '<option value="">'+placeholder+'</option>'+list.map(v=>'<option value="'+v.replace(/"/g,'&quot;')+'">'+v+'</option>').join(''); }
function productCard(i,p){return '<div class="ps-product"><label><span>'+p+'</span><select name="inspections['+i+'][produk]['+p.replace(/([\\'])/g,'\\$1')+']" class="ps-input ps-select"><option value="">Pilih</option><option value="AC">AC</option><option value="UN">UN</option></select></label></div>';}
function addRow(){const i=container.querySelectorAll('.ps-inspection').length; const el=document.createElement('div'); el.className='ps-inspection'; el.dataset.index=i; el.innerHTML='<div class="ps-inspection-head"><strong>Jam Inspeksi '+(i+1)+'</strong><button type="button" class="ps-remove" data-remove>Hapus Baris</button></div><div class="ps-inspection-body"><div class="ps-inspection-grid"><label class="ps-field">Jam Inspeksi<select name="inspections['+i+'][jam]" required>'+options(times,'Pilih Jam')+'</select></label><label class="ps-field">Nama QC<select name="inspections['+i+'][nama_qc]">'+options(qcs,'Pilih QC')+'</select></label><label class="ps-field">Keterangan<textarea name="inspections['+i+'][keterangan]" placeholder="Catatan dan langkah koreksi..."></textarea></label></div><div class="ps-product-grid">'+products.map(p=>productCard(i,p)).join('')+'</div></div>'; container.appendChild(el); }
document.getElementById('addInspection').addEventListener('click',addRow);
container.addEventListener('click',e=>{const b=e.target.closest('[data-remove]'); if(!b)return; const rows=container.querySelectorAll('.ps-inspection'); if(rows.length<=1){alert('Minimal satu baris inspeksi harus tersedia.');return;} b.closest('.ps-inspection').remove(); [...container.querySelectorAll('.ps-inspection')].forEach((el,i)=>el.querySelector('.ps-inspection-head strong').textContent='Jam Inspeksi '+(i+1));});
</script>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
