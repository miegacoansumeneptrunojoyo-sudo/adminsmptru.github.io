<?php
require_once __DIR__ . '/../../config.php';
$pageTitle = 'Prepare Phase';
$pdo = db();
$selectedDate = trim((string)($_GET['date'] ?? date('Y-m-d')));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate)) $selectedDate = date('Y-m-d');
$rows = [];
try {
  $pdo->exec("CREATE TABLE IF NOT EXISTS prepare_phase (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        tanggal DATE NOT NULL,
        opening_qc VARCHAR(50) NOT NULL,
        middle_qc VARCHAR(50) NOT NULL,
        closing_qc VARCHAR(50) NOT NULL,
        procedures_json LONGTEXT NOT NULL,
        inspections_json LONGTEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_prepare_tanggal (tanggal)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  $st = $pdo->prepare('SELECT * FROM prepare_phase WHERE tanggal = ? ORDER BY id DESC');
  $st->execute([$selectedDate]);
  $rows = $st->fetchAll();
  foreach ($rows as &$row) {
    $row['procedures'] = json_decode((string)$row['procedures_json'], true) ?: [];
    $row['inspections'] = json_decode((string)$row['inspections_json'], true) ?: [];
  }
  unset($row);
} catch (Throwable $e) {
  $rows = [];
  flash('error', 'Data Prepare Phase belum dapat dibaca: ' . $e->getMessage());
}
require __DIR__ . '/../../includes/header.php';
function pp_h2(string $v): string
{
  return htmlspecialchars($v, ENT_QUOTES, 'UTF-8');
}
?>
<style>
  .prepare-data-empty {
    min-height: 168px;
    display: grid;
    place-items: center;
    text-align: center
  }

  .prepare-data-empty strong {
    font-size: 18px
  }

  .prepare-data-empty p {
    margin: 8px 0 0;
    color: #6c829d
  }

  .prepare-data-card {
    overflow: hidden
  }

  .prepare-data-card .card-head {
    padding: 16px 20px;
    background: linear-gradient(90deg, #eef6ff, #fff5fb);
    border-bottom: 1px solid #e7edf5;
    display: flex;
    justify-content: space-between;
    gap: 12px;
    align-items: center
  }

  .prepare-data-card .card-head strong {
    font-size: 14px
  }

  .prepare-data-card .card-head span {
    font-size: 12px;
    color: #6c829d;
    font-weight: 800
  }

  .prepare-data-card .card-body {
    padding: 18px 20px
  }

  .prepare-mini-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 12px;
    margin-bottom: 18px
  }

  .prepare-mini {
    border: 1px solid #dfE8f3;
    border-radius: 12px;
    padding: 12px;
    background: #fbfdff
  }

  .prepare-mini small {
    display: block;
    color: #6a829e;
    font-size: 10px;
    font-weight: 900;
    text-transform: uppercase
  }

  .prepare-mini strong {
    display: block;
    margin-top: 5px
  }

  .prepare-data-card h4 {
    margin: 18px 0 10px;
    font-size: 14px;
    color: #20456f
  }

  .prepare-data-table {
    width: 100%;
    border-collapse: collapse
  }

  .prepare-data-table th,
  .prepare-data-table td {
    padding: 10px;
    border-bottom: 1px solid #edf2f7;
    font-size: 12px;
    text-align: left;
    vertical-align: top
  }

  .prepare-data-table th {
    background: #f8fbff;
    color: #5e7691
  }

  .status-chip {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 44px;
    padding: 5px 8px;
    border-radius: 999px;
    font-size: 10px;
    font-weight: 900
  }

  .status-chip.ac {
    background: #dcfce7;
    color: #166534
  }

  .status-chip.un {
    background: #fee2e2;
    color: #b91c1c
  }

  .status-chip.na {
    background: #f1f5f9;
    color: #64748b
  }

  .inspection-block {
    border: 1px solid #e2eaf4;
    border-radius: 12px;
    overflow: auto
  }

  .inspection-data-table {
    min-width: 1000px;
    width: 100%;
    border-collapse: collapse
  }

  .inspection-data-table th,
  .inspection-data-table td {
    padding: 8px;
    border-bottom: 1px solid #edf2f7;
    font-size: 11px;
    text-align: center
  }

  .inspection-data-table th {
    background: #f8fbff;
    color: #5e7691
  }

  .inspection-data-table th:first-child,
  .inspection-data-table td:first-child,
  .inspection-data-table th:nth-child(2),
  .inspection-data-table td:nth-child(2),
  .inspection-data-table th:last-child,
  .inspection-data-table td:last-child {
    text-align: left
  }

  @media(max-width:760px) {
    .prepare-mini-grid {
      grid-template-columns: 1fr
    }

    .prepare-data-card .card-head {
      align-items: flex-start;
      flex-direction: column
    }

    .prepare-data-card .card-body {
      padding: 14px
    }

    .prepare-data-table thead {
      display: none
    }

    .prepare-data-table,
    .prepare-data-table tbody,
    .prepare-data-table tr,
    .prepare-data-table td {
      display: block;
      width: 100%
    }

    .prepare-data-table tr {
      border: 1px solid #e5edf6;
      border-radius: 12px;
      margin-bottom: 9px;
      padding: 8px
    }

    .prepare-data-table td {
      border: 0;
      border-bottom: 1px dashed #edf2f7;
      padding: 7px 0
    }

    .prepare-data-table td:last-child {
      border-bottom: 0
    }

    .prepare-data-table td::before {
      display: block;
      color: #6a819d;
      font-size: 9px;
      font-weight: 900;
      text-transform: uppercase;
      margin-bottom: 3px
    }

    .prepare-data-table td:nth-child(1)::before {
      content: 'Procedure'
    }

    .prepare-data-table td:nth-child(2)::before {
      content: 'Standard'
    }

    .prepare-data-table td:nth-child(3)::before {
      content: 'Hasil'
    }

    .prepare-data-table td:nth-child(4)::before {
      content: 'Catatan'
    }
  }
</style>
<div class="page-head">
  <div>
    <h2>Data Prepare Phase</h2>
  </div>
  <div class="page-actions" style="align-items:center">
    <a class="btn-action back" href="../../qualitycontrol.php">← Kembali</a>
    <form method="get" style="display:flex;gap:8px;align-items:center">
      <input type="date" name="date" value="<?= pp_h2($selectedDate) ?>" style="min-height:42px;padding:10px 12px;border:1px solid #d7e3f4;border-radius:11px;background:#fff;color:#172554;font-weight:700">
      <button class="btn-action primary" type="submit">Tampilkan</button>
    </form>
    <a class="btn-action primary" href="inputpreparephase.php">＋ Input Data</a>
  </div>
</div>
<?php if (!$rows): ?>
  <section class="panel prepare-data-empty">
    <div><strong>Belum ada data Prepare Phase</strong>
    </div>
  </section>
<?php else: ?>
  <div style="display:grid;gap:16px">
    <?php foreach ($rows as $row): ?>
      <section class="panel prepare-data-card">
        <div class="card-head"><strong>Prepare Phase — <?= pp_h2(date('d/m/Y', strtotime($row['tanggal']))) ?></strong><span>QC Incharge: Opening <?= pp_h2($row['opening_qc']) ?> • Middle <?= pp_h2($row['middle_qc']) ?> • Closing <?= pp_h2($row['closing_qc']) ?></span></div>
        <div class="card-body">
          <h4>QC Incharge</h4>
          <div class="prepare-mini-grid">
            <div class="prepare-mini"><small>Opening</small><strong><?= pp_h2($row['opening_qc']) ?></strong></div>
            <div class="prepare-mini"><small>Middle</small><strong><?= pp_h2($row['middle_qc']) ?></strong></div>
            <div class="prepare-mini"><small>Closing</small><strong><?= pp_h2($row['closing_qc']) ?></strong></div>
          </div>
          <h4>Pengecekan Prosedure</h4>
          <div class="table-wrap">
            <table class="prepare-data-table">
              <thead>
                <tr>
                  <th>Procedure</th>
                  <th>Standard</th>
                  <th>Hasil</th>
                  <th>Catatan</th>
                </tr>
              </thead>
              <tbody>
                <?php foreach ($row['procedures'] as $p): ?><tr>
                    <td><?= pp_h2((string)$p['produk']) ?></td>
                    <td><?= pp_h2((string)$p['standard']) ?></td>
                    <td><span class="status-chip <?= strtolower((string)$p['hasil']) === 'ac' ? 'ac' : (strtolower((string)$p['hasil']) === 'un' ? 'un' : 'na') ?>"><?= pp_h2((string)($p['hasil'] ?: '—')) ?></span></td>
                    <td><?= pp_h2((string)($p['catatan'] ?: '-')) ?></td>
                  </tr><?php endforeach; ?></tbody>
            </table>
          </div>
          <h4>Temperature Inspection</h4>
          <?php if (!$row['inspections']): ?><p class="prepare-note">Belum ada jam inspeksi yang dicatat.</p><?php else: ?>
            <div class="inspection-block">
              <table class="inspection-data-table">
                <thead>
                  <tr>
                    <th>Jam</th>
                    <th>Nama QC</th><?php foreach (['Mie Thawingan', 'Kulit Pangsit', 'Adonan Pangsit', 'Surai Naga', 'Pentol Thawing', 'Siomay', 'Cabe', 'Belimbing', 'Strawberry'] as $p): ?><th><?= pp_h2($p) ?></th><?php endforeach; ?><th>Keterangan</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($row['inspections'] as $in): ?>
                    <tr>
                      <td><?= pp_h2((string)$in['jam']) ?></td>
                      <td><?= pp_h2((string)$in['qc']) ?></td>
                      <?php foreach (['Mie Thawingan', 'Kulit Pangsit', 'Adonan Pangsit', 'Surai Naga', 'Pentol Thawing', 'Siomay', 'Cabe', 'Belimbing', 'Strawberry'] as $p): ?>
                        <?php $v = (string)($in['hasil'][$p] ?? '');
                                                                                                                  $cls = strtolower($v) === 'ac' ? 'ac' : (strtolower($v) === 'un' ? 'un' : 'na'); ?>
                        <td><span class="status-chip <?= $cls ?>"><?= pp_h2($v ?: '—') ?></span></td>
                      <?php endforeach; ?>
                      <td style="text-align:left"><?= pp_h2((string)($in['catatan'] ?: '-')) ?></td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php endif; ?>
        </div>
      </section>
    <?php endforeach; ?>
  </div>
<?php endif; ?>
<?php require __DIR__ . '/../../includes/footer.php'; ?>