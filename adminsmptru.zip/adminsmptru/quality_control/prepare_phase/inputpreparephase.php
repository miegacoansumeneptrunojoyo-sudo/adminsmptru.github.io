<?php
require_once __DIR__ . '/../../config.php';
$pageTitle = 'Prepare Phase';
$pdo = db();

$products = [
    ['Kulit Pangsit', 'Tidak berbau, tidak lengket, ukuran 12 x 12cm, perlembar 13 gr - 17 gr (66 lembar/kg)'],
    ['Pentol Thawing', 'Suhu 0-4 derajat, berat 25gr/pcs, berat total 600 gr (berat yang dapat ditoleransi 588-612gr per pack). tidak berair / tidak berlendir'],
    ['Mie Thawing', 'Suhu 0-4 derajat, Random sampling, berat 80-90 gr, diameter 1,5-1,6mm, panjang 30-35 cm'],
    ['Cabe Merah', 'Cabe yang telah melalui proses perendaman, tidak berulat, tidak busuk, 85% cabai merah'],
    ['Belimbing', 'Warna hijau kekuningan, tidak busuk, 1 kg 4-5 biji'],
    ['Strawberry', 'sudah melalui proses perendaman, kondisi fresh, tidak busuk, tekstur tidak lembek, tidak terdapat ulat'],
    ['Siomay', 'Berat 30gr /pcs, berat yang dapat di toleransi 705 gr - 735 gr, tampilan bagus, kulit tidak mengelupas, tidak menempel, jamur tidak terlihat'],
    ['Adonan Pangsit', 'Tidak berair, Tidak bocor, Tidak menggelembung, Tidak berbuih'],
    ['Surai Naga', 'Tidak Berbau, Tidak Lengket,'],
];
$inspectionProducts = ['Mie Thawingan', 'Kulit Pangsit', 'Adonan Pangsit', 'Surai Naga', 'Pentol Thawing', 'Siomay', 'Cabe', 'Belimbing', 'Strawberry'];
$qcs = ['Luluk', 'Ega', 'Atika'];

function pp_h(string $v): void { echo htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    $tanggal = trim((string)($_POST['tanggal'] ?? date('Y-m-d')));
    $opening = trim((string)($_POST['opening'] ?? ''));
    $middle = trim((string)($_POST['middle'] ?? ''));
    $closing = trim((string)($_POST['closing'] ?? ''));

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal)) $tanggal = date('Y-m-d');
    if (!in_array($opening, $qcs, true) || !in_array($middle, $qcs, true) || !in_array($closing, $qcs, true)) {
        flash('error', 'QC Opening, Middle, dan Closing wajib dipilih.');
        redirect('inputpreparephase.php');
    }

    $proc = [];
    foreach ($products as $i => [$name, $standard]) {
        $proc[] = [
            'produk' => $name,
            'standard' => $standard,
            'hasil' => trim((string)($_POST['proc_hasil'][$i] ?? '')),
            'catatan' => trim((string)($_POST['proc_catatan'][$i] ?? '')),
        ];
    }

    $inspections = [];
    $jam = $_POST['inspeksi_jam'] ?? [];
    $namaQc = $_POST['inspeksi_qc'] ?? [];
    $catatan = $_POST['inspeksi_catatan'] ?? [];
    $hasil = $_POST['inspeksi_hasil'] ?? [];
    $rows = max(count($jam), count($namaQc), count($catatan), 1);
    for ($r = 0; $r < $rows; $r++) {
        $row = [
            'jam' => trim((string)($jam[$r] ?? '')),
            'qc' => trim((string)($namaQc[$r] ?? '')),
            'hasil' => [],
            'catatan' => trim((string)($catatan[$r] ?? '')),
        ];
        foreach ($inspectionProducts as $pIndex => $product) {
            $row['hasil'][$product] = trim((string)($hasil[$r][$pIndex] ?? ''));
        }
        if ($row['jam'] !== '' || $row['qc'] !== '' || $row['catatan'] !== '' || array_filter($row['hasil'])) {
            $inspections[] = $row;
        }
    }

    $pdo->beginTransaction();
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS prepare_phase (
            id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
            tanggal DATE NOT NULL,
            opening_qc VARCHAR(50) NOT NULL,
            middle_qc VARCHAR(50) NOT NULL,
            closing_qc VARCHAR(50) NOT NULL,
            procedures_json LONGTEXT NOT NULL,
            inspections_json LONGTEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX idx_prepare_tanggal (tanggal)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        $stmt = $pdo->prepare('INSERT INTO prepare_phase (tanggal, opening_qc, middle_qc, closing_qc, procedures_json, inspections_json) VALUES (?,?,?,?,?,?)');
        $stmt->execute([$tanggal, $opening, $middle, $closing, json_encode($proc, JSON_UNESCAPED_UNICODE), json_encode($inspections, JSON_UNESCAPED_UNICODE)]);
        $pdo->commit();
        flash('success', 'Prepare Phase berhasil disimpan.');
        redirect('datapreparephase.php?date=' . urlencode($tanggal));
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('error', 'Gagal menyimpan data: ' . $e->getMessage());
        redirect('inputpreparephase.php');
    }
}

require __DIR__ . '/../../includes/header.php';
$today = date('Y-m-d');
?>
<style>
.prepare-form,.prepare-form .panel,.prepare-section-body,.prepare-top-grid,.prepare-table-wrap,.inspection-list{width:100%;max-width:100%;min-width:0;box-sizing:border-box}
.prepare-form{display:grid;gap:18px;overflow:hidden}
.prepare-info{padding:0;overflow:hidden}
.prepare-section-title{padding:15px 20px;color:#fff;font-weight:800;background:linear-gradient(90deg,#1677e8,#2563eb);box-sizing:border-box}
.prepare-section-body{padding:20px}
.prepare-top-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}
.prepare-field label,.prepare-label{display:block;font-size:12px;font-weight:800;color:#46617f;margin-bottom:7px}
.prepare-field input,.prepare-field select,.prepare-field textarea,
.prepare-table input,.prepare-table select,.prepare-table textarea,.prepare-inspection-card input,.prepare-inspection-card select,.prepare-inspection-card textarea{
  width:100%;min-height:44px;border:1px solid #d5e2f1;border-radius:12px;padding:10px 13px;background:#fff;color:#172554;font:inherit;outline:none;box-sizing:border-box;min-width:0
}
.prepare-field input:focus,.prepare-field select:focus,.prepare-field textarea:focus,.prepare-table input:focus,.prepare-table select:focus,.prepare-inspection-card input:focus,.prepare-inspection-card select:focus,.prepare-inspection-card textarea:focus{border-color:#73a9ff;box-shadow:0 0 0 3px rgba(37,99,235,.1)}
.prepare-field input[readonly]{background:#f6f9fd;color:#355579;font-weight:700}
.prepare-field select,.prepare-table select,.prepare-table textarea,.prepare-inspection-card select{appearance:none;-webkit-appearance:none;background-image:linear-gradient(45deg,transparent 50%,#62809f 50%),linear-gradient(135deg,#62809f 50%,transparent 50%);background-position:calc(100% - 17px) 19px,calc(100% - 12px) 19px;background-size:5px 5px,5px 5px;background-repeat:no-repeat;padding-right:38px}
.prepare-note{margin:0;color:#70839c;font-size:12px;line-height:1.55}
.prepare-table-wrap{overflow:hidden;border:1px solid #e2eaf4;border-radius:16px}
.prepare-table{width:100%;max-width:100%;border-collapse:collapse;table-layout:fixed}
.prepare-table th,.prepare-table td{padding:12px;border-bottom:1px solid #edf2f7;vertical-align:top;overflow-wrap:anywhere}
.prepare-table th{font-size:11px;text-transform:uppercase;letter-spacing:.03em;color:#5e7896;background:#f8fbff;text-align:left}
.prepare-table th:nth-child(1),.prepare-table td:first-child{width:18%;font-weight:800;color:#1f4672}
.prepare-table th:nth-child(2),.prepare-table td:nth-child(2){width:52%;color:#5e738e;font-size:12px;line-height:1.5}
.prepare-table th:nth-child(3),.prepare-table td:nth-child(3){width:30%}
.prepare-result-select{width:100%;min-width:0}
.inspection-head{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:10px}
.inspection-head h3{margin:0;font-size:16px}
.inspection-grid{display:grid;grid-template-columns:145px 180px minmax(0,1fr);gap:12px;align-items:end}
.prepare-product-box{border:1px solid #e1e9f4;border-radius:14px;background:#fff;overflow:hidden;margin-bottom:14px}
.prepare-product-box .box-head{display:flex;justify-content:space-between;align-items:center;padding:14px 16px;background:linear-gradient(135deg,#eef6ff,#fff5fb);border-bottom:1px solid #e8eef6}
.prepare-product-box .box-head strong{font-size:14px;color:#1f4672}
.prepare-product-box .box-head span{font-size:11px;font-weight:800;color:#66809e}
.inspection-list{display:grid;gap:12px}
.inspection-row{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;padding:14px;border:1px solid #e2eaf4;border-radius:16px;background:#fff;box-sizing:border-box;min-width:0}
.inspection-row.head{display:none}
.inspection-field{min-width:0}
.inspection-field.wide{grid-column:span 2}
.inspection-field.full{grid-column:1/-1}
.inspection-field label{display:block;margin:0 0 6px;font-size:10px;font-weight:900;text-transform:uppercase;letter-spacing:.03em;color:#657e9c}
.inspection-field input,.inspection-field select,.inspection-field textarea{width:100%;min-width:0;box-sizing:border-box;min-height:44px;border:1px solid #d5e2f1;border-radius:12px;padding:10px 12px;background:#fff;color:#172554;font:inherit;outline:none}
.inspection-field textarea{min-height:84px;resize:vertical}
.inspection-field input:focus,.inspection-field select:focus,.inspection-field textarea:focus{border-color:#73a9ff;box-shadow:0 0 0 3px rgba(37,99,235,.1)}
.inspection-field select{appearance:none;-webkit-appearance:none;background-image:linear-gradient(45deg,transparent 50%,#62809f 50%),linear-gradient(135deg,#62809f 50%,transparent 50%);background-position:calc(100% - 17px) 19px,calc(100% - 12px) 19px;background-size:5px 5px,5px 5px;background-repeat:no-repeat;padding-right:38px}
.inspection-products{grid-column:1/-1;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;min-width:0}
.inspection-product{border:1px solid #e4ebf4;border-radius:12px;padding:10px;background:#f8fbff;min-width:0}
.inspection-product label{display:block;font-size:10px;font-weight:800;color:#46617f;margin-bottom:6px;line-height:1.35}
.inspection-product select{width:100%;min-width:0;min-height:40px;box-sizing:border-box;border:1px solid #d5e2f1;border-radius:12px;padding:9px 38px 9px 12px;background-color:#fff;color:#172554;font:inherit;outline:none;appearance:none;-webkit-appearance:none;background-image:linear-gradient(45deg,transparent 50%,#62809f 50%),linear-gradient(135deg,#62809f 50%,transparent 50%);background-position:calc(100% - 17px) 17px,calc(100% - 12px) 17px;background-size:5px 5px,5px 5px;background-repeat:no-repeat}
.inspection-product select:focus{border-color:#73a9ff;box-shadow:0 0 0 3px rgba(37,99,235,.1)}
.inspection-remove{align-self:end;width:100%;min-height:44px;border:1px solid #fecdd3;background:#fff1f2;color:#be123c;border-radius:10px;cursor:pointer;font-weight:900}
.btn-add-row{border:1px solid #bfd6fb;background:#eff6ff;color:#1d4ed8}
.btn-submit{border:0;border-radius:12px;background:linear-gradient(90deg,#2563eb,#ec4899);color:#fff;padding:13px 20px;font-weight:800;cursor:pointer}
.prepare-actions{display:flex;justify-content:flex-end;gap:10px}
@media(max-width:1100px){.prepare-top-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.inspection-row{grid-template-columns:repeat(2,minmax(0,1fr))}.inspection-field.wide{grid-column:span 2}.inspection-products{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:760px){.prepare-top-grid,.inspection-grid{grid-template-columns:1fr}.prepare-section-body{padding:14px}.prepare-page-head .page-actions{width:auto;display:flex}.prepare-page-head .btn-action{min-width:120px}.prepare-product-box .box-head{align-items:flex-start;flex-direction:column;gap:4px}.prepare-table-wrap{overflow:visible;border:0}.prepare-table thead{display:none}.prepare-table,.prepare-table tbody,.prepare-table tr,.prepare-table td{display:block;width:100%}.prepare-table tr{border:1px solid #e3ebf5;border-radius:14px;margin-bottom:10px;padding:10px;box-sizing:border-box}.prepare-table td{padding:8px 0;border-bottom:1px dashed #edf2f7}.prepare-table td:last-child{border-bottom:0}.prepare-table td::before{display:block;color:#6a819d;font-size:10px;font-weight:900;text-transform:uppercase;margin-bottom:5px}.prepare-table td:nth-child(1)::before{content:'Procedure'}.prepare-table td:nth-child(2)::before{content:'Standard dan Critical Control Point'}.prepare-table td:nth-child(3)::before{content:'Hasil & Catatan'}.prepare-table td:first-child,.prepare-table td:nth-child(2),.prepare-table td:nth-child(3){width:auto}.inspection-row{grid-template-columns:1fr;padding:12px}.inspection-field.wide,.inspection-field.full{grid-column:auto}.inspection-products{grid-template-columns:1fr}.inspection-remove{width:100%}.prepare-actions{display:grid;grid-template-columns:1fr}.prepare-actions .btn-action,.prepare-actions .btn-submit{width:100%}}
</style>

<div class="page-head prepare-page-head">
  <div><h2>Input Prepare Phase</h2><p>Checklist prepare phase • prosedur pemasakan dan temperature inspection</p></div>
  <div class="page-actions"><a class="btn-action back" href="datapreparephase.php">← Kembali</a></div>
</div>

<form method="post" class="prepare-form">
  <input type="hidden" name="csrf" value="<?=htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8')?>">
  <section class="panel prepare-info">
    <div class="prepare-section-title">Informasi Prepare Phase</div>
    <div class="prepare-section-body">
      <div class="prepare-top-grid">
        <div class="prepare-field"><label>Tanggal</label><input type="date" name="tanggal" value="<?=$today?>" readonly></div>
        <div class="prepare-field"><label>Opening</label><select name="opening" required><option value="">Pilih QC Opening</option><?php foreach($qcs as $qc): ?><option value="<?=htmlspecialchars($qc,ENT_QUOTES,'UTF-8')?>"><?=htmlspecialchars($qc)?></option><?php endforeach; ?></select></div>
        <div class="prepare-field"><label>Middle</label><select name="middle" required><option value="">Pilih QC Middle</option><?php foreach($qcs as $qc): ?><option value="<?=htmlspecialchars($qc,ENT_QUOTES,'UTF-8')?>"><?=htmlspecialchars($qc)?></option><?php endforeach; ?></select></div>
        <div class="prepare-field"><label>Closing</label><select name="closing" required><option value="">Pilih QC Closing</option><?php foreach($qcs as $qc): ?><option value="<?=htmlspecialchars($qc,ENT_QUOTES,'UTF-8')?>"><?=htmlspecialchars($qc)?></option><?php endforeach; ?></select></div>
      </div>
      <p class="prepare-note" style="margin-top:12px">Form diisi oleh Quality Control. QC Incharge untuk Opening, Middle, dan Closing dipilih dari Luluk, Ega, atau Atika.</p>
    </div>
  </section>

  <section class="panel">
    <div class="prepare-section-title">Pengecekan Prosedure Pemasakan dan Temperature Inspection</div>
    <div class="prepare-section-body">
      <p class="prepare-note" style="margin-bottom:12px">Pastikan petugas mengetahui dan dapat membedakan standard temperature produk cooking, frying, boiling, dan warming sesuai standard food safety.</p>
      <div class="prepare-table-wrap">
        <table class="prepare-table">
          <thead><tr><th>Procedure</th><th>Standard dan Critical Control Point</th><th>Hasil & Catatan</th></tr></thead>
          <tbody>
          <?php foreach($products as $i => [$name,$standard]): ?>
            <tr>
              <td><?=htmlspecialchars($name)?></td>
              <td><?=htmlspecialchars($standard)?></td>
              <td>
                <select name="proc_hasil[<?=$i?>]" class="prepare-result-select" required>
                  <option value="">Pilih Hasil</option><option value="AC">AC</option><option value="UN">UN</option>
                </select>
                <textarea name="proc_catatan[<?=$i?>]" rows="2" style="margin-top:7px" placeholder="Catatan inspeksi..."></textarea>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </section>

  <section class="panel">
    <div class="prepare-section-title">Temperature Inspection</div>
    <div class="prepare-section-body">
      <p class="prepare-note" style="margin-bottom:12px">Lakukan pengecekan temperature produk setelah dimasak setiap satu jam sekali untuk masing-masing produk. Tambahkan baris sesuai jam inspeksi yang dilakukan.</p>
      <div id="inspectionRows" class="inspection-list"></div>
      <div style="margin-top:10px"><button type="button" class="btn-action btn-add-row" id="addInspection">＋ Tambah Jam Inspeksi</button></div>
    </div>
  </section>

  <div class="prepare-actions">
    <a class="btn-action back" href="datapreparephase.php">Batal</a>
    <button type="submit" class="btn-submit">Simpan Data Prepare Phase</button>
  </div>
</form>

<template id="inspectionTemplate">
  <div class="inspection-row">
    <div class="inspection-field">
      <label>Jam Inspeksi</label>
      <input type="time" name="inspeksi_jam[]" aria-label="Jam Inspeksi">
    </div>
    <div class="inspection-field">
      <label>Nama QC</label>
      <select name="inspeksi_qc[]" aria-label="Nama QC"><option value="">Pilih QC</option><?php foreach($qcs as $qc): ?><option value="<?=htmlspecialchars($qc,ENT_QUOTES,'UTF-8')?>"><?=htmlspecialchars($qc)?></option><?php endforeach; ?></select>
    </div>
    <div class="inspection-field wide">
      <label>Keterangan</label>
      <textarea name="inspeksi_catatan[]" rows="2" placeholder="Catatan & langkah koreksi"></textarea>
    </div>
    <div class="inspection-products">
      <?php foreach($inspectionProducts as $i=>$product): ?>
      <div class="inspection-product">
        <label><?=htmlspecialchars($product)?></label>
        <select name="inspeksi_hasil[ROW][<?=$i?>]" aria-label="<?=htmlspecialchars($product)?>"><option value="">Pilih</option><option value="AC">AC</option><option value="UN">UN</option></select>
      </div>
      <?php endforeach; ?>
    </div>
    <div class="inspection-field">
      <label>&nbsp;</label>
      <button type="button" class="inspection-remove" title="Hapus baris">Hapus Baris</button>
    </div>
  </div>
</template>
<script>
(() => {
  const wrap = document.getElementById('inspectionRows');
  const tpl = document.getElementById('inspectionTemplate').innerHTML;
  const add = document.getElementById('addInspection');
  let idx = 0;
  function addRow(){
    const html = tpl.replaceAll('ROW', String(idx++));
    wrap.insertAdjacentHTML('beforeend', html);
    const rows = wrap.querySelectorAll('.inspection-row');
    rows[rows.length-1].querySelector('.inspection-remove').addEventListener('click', e => e.currentTarget.closest('.inspection-row').remove());
  }
  addRow();
  add.addEventListener('click', addRow);
})();
</script>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
