<?php

declare(strict_types=1);

require_once __DIR__ . '/../../config.php';

$pageTitle = 'Data Product Inspection';
$pdo = db();

$productNames = [
    'Siomay Ayam',
    'Udang Rambutan',
    'Udang Keju',
    'Lumpia Udang',
    'Mie Gacoan',
    'Mie Hompimpa',
    'Pangsit Goreng',
    'Beverages & Es buah'
];

$selectedDate = trim((string)($_GET['date'] ?? date('Y-m-d')));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate)) {
    $selectedDate = date('Y-m-d');
}

function pi_data_ensure_schema(PDO $pdo): void
{
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `product_inspection` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `tanggal` DATE NOT NULL,
            `shift` VARCHAR(30) NOT NULL DEFAULT '',
            `nama_qc` VARCHAR(50) NOT NULL DEFAULT '',
            `qc_opening` VARCHAR(50) NOT NULL DEFAULT '',
            `qc_middle` VARCHAR(50) NOT NULL DEFAULT '',
            `qc_closing` VARCHAR(50) NOT NULL DEFAULT '',
            `procedures_json` LONGTEXT NOT NULL,
            `inspections_json` LONGTEXT NOT NULL,
            `feedback_json` LONGTEXT NOT NULL,
            `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_product_inspection_tanggal` (`tanggal`),
            KEY `idx_product_inspection_shift` (`shift`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );
}

pi_data_ensure_schema($pdo);

function pi_h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function pi_result_chip(string $value): string
{
    $v = strtoupper(trim($value));
    return match ($v) {
        'AC', '√' => 'ac',
        'UN', 'X' => 'un',
        default => 'na',
    };
}

function pi_result_label(string $value): string
{
    $v = trim($value);
    return match ($v) {
        '√' => '✓ Layak',
        'X' => '✕ Tidak',
        'AC' => 'AC',
        'UN' => 'UN',
        default => '—',
    };
}

$rows = [];

try {
    $st = $pdo->prepare('SELECT * FROM product_inspection WHERE tanggal = ? ORDER BY id DESC');
    $st->execute([$selectedDate]);
    $rows = $st->fetchAll();

    foreach ($rows as &$row) {
        $row['procedures'] = json_decode((string)($row['procedures_json'] ?? ''), true) ?: [];
        $row['inspections'] = json_decode((string)($row['inspections_json'] ?? ''), true) ?: [];
        $row['feedback'] = json_decode((string)($row['feedback_json'] ?? ''), true) ?: [];

        // Normalize older records.
        $legacyShift = '';
        if (trim((string)($row['shift'] ?? '')) !== '') {
            $legacyShift = (string)$row['shift'];
        } elseif (trim((string)($row['qc_opening'] ?? '')) !== '') {
            $legacyShift = 'Prepare';
        } elseif (trim((string)($row['qc_middle'] ?? '')) !== '') {
            $legacyShift = 'Middle';
        } elseif (trim((string)($row['qc_closing'] ?? '')) !== '') {
            $legacyShift = 'Closing';
        }
        $row['shift'] = $legacyShift !== '' ? $legacyShift : '-';

        if (trim((string)($row['nama_qc'] ?? '')) === '') {
            $row['nama_qc'] =
                trim((string)($row['qc_opening'] ?? '')) ?: (trim((string)($row['qc_middle'] ?? '')) ?: (trim((string)($row['qc_closing'] ?? '')) ?:
                        '-'));
        }

        // Older versions stored "Pagi"; show it as Prepare.
        if (isset($row['feedback']['Pagi']) && !isset($row['feedback']['Prepare'])) {
            $row['feedback']['Prepare'] = $row['feedback']['Pagi'];
        }
    }
    unset($row);
} catch (Throwable $e) {
    $rows = [];
    flash('error', 'Data Product Inspection belum dapat dibaca: ' . $e->getMessage());
}

require __DIR__ . '/../../includes/header.php';
?>
<style>
    .pi-data {
        max-width: 1200px;
        margin: 0 auto;
        padding-bottom: 28px
    }

    .pi-data-head {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        margin-bottom: 18px
    }

    .pi-data-head h2 {
        margin: 0;
        color: #133f78;
        font-size: 28px;
        font-weight: 900
    }

    .pi-actions-top {
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap
    }

    .pi-top-btn {
        min-height: 42px;
        padding: 0 15px;
        border: 1px solid #d7e2ef;
        border-radius: 11px;
        background: #fff;
        color: #2b5a8d;
        font-weight: 800;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        justify-content: center
    }

    .pi-top-btn.primary {
        background: linear-gradient(100deg, #1678ed, #f04f9b);
        border-color: transparent;
        color: #fff
    }

    .pi-date {
        height: 42px;
        border: 1px solid #d7e2ef;
        border-radius: 11px;
        background: #fff;
        padding: 0 11px;
        color: #173d6e;
        font-weight: 700
    }

    .pi-empty {
        min-height: 168px;
        display: grid;
        place-items: center;
        text-align: center;
        background: #fff;
        border: 1px solid #dfe8f3;
        border-radius: 20px
    }

    .pi-empty strong {
        font-size: 18px;
        color: #173e73
    }

    .pi-empty p {
        margin: 7px 0 0;
        color: #73839c
    }

    .pi-record {
        background: #fff;
        border: 1px solid #dfe8f3;
        border-radius: 20px;
        overflow: hidden;
        box-shadow: 0 10px 30px rgba(29, 65, 115, .07);
        margin-bottom: 16px
    }

    .pi-record-head {
        padding: 15px 20px;
        background: linear-gradient(90deg, #eef6ff, #fff5fb);
        display: flex;
        justify-content: space-between;
        gap: 12px;
        align-items: center;
        border-bottom: 1px solid #e5edf6
    }

    .pi-record-head strong {
        color: #214a77
    }

    .pi-record-head span {
        font-size: 12px;
        color: #70839c;
        font-weight: 700
    }

    .pi-record-body {
        padding: 18px 20px
    }

    .pi-meta {
        display: grid;
        grid-template-columns: repeat(3, minmax(0, 1fr));
        gap: 10px;
        margin-bottom: 16px
    }

    .pi-meta-card {
        background: #f8fbff;
        border: 1px solid #e1e9f3;
        border-radius: 12px;
        padding: 11px
    }

    .pi-meta-card small {
        display: block;
        color: #6d829c;
        font-size: 10px;
        text-transform: uppercase;
        font-weight: 900
    }

    .pi-meta-card b {
        display: block;
        margin-top: 4px;
        color: #1e4268
    }

    .pi-section-title {
        margin: 20px 0 10px;
        color: #244b73;
        font-size: 14px;
        font-weight: 900
    }

    .pi-scroll {
        overflow-x: auto;
        border: 1px solid #e0e8f2;
        border-radius: 14px
    }

    .pi-data-table {
        width: 100%;
        border-collapse: collapse;
        min-width: 780px
    }

    .pi-data-table th,
    .pi-data-table td {
        padding: 10px;
        border-bottom: 1px solid #e9eef4;
        font-size: 12px;
        text-align: left;
        vertical-align: top
    }

    .pi-data-table th {
        background: #f5f9ff;
        color: #56708d;
        font-size: 11px
    }

    .pi-chip {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-width: 48px;
        padding: 5px 9px;
        border-radius: 999px;
        font-size: 10px;
        font-weight: 900
    }

    .pi-chip.ac {
        background: #dcfce7;
        color: #166534
    }

    .pi-chip.un {
        background: #fee2e2;
        color: #b91c1c
    }

    .pi-chip.na {
        background: #eef2f7;
        color: #64748b
    }

    .pi-inspections {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 12px
    }

    .pi-hour-card {
        border: 1px solid #dfe8f3;
        border-radius: 16px;
        overflow: hidden;
        background: #fff
    }

    .pi-hour-head {
        display: flex;
        justify-content: space-between;
        gap: 8px;
        align-items: center;
        padding: 12px 14px;
        background: linear-gradient(90deg, #eff6ff, #fff7fb);
        border-bottom: 1px solid #e7eef6
    }

    .pi-hour-head strong {
        color: #204a78;
        font-size: 13px
    }

    .pi-hour-head span {
        font-size: 11px;
        color: #647993;
        font-weight: 800
    }

    .pi-hour-body {
        padding: 14px
    }

    .pi-products {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 8px
    }

    .pi-prod {
        display: flex;
        justify-content: space-between;
        gap: 8px;
        align-items: center;
        border: 1px solid #e1e9f3;
        background: #f8fbff;
        border-radius: 10px;
        padding: 8px 9px
    }

    .pi-prod span {
        font-size: 10px;
        color: #35577e;
        font-weight: 800
    }

    .pi-prod b {
        font-size: 10px
    }

    .pi-note {
        margin-top: 10px;
        padding-top: 10px;
        border-top: 1px dashed #e4ebf3;
        color: #5d728c;
        font-size: 11px;
        white-space: pre-wrap
    }

    .pi-feedback-card {
        border: 1px solid #e0e8f2;
        border-radius: 12px;
        padding: 12px;
        background: #fbfdff
    }

    .pi-feedback-card small {
        display: block;
        color: #6b819a;
        font-size: 10px;
        text-transform: uppercase;
        font-weight: 900
    }

    .pi-feedback-card p {
        margin: 6px 0 0;
        white-space: pre-wrap;
        color: #284463;
        font-size: 12px
    }

    .pi-no-data {
        padding: 20px;
        text-align: center;
        color: #6f8299;
        background: #fbfdff;
        border: 1px dashed #dce7f2;
        border-radius: 12px
    }

    @media(max-width:900px) {
        .pi-meta {
            grid-template-columns: 1fr 1fr
        }

        .pi-inspections {
            grid-template-columns: 1fr
        }
    }

    @media(max-width:700px) {
        .pi-data-head {
            align-items: flex-start;
            flex-direction: column
        }

        .pi-data-head h2 {
            font-size: 23px
        }

        .pi-actions-top {
            width: 100%
        }

        .pi-top-btn,
        .pi-date {
            flex: 1
        }

        .pi-record-head {
            align-items: flex-start;
            flex-direction: column
        }

        .pi-record-body {
            padding: 14px
        }

        .pi-meta {
            grid-template-columns: 1fr
        }

        .pi-products {
            grid-template-columns: 1fr
        }
    }
</style>

<div class="pi-data">
    <div class="pi-data-head">
        <h2>Data Product Inspection</h2>
        <div class="pi-actions-top">
            <a class="pi-top-btn" href="../../qualitycontrol.php">← Kembali</a>
            <form method="get" style="display:flex;gap:8px;align-items:center">
                <input class="pi-date" type="date" name="date" value="<?= pi_h($selectedDate) ?>">
                <button class="pi-top-btn primary" type="submit">Tampilkan</button>
            </form>
            <a class="pi-top-btn primary" href="inputproductinspection.php">＋ Input Data</a>
        </div>
    </div>

    <?php if (!$rows): ?>
        <section class="pi-empty">
            <div>
                <strong>Belum ada data Product Inspection</strong>
            </div>
        </section>
    <?php else: ?>
        <?php foreach ($rows as $row): ?>
            <section class="pi-record">
                <div class="pi-record-head">
                    <strong>Product Inspection — <?= pi_h(date('d/m/Y', strtotime((string)$row['tanggal']))) ?></strong>
                    <span>Shift: <?= pi_h((string)$row['shift']) ?> • QC: <?= pi_h((string)$row['nama_qc']) ?></span>
                </div>

                <div class="pi-record-body">
                    <div class="pi-meta">
                        <div class="pi-meta-card"><small>Tanggal</small><b><?= pi_h(date('d/m/Y', strtotime((string)$row['tanggal']))) ?></b></div>
                        <div class="pi-meta-card"><small>Shift</small><b><?= pi_h((string)$row['shift']) ?></b></div>
                        <div class="pi-meta-card"><small>Nama QC</small><b><?= pi_h((string)$row['nama_qc']) ?></b></div>
                    </div>

                    <div class="pi-section-title">Pengecekan Prosedure Inspeksi Produk</div>
                    <div class="pi-scroll">
                        <table class="pi-data-table">
                            <thead>
                                <tr>
                                    <th>Procedure</th>
                                    <th>Standard &amp; Critical Point</th>
                                    <th>Hasil</th>
                                    <th>Catatan &amp; Langkah Koreksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($row['procedures'])): ?>
                                    <?php foreach ($row['procedures'] as $p): ?>
                                        <tr>
                                            <td><?= pi_h((string)($p['procedure'] ?? '')) ?></td>
                                            <td><?= pi_h((string)($p['standard'] ?? '')) ?></td>
                                            <td>
                                                <span class="pi-chip <?= pi_result_chip((string)($p['hasil'] ?? '')) ?>">
                                                    <?= pi_h(pi_result_label((string)($p['hasil'] ?? ''))) ?>
                                                </span>
                                            </td>
                                            <td><?= pi_h((string)($p['catatan'] ?? '—')) ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="4">—</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="pi-section-title">Product Inspection Setiap Jam</div>
                    <?php if (!empty($row['inspections'])): ?>
                        <div class="pi-inspections">
                            <?php foreach ($row['inspections'] as $ins): ?>
                                <div class="pi-hour-card">
                                    <div class="pi-hour-head">
                                        <strong>Jam Inspeksi: <?= pi_h((string)($ins['jam'] ?? '—')) ?></strong>
                                        <span>Nama QC: <?= pi_h((string)($ins['nama_qc'] ?? $row['nama_qc'])) ?></span>
                                    </div>
                                    <div class="pi-hour-body">
                                        <div class="pi-products">
                                            <?php foreach ($productNames as $product):
                                                $v = (string)($ins['hasil'][$product] ?? '');
                                            ?>
                                                <div class="pi-prod">
                                                    <span><?= pi_h($product) ?></span>
                                                    <b class="pi-chip <?= pi_result_chip($v) ?>"><?= pi_h(pi_result_label($v)) ?></b>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                        <div class="pi-note">
                                            <b>Keterangan:</b><br><?= pi_h((string)($ins['catatan'] ?? '—')) ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php else: ?>
                        <div class="pi-no-data">Belum ada jam inspeksi yang diinput.</div>
                    <?php endif; ?>

                    <div class="pi-section-title">Feedback <?= pi_h((string)$row['shift']) ?></div>
                    <?php
                    $feedbackValue = (string)($row['feedback'][(string)$row['shift']] ?? '');
                    if ($feedbackValue === '' && (string)$row['shift'] === 'Prepare') {
                        $feedbackValue = (string)($row['feedback']['Pagi'] ?? '');
                    }
                    ?>
                    <div class="pi-feedback-card">
                        <small>Feedback Shift</small>
                        <p><?= pi_h($feedbackValue !== '' ? $feedbackValue : '—') ?></p>
                    </div>
                </div>
            </section>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php require __DIR__ . '/../../includes/footer.php'; ?>