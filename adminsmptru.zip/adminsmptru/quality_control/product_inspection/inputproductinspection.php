<?php
declare(strict_types=1);

require_once __DIR__ . '/../../config.php';

$pageTitle = 'Input Product Inspection';
$pdo = db();

$procedureMaster = [
    [
        'procedure' => 'Seluruh produk makanan yang akan disajikan ke konsumen dalam keadaan hangat',
        'standard' => 'Temperature Hot Holding 35°C, lakukan waste produk apabila temperature dibawah 35°C',
    ],
    [
        'procedure' => 'Lakukan pengecekan temperature permukaan pada saat produk akan disajikan ke konsumen setiap satu jam sekali',
        'standard' => 'Pengecekan dengan thermo gun dengan jarak maksimal 5 cm dari permukaan produk.',
    ],
    [
        'procedure' => 'Be Well Dress',
        'standard' => 'Serving plate (Piring, Klakat, dan Gelas) bersih dan layak, takaran, porsi, dan tampilan sesuai SOC',
    ],
];

$inspectionTimes = [
    '02:00','03:00','04:00','05:00','06:00','07:00','08:00','09:00','10:00',
    '15:00','16:00','21:00','22:00'
];

$productNames = [
    'Siomay Ayam','Udang Rambutan','Udang Keju','Lumpia Udang',
    'Mie Gacoan','Mie Hompimpa','Pangsit Goreng','Beverages & Es buah'
];

$qcOptions = ['Atika','Luluk','Ega'];
$shiftOptions = ['Prepare','Middle','Closing'];

function pi_valid_date(string $date): string
{
    return preg_match('/^\d{4}-\d{2}-\d{2}$/', $date) ? $date : date('Y-m-d');
}

function pi_ensure_schema(PDO $pdo): void
{
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS `product_inspection` (
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            `tanggal` DATE NOT NULL,
            `shift` VARCHAR(30) NOT NULL DEFAULT '',
            `nama_qc` VARCHAR(50) NOT NULL DEFAULT '',
            `qc_opening` VARCHAR(50) NOT NULL DEFAULT '',
            `qc_middle` VARCHAR(50) NOT NULL DEFAULT '',
            `qc_closing` VARCHAR(50) NOT NULL DEFAULT '',
            `procedures_json` LONGTEXT NOT NULL,
            `inspections_json` LONGTEXT NOT NULL,
            `feedback_json` LONGTEXT NOT NULL,
            `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (`id`),
            KEY `idx_product_inspection_tanggal` (`tanggal`),
            KEY `idx_product_inspection_shift` (`shift`)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci"
    );

    // Safe migration for older installations.
    $cols = $pdo->query("SHOW COLUMNS FROM `product_inspection`")->fetchAll(PDO::FETCH_COLUMN, 1);
    $migrations = [
        'shift' => "VARCHAR(30) NOT NULL DEFAULT ''",
        'nama_qc' => "VARCHAR(50) NOT NULL DEFAULT ''",
        'qc_opening' => "VARCHAR(50) NOT NULL DEFAULT ''",
        'qc_middle' => "VARCHAR(50) NOT NULL DEFAULT ''",
        'qc_closing' => "VARCHAR(50) NOT NULL DEFAULT ''",
        'procedures_json' => "LONGTEXT NOT NULL",
        'inspections_json' => "LONGTEXT NOT NULL",
        'feedback_json' => "LONGTEXT NOT NULL",
        'created_at' => "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP",
        'updated_at' => "DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP",
    ];
    foreach ($migrations as $column => $definition) {
        if (!in_array($column, $cols, true)) {
            try {
                $pdo->exec("ALTER TABLE `product_inspection` ADD COLUMN `$column` $definition");
            } catch (Throwable $e) {
                // Keep compatibility with existing installations that already contain the column.
            }
        }
    }
}

pi_ensure_schema($pdo);

$today = date('Y-m-d');
$postDate = pi_valid_date((string)($_POST['tanggal'] ?? $today));
$postShift = trim((string)($_POST['shift'] ?? ''));
$postQc = trim((string)($_POST['nama_qc'] ?? ''));
$errors = [];

$oldRows = $_POST['inspections'] ?? [];
if (!is_array($oldRows) || !$oldRows) {
    $oldRows = [[
        'jam' => '',
        'nama_qc' => $postQc,
        'catatan' => '',
        'hasil' => array_fill_keys($productNames, ''),
    ]];
}

$selectedFeedback = [
    'Prepare' => '',
    'Middle' => '',
    'Closing' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        check_csrf();

        if (!in_array($postShift, $shiftOptions, true)) {
            throw new RuntimeException('Shift wajib dipilih.');
        }
        if (!in_array($postQc, $qcOptions, true)) {
            throw new RuntimeException('Nama QC wajib dipilih.');
        }

        foreach ($procedureMaster as $i => $master) {
            $p = is_array($_POST['procedures'][$i] ?? null) ? $_POST['procedures'][$i] : [];
            $hasil = trim((string)($p['hasil'] ?? ''));
            if ($hasil !== '' && !in_array($hasil, ['AC', 'UN'], true)) {
                throw new RuntimeException('Hasil procedure tidak valid.');
            }
        }

        $inspections = [];
        $usedInspectionTimes = [];
        foreach ((array)($_POST['inspections'] ?? []) as $src) {
            if (!is_array($src)) continue;

            $jam = trim((string)($src['jam'] ?? ''));
            $catatan = trim((string)($src['catatan'] ?? ''));
            $hasil = [];
            $hasAny = $jam !== '' || $catatan !== '';

            foreach ($productNames as $product) {
                $value = trim((string)($src['hasil'][$product] ?? ''));
                if ($value !== '' && !in_array($value, ['√', 'X'], true)) {
                    throw new RuntimeException('Hasil product inspection tidak valid.');
                }
                $hasil[$product] = $value;
                if ($value !== '') $hasAny = true;
            }

            if (!$hasAny) continue;
            if (!in_array($jam, $inspectionTimes, true)) {
                throw new RuntimeException('Jam inspeksi tidak valid.');
            }
            if (isset($usedInspectionTimes[$jam])) {
                throw new RuntimeException('Jam inspeksi ' . $jam . ' dipilih lebih dari satu kali.');
            }
            $usedInspectionTimes[$jam] = true;

            $inspections[] = [
                'jam' => $jam,
                'nama_qc' => $postQc,
                'hasil' => $hasil,
                'catatan' => $catatan,
            ];
        }

        if (!$inspections) {
            throw new RuntimeException('Minimal 1 jam inspeksi harus diisi.');
        }

        // Only the selected shift receives feedback.
        $selectedFeedback[$postShift] = trim((string)($_POST['feedback'][$postShift] ?? ''));

        $procedures = [];
        foreach ($procedureMaster as $i => $master) {
            $p = is_array($_POST['procedures'][$i] ?? null) ? $_POST['procedures'][$i] : [];
            $procedures[] = [
                'procedure' => $master['procedure'],
                'standard' => $master['standard'],
                'hasil' => trim((string)($p['hasil'] ?? '')),
                'catatan' => trim((string)($p['catatan'] ?? '')),
            ];
        }

        $stmt = $pdo->prepare(
            'INSERT INTO product_inspection
                (tanggal, shift, nama_qc, qc_opening, qc_middle, qc_closing, procedures_json, inspections_json, feedback_json)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );

        $stmt->execute([
            $postDate,
            $postShift,
            $postQc,
            $postShift === 'Prepare' ? $postQc : '',
            $postShift === 'Middle' ? $postQc : '',
            $postShift === 'Closing' ? $postQc : '',
            json_encode($procedures, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            json_encode($inspections, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            json_encode($selectedFeedback, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
        ]);

        flash('success', 'Product Inspection berhasil disimpan.');
        redirect('dataproductinspection.php?date=' . urlencode($postDate));
    } catch (Throwable $e) {
        $errors[] = $e->getMessage();
    }
}

require __DIR__ . '/../../includes/header.php';
?>
<style>
.pi-input{max-width:1180px;margin:0 auto;padding-bottom:28px}
.pi-head{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;margin-bottom:18px}
.pi-head h2{margin:0;color:#133f78;font-size:30px;font-weight:900}
.pi-head p{margin:6px 0 0;color:#71829c;font-size:13px}
.pi-panel{background:#fff;border:1px solid #dfe8f3;border-radius:20px;box-shadow:0 12px 35px rgba(29,65,115,.07);overflow:hidden;margin-bottom:18px}
.pi-panel-title{background:linear-gradient(90deg,#1678ed,#276de7);color:#fff;padding:15px 20px;font-weight:900;font-size:15px}
.pi-panel-body{padding:20px}
.pi-grid-top{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}
.pi-field{display:flex;flex-direction:column;gap:7px;color:#425675;font-size:12px;font-weight:800;min-width:0}
.pi-field span{font-size:11px;color:#35557a}
.pi-field input,.pi-field select,.pi-field textarea,
.pi-proc select,.pi-proc textarea,
.pi-product-card select{
    width:100%;min-width:0;box-sizing:border-box;
    border:1px solid #cfe0f4;border-radius:12px;background:#fbfdff;color:#183657;
    padding:11px 13px;outline:none;transition:.15s ease;font-size:14px;
}
.pi-field input,.pi-field select{height:46px}
.pi-field select,.pi-proc select,.pi-product-card select{
    appearance:none;padding-right:38px;
    background-image:linear-gradient(45deg,transparent 50%,#6882a0 50%),linear-gradient(135deg,#6882a0 50%,transparent 50%);
    background-position:calc(100% - 19px) 20px,calc(100% - 13px) 20px;
    background-size:6px 6px,6px 6px;background-repeat:no-repeat;
}
.pi-field input[readonly]{background:#eef4fb;color:#204a77}
.pi-field input:focus,.pi-field select:focus,.pi-field textarea:focus,
.pi-proc select:focus,.pi-proc textarea:focus,.pi-product-card select:focus{
    border-color:#2a7ef2;box-shadow:0 0 0 3px rgba(42,126,242,.10);background:#fff;
}
.pi-help{margin:0 0 14px;color:#73839c;font-size:12px;line-height:1.55}
.pi-autofill{margin-top:8px;font-size:11px;color:#5d7692;display:flex;align-items:center;gap:7px}
.pi-dot{width:7px;height:7px;border-radius:50%;background:#16a4e8;display:inline-block;flex:0 0 auto}
.pi-proc-wrap{overflow-x:auto;border:1px solid #e0e8f2;border-radius:14px}
.pi-proc{width:100%;border-collapse:collapse;table-layout:fixed}
.pi-proc th,.pi-proc td{border-bottom:1px solid #e8eef5;padding:11px 10px;vertical-align:top;font-size:12px}
.pi-proc th{background:#f5f9ff;color:#526a86;text-align:left;font-size:11px;letter-spacing:.4px}
.pi-proc th:nth-child(1){width:30%}.pi-proc th:nth-child(2){width:34%}.pi-proc th:nth-child(3){width:15%}.pi-proc th:nth-child(4){width:21%}
.pi-proc td:first-child{font-weight:800;color:#213f64}
.pi-proc select{height:42px}.pi-proc textarea{min-height:72px;resize:vertical}
.pi-row-card{border:1px solid #dfe8f3;border-radius:16px;overflow:hidden;margin-bottom:14px;background:#fff}
.pi-row-head{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 16px;background:linear-gradient(90deg,#eef6ff,#fff7fb);border-bottom:1px solid #e7eef6}
.pi-row-head strong{color:#204a78;font-size:13px}
.pi-delete{border:1px solid #ffc7d1;background:#fff4f6;color:#c51f45;border-radius:10px;padding:8px 12px;font-weight:900;cursor:pointer}
.pi-row-body{padding:16px}
.pi-row-top{display:grid;grid-template-columns:minmax(150px,1fr) minmax(150px,1fr) minmax(260px,2fr);gap:14px;margin-bottom:14px}
.pi-row-note textarea{min-height:92px;resize:vertical}
.pi-product-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}
.pi-product-card{display:flex;align-items:center;justify-content:space-between;gap:10px;border:1px solid #dfe8f3;border-radius:12px;background:#f8fbff;padding:10px 11px;min-width:0}
.pi-product-card span{font-size:11px;font-weight:800;color:#2c5279;line-height:1.25;min-width:0}
.pi-product-card select{width:128px;flex:0 0 128px;height:40px;padding-top:0;padding-bottom:0}
.pi-add-row{display:flex;justify-content:flex-start;margin-top:8px}
.pi-add-btn{border:0;border-radius:12px;padding:11px 18px;background:linear-gradient(100deg,#1678ed,#f04f9b);color:#fff;font-weight:900;cursor:pointer}
.pi-feedback{display:block}
.pi-feedback .box{border:1px solid #dfe8f3;border-radius:14px;padding:14px;background:#fbfdff}
.pi-feedback .box h4{margin:0 0 8px;color:#214b77;font-size:13px}
.pi-feedback textarea{width:100%;min-height:100px;border:1px solid #cfe0f4;border-radius:10px;background:#fff;padding:10px;resize:vertical;outline:none;box-sizing:border-box;font-size:14px}
.pi-feedback textarea:focus{border-color:#2a7ef2;box-shadow:0 0 0 3px rgba(42,126,242,.10)}
.pi-actions{display:flex;justify-content:flex-end;gap:10px}
.pi-btn{border:0;border-radius:12px;padding:12px 18px;font-weight:900;text-decoration:none;display:inline-flex;align-items:center;justify-content:center}
.pi-btn-back{background:#eef3fa;color:#41516b}.pi-btn-save{background:linear-gradient(100deg,#1678ed,#f04f9b);color:#fff;cursor:pointer}
.pi-errors{margin:0 0 14px;padding:11px 14px;border:1px solid #fecdd3;background:#fff1f2;color:#b4233f;border-radius:12px;font-weight:800}
@media(max-width:1000px){
    .pi-grid-top{grid-template-columns:1fr 1fr}
    .pi-product-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
}
@media(max-width:700px){
    .pi-head{align-items:flex-start;flex-direction:column}
    .pi-head h2{font-size:24px}
    .pi-grid-top,.pi-row-top,.pi-product-grid{grid-template-columns:1fr}
    .pi-panel-body{padding:14px}
    .pi-product-card select{width:150px;flex-basis:150px}
}
</style>

<div class="pi-input">
    <div class="pi-head">
        <div>
            <h2>Input Product Inspection</h2>
            <p>Pengecekan inspeksi produk yang akan disajikan kepada konsumen</p>
        </div>
        <a class="pi-btn pi-btn-back" href="dataproductinspection.php">← Kembali</a>
    </div>

    <?php foreach ($errors as $err): ?>
        <div class="pi-errors"><?= e($err) ?></div>
    <?php endforeach; ?>

    <form method="post" id="productInspectionForm">
        <input type="hidden" name="csrf" value="<?= e(csrf_token()) ?>">

        <section class="pi-panel">
            <div class="pi-panel-title">Informasi Checklist</div>
            <div class="pi-panel-body">
                <div class="pi-grid-top">
                    <label class="pi-field">
                        <span>Tanggal</span>
                        <input type="date" name="tanggal" value="<?= e($postDate) ?>" readonly>
                    </label>

                    <label class="pi-field">
                        <span>Shift</span>
                        <select name="shift" id="shiftSelect" required>
                            <option value="">Pilih Shift</option>
                            <?php foreach ($shiftOptions as $s): ?>
                                <option value="<?= e($s) ?>" <?= $postShift === $s ? 'selected' : '' ?>><?= e($s) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </label>

                    <label class="pi-field">
                        <span>Nama QC</span>
                        <select name="nama_qc" id="mainQcSelect" required>
                            <option value="">Pilih Nama QC</option>
                            <?php foreach ($qcOptions as $q): ?>
                                <option value="<?= e($q) ?>" <?= $postQc === $q ? 'selected' : '' ?>><?= e($q) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <div class="pi-autofill"><span class="pi-dot"></span>Nama QC pada setiap jam inspeksi otomatis mengikuti pilihan ini.</div>
                    </label>
                </div>
            </div>
        </section>

        <section class="pi-panel">
            <div class="pi-panel-title">Pengecekan Prosedure Inspeksi Produk</div>
            <div class="pi-panel-body">
                <p class="pi-help">Gunakan <b>AC</b> jika sesuai standar dan <b>UN</b> jika tidak sesuai. Isi catatan jika ada temuan atau langkah koreksi.</p>
                <div class="pi-proc-wrap">
                    <table class="pi-proc">
                        <thead>
                            <tr>
                                <th>Procedure</th>
                                <th>Standard &amp; Critical Point</th>
                                <th>Hasil</th>
                                <th>Catatan &amp; Langkah Koreksi</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($procedureMaster as $i => $master):
                            $postP = is_array($_POST['procedures'][$i] ?? null) ? $_POST['procedures'][$i] : [];
                        ?>
                            <tr>
                                <td><?= e($master['procedure']) ?></td>
                                <td><?= e($master['standard']) ?></td>
                                <td>
                                    <select name="procedures[<?= $i ?>][hasil]">
                                        <option value="">Pilih Hasil</option>
                                        <option value="AC" <?= (($postP['hasil'] ?? '') === 'AC') ? 'selected' : '' ?>>AC</option>
                                        <option value="UN" <?= (($postP['hasil'] ?? '') === 'UN') ? 'selected' : '' ?>>UN</option>
                                    </select>
                                </td>
                                <td>
                                    <textarea name="procedures[<?= $i ?>][catatan]" placeholder="Catatan inspeksi..."><?= e((string)($postP['catatan'] ?? '')) ?></textarea>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>

        <section class="pi-panel">
            <div class="pi-panel-title">Product Inspection Setiap Jam</div>
            <div class="pi-panel-body">
                <p class="pi-help">Pilih jam inspeksi yang dilakukan. Nama QC pada setiap baris otomatis mengikuti <b>Nama QC</b> pada Informasi Checklist.</p>

                <div id="inspectionRows">
                <?php foreach ($oldRows as $i => $row):
                    $jam = (string)($row['jam'] ?? '');
                    $rowQc = (string)($postQc !== '' ? $postQc : ($row['nama_qc'] ?? ''));
                    $catatan = (string)($row['catatan'] ?? '');
                    $hasilArr = is_array($row['hasil'] ?? null) ? $row['hasil'] : [];
                ?>
                    <div class="pi-row-card inspection-row">
                        <div class="pi-row-head">
                            <strong>Jam Inspeksi <?= $i + 1 ?></strong>
                            <button type="button" class="pi-delete" onclick="removeInspectionRow(this)">Hapus Baris</button>
                        </div>
                        <div class="pi-row-body">
                            <div class="pi-row-top">
                                <label class="pi-field">
                                    <span>Jam Inspeksi</span>
                                    <select name="inspections[<?= $i ?>][jam]" class="inspection-time" required>
                                        <option value="">Pilih Jam</option>
                                        <?php foreach ($inspectionTimes as $t): ?>
                                            <option value="<?= e($t) ?>" <?= $jam === $t ? 'selected' : '' ?>><?= e($t) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </label>

                                <label class="pi-field">
                                    <span>Nama QC</span>
                                    <input type="text" class="inspection-qc" value="<?= e($rowQc) ?>" readonly>
                                    <input type="hidden" name="inspections[<?= $i ?>][nama_qc]" class="inspection-qc-hidden" value="<?= e($rowQc) ?>">
                                </label>

                                <label class="pi-field pi-row-note">
                                    <span>Keterangan</span>
                                    <textarea name="inspections[<?= $i ?>][catatan]" placeholder="Catatan dan langkah koreksi..."><?= e($catatan) ?></textarea>
                                </label>
                            </div>

                            <div class="pi-product-grid">
                            <?php foreach ($productNames as $product):
                                $v = (string)($hasilArr[$product] ?? '');
                            ?>
                                <label class="pi-product-card">
                                    <span><?= e($product) ?></span>
                                    <select name="inspections[<?= $i ?>][hasil][<?= e($product) ?>]">
                                        <option value="">Pilih</option>
                                        <option value="√" <?= $v === '√' ? 'selected' : '' ?>>✓ Layak</option>
                                        <option value="X" <?= $v === 'X' ? 'selected' : '' ?>>✕ Tidak</option>
                                    </select>
                                </label>
                            <?php endforeach; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
                </div>

                <div class="pi-add-row">
                    <button type="button" class="pi-add-btn" id="addInspectionBtn">＋ Tambah Jam Inspeksi</button>
                </div>
            </div>
        </section>

        <section class="pi-panel">
            <div class="pi-panel-title">Feedback Shift</div>
            <div class="pi-panel-body">
                <?php
                $feedbackValue = '';
                if ($postShift !== '') {
                    $feedbackValue = (string)($_POST['feedback'][$postShift] ?? '');
                }
                ?>
                <div class="pi-feedback">
                    <div class="box">
                        <h4>Feedback <?= $postShift !== '' ? e($postShift) : 'Shift' ?></h4>
                        <textarea
                            name="feedback[<?= $postShift !== '' ? e($postShift) : 'Prepare' ?>]"
                            placeholder="Tulis feedback / temuan / tindakan koreksi..."
                            <?= $postShift === '' ? 'disabled' : '' ?>
                        ><?= e($feedbackValue) ?></textarea>
                        <?php if ($postShift === ''): ?><small style="display:block;margin-top:8px;color:#7b8ca4">Pilih Shift terlebih dahulu.</small><?php endif; ?>
                    </div>
                </div>
            </div>
        </section>

        <div class="pi-actions">
            <a class="pi-btn pi-btn-back" href="dataproductinspection.php">Batal</a>
            <button class="pi-btn pi-btn-save" type="submit">Simpan Data</button>
        </div>
    </form>
</div>

<script>
(function(){
    const mainQc = document.getElementById('mainQcSelect');
    const shift = document.getElementById('shiftSelect');
    const rowsWrap = document.getElementById('inspectionRows');
    const addBtn = document.getElementById('addInspectionBtn');
    const feedbackBox = document.querySelector('.pi-feedback .box');
    const feedbackTitle = feedbackBox?.querySelector('h4');
    const feedbackTextarea = feedbackBox?.querySelector('textarea');

    const times = <?= json_encode($inspectionTimes, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;
    const products = <?= json_encode($productNames, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) ?>;

    function escapeHtml(str){
        return String(str).replace(/[&<>'"]/g, c => ({
            '&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'
        }[c]));
    }

    function optionList(items){
        return '<option value="">Pilih</option>' + items.map(v =>
            '<option value="' + escapeHtml(v) + '">' + escapeHtml(v) + '</option>'
        ).join('');
    }

    function syncQC(){
        const qc = mainQc ? mainQc.value : '';
        rowsWrap.querySelectorAll('.inspection-row').forEach(row => {
            const text = row.querySelector('.inspection-qc');
            const hidden = row.querySelector('.inspection-qc-hidden');
            if (text) text.value = qc;
            if (hidden) hidden.value = qc;
        });
    }

    function syncFeedback(){
        const currentShift = shift ? shift.value : '';
        if (!feedbackTitle || !feedbackTextarea) return;

        feedbackTitle.textContent = currentShift ? ('Feedback ' + currentShift) : 'Feedback Shift';
        feedbackTextarea.disabled = !currentShift;
        feedbackTextarea.name = 'feedback[' + (currentShift || 'Prepare') + ']';
    }

    function renumber(){
        rowsWrap.querySelectorAll('.inspection-row').forEach((row, idx) => {
            row.querySelector('.pi-row-head strong').textContent = 'Jam Inspeksi ' + (idx + 1);
            row.querySelectorAll('[name]').forEach(el => {
                el.name = el.name.replace(/inspections\[\d+\]/, 'inspections[' + idx + ']');
            });
        });
    }

    function addRow(){
        const idx = rowsWrap.querySelectorAll('.inspection-row').length;
        const qc = mainQc ? mainQc.value : '';

        const row = document.createElement('div');
        row.className = 'pi-row-card inspection-row';
        row.innerHTML = `
            <div class="pi-row-head">
                <strong>Jam Inspeksi ${idx + 1}</strong>
                <button type="button" class="pi-delete" onclick="removeInspectionRow(this)">Hapus Baris</button>
            </div>
            <div class="pi-row-body">
                <div class="pi-row-top">
                    <label class="pi-field">
                        <span>Jam Inspeksi</span>
                        <select name="inspections[${idx}][jam]" class="inspection-time" required>${optionList(times)}</select>
                    </label>
                    <label class="pi-field">
                        <span>Nama QC</span>
                        <input type="text" class="inspection-qc" value="${escapeHtml(qc)}" readonly>
                        <input type="hidden" name="inspections[${idx}][nama_qc]" class="inspection-qc-hidden" value="${escapeHtml(qc)}">
                    </label>
                    <label class="pi-field pi-row-note">
                        <span>Keterangan</span>
                        <textarea name="inspections[${idx}][catatan]" placeholder="Catatan dan langkah koreksi..."></textarea>
                    </label>
                </div>
                <div class="pi-product-grid">
                    ${products.map(product => `
                        <label class="pi-product-card">
                            <span>${escapeHtml(product)}</span>
                            <select name="inspections[${idx}][hasil][${escapeHtml(product)}]">
                                <option value="">Pilih</option>
                                <option value="√">✓ Layak</option>
                                <option value="X">✕ Tidak</option>
                            </select>
                        </label>
                    `).join('')}
                </div>
            </div>
        `;
        rowsWrap.appendChild(row);
    }

    window.removeInspectionRow = function(button){
        const rows = rowsWrap.querySelectorAll('.inspection-row');
        if (rows.length <= 1) {
            alert('Minimal 1 baris inspeksi.');
            return;
        }
        button.closest('.inspection-row')?.remove();
        renumber();
        syncQC();
    };

    mainQc?.addEventListener('change', syncQC);
    shift?.addEventListener('change', syncFeedback);
    addBtn?.addEventListener('click', addRow);

    syncQC();
    syncFeedback();
})();
</script>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
