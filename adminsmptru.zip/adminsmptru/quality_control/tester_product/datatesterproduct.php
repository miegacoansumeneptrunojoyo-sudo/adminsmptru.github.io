<?php
$pageTitle = 'Tester Product';
require __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../config/database.php';
if (db_ready()) {
  $cols = [];
  $q = $conn->query("SHOW COLUMNS FROM tester_product_inspections");
  if ($q) {
    while ($c = $q->fetch_assoc()) $cols[$c['Field']] = true;
  }
  $alters = [];
  if (!isset($cols['quality_control'])) $alters[] = "ADD COLUMN quality_control VARCHAR(30) NOT NULL DEFAULT '' AFTER tanggal";
  if (!isset($cols['nama_sm'])) $alters[] = "ADD COLUMN nama_sm VARCHAR(120) NOT NULL DEFAULT 'Alvin Zakaria' AFTER quality_control";
  if ($alters) {
    try {
      $conn->query('ALTER TABLE tester_product_inspections ' . implode(', ', $alters));
    } catch (Throwable $e) {
      $error = $e->getMessage();
    }
  }
}

$selectedDate = trim((string)($_GET['tanggal'] ?? date('Y-m-d')));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate)) $selectedDate = date('Y-m-d');

$rows = [];
$error = '';
if (db_ready()) {
  $stmt = $conn->prepare('SELECT tanggal, quality_control, nama_sm, station, no_barang, nama_barang, qty_sampel, kode_produksi, bentuk, warna, aroma, rasa, tekstur, average, resume FROM tester_product_inspections WHERE tanggal = ? ORDER BY no_barang ASC, id ASC');
  if ($stmt) {
    $stmt->bind_param('s', $selectedDate);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) $rows[] = $row;
    $stmt->close();
  } else {
    $error = $conn->error;
  }
} else {
  $error = 'Database tidak dapat terhubung.';
}
?>

<style>
  .tester-data-wrap {
    overflow: auto;
    border: 1px solid #e4ebf4;
    border-radius: 14px
  }

  .tester-data-table {
    width: 100%;
    min-width: 1150px;
    border-collapse: separate;
    border-spacing: 0;
    background: #fff
  }

  .tester-data-table th,
  .tester-data-table td {
    padding: 10px 9px;
    border-bottom: 1px solid #e7edf5;
    border-right: 1px solid #eef2f7;
    font-size: 12px;
    vertical-align: middle
  }

  .tester-data-table th:last-child,
  .tester-data-table td:last-child {
    border-right: 0
  }

  .tester-data-table th {
    background: #f5f9ff;
    color: #3f5f86;
    text-align: center;
    font-weight: 800;
    white-space: nowrap
  }

  .tester-data-table td {
    text-align: center
  }

  .tester-data-table td.name {
    text-align: left;
    font-weight: 700;
    color: #1e3a5f
  }

  .tester-data-table td.station {
    text-align: left;
    font-weight: 800;
    color: #2563eb
  }

  .value-pill {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 34px;
    height: 32px;
    padding: 5px 8px;
    border: 1px solid #d4e2f2;
    border-radius: 9px;
    background: #fbfdff;
    font-weight: 800;
    color: #173a68
  }

  .avg-pill {
    min-width: 56px
  }

  .resume-pill {
    padding: 6px 9px;
    border-radius: 9px;
    font-weight: 800;
    white-space: nowrap
  }

  .resume-pill.waste {
    background: #fff1f2;
    color: #b91c1c
  }

  .resume-pill.standard {
    background: #ecfdf3;
    color: #166534
  }

  .tester-data-table th {
    white-space: nowrap
  }

  .tester-filter {
    display: flex;
    align-items: center;
    gap: 10px;
    flex-wrap: wrap
  }

  .tester-filter label {
    font-size: 13px;
    font-weight: 800;
    color: #173a68
  }

  .page-head-actions {
    display: flex !important;
    align-items: center !important;
    gap: 10px !important;
    flex-wrap: wrap !important
  }

  .tester-date-input {
    width: 140px;
    height: 42px;
    border: 1px solid #d7e3f2;
    border-radius: 11px;
    padding: 9px 11px;
    font: inherit;
    background: #fff;
    color: #173a68;
    font-weight: 700;
    box-sizing: border-box
  }

  .tester-date-input:focus {
    outline: none;
    border-color: #4b8bea;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, .12)
  }

  .tester-filter input {
    display: block;
    margin-top: 7px;
    width: 220px;
    height: 42px;
    border: 1px solid #d7e3f2;
    border-radius: 11px;
    padding: 10px 12px;
    font: inherit;
    background: #fff
  }

  @media(max-width:760px) {
    .tester-filter {
      display: grid;
      grid-template-columns: 1fr
    }

    .tester-filter input {
      width: 100%
    }

    .tester-filter .btn-action {
      width: 100%
    }
  }
</style>

<div class="page-head">
  <div>
    <h2>Data Tester Product</h2>
  </div>
  <div class="page-actions">
    <a class="btn-action back" href="../../qualitycontrol.php">← Kembali</a>
    <form class="page-head-actions" method="get">
      <input class="tester-date-input" type="date" name="tanggal" value="<?= e($selectedDate) ?>" aria-label="Pilih tanggal">
      <button class="btn-action primary" type="submit">Tampilkan</button>
      <a class="btn-action primary" href="inputtesterproduct.php">＋ Input Data</a>
    </form>
  </div>
</div>

<?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>

<div class="panel">
  <?php if (!$rows): ?>
    <div class="empty-state">
      <h3>Belum ada data Tester Product</h3>
    </div>
  <?php else: ?>
    <div class="panel-title">Data Tester Product — <?= e(date('d/m/Y', strtotime($selectedDate))) ?></div>
    <div class="tester-data-wrap">
      <table class="tester-data-table">
        <thead>
          <tr>
            <th>Tanggal</th>
            <th>Quality Control</th>
            <th>Nama SM</th>
            <th>Station</th>
            <th>No</th>
            <th>Nama Barang</th>
            <th>Qty Sampel</th>
            <th>Kode Produksi</th>
            <th>Bentuk</th>
            <th>Warna</th>
            <th>Aroma</th>
            <th>Rasa</th>
            <th>Tekstur</th>
            <th>Average</th>
            <th>Resume</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($rows as $row): ?>
            <tr>
              <td><?= e(date('d/m/Y', strtotime($row['tanggal']))) ?></td>
              <td><?= e($row['quality_control']) ?></td>
              <td><?= e($row['nama_sm']) ?></td>
              <td class="station"><?= e($row['station']) ?></td>
              <td><?= e($row['no_barang']) ?></td>
              <td class="name"><?= e($row['nama_barang']) ?></td>
              <td><?= e($row['qty_sampel']) ?></td>
              <td><?= e($row['kode_produksi']) ?></td>
              <?php foreach (['bentuk', 'warna', 'aroma', 'rasa', 'tekstur'] as $key): ?><td><span class="value-pill"><?= e($row[$key]) ?></span></td><?php endforeach; ?>
              <td><span class="value-pill avg-pill"><?= e(number_format((float)$row['average'], 2, '.', '')) ?></span></td>
              <td><?php $standard = strtoupper((string)$row['resume']) === 'PRODUK STANDART'; ?><span class="resume-pill <?= $standard ? 'standard' : 'waste' ?>"><?= e($row['resume']) ?></span></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  <?php endif; ?>
</div>
<?php require __DIR__ . '/../../includes/footer.php'; ?>