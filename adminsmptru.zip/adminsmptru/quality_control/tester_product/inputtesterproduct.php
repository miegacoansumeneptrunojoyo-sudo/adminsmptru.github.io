<?php
$pageTitle = 'Tester Product';
require __DIR__ . '/../../includes/header.php';

$items = [
    ['NOODLE', 1, 'MIE'],
    ['NOODLE', 2, 'KRUPUK PANGSIT'],
    ['NOODLE', 3, 'PANGSIT GORENG'],
    ['NOODLE', 4, 'ACIN'],
    ['NOODLE', 5, 'BAWANG GORENG'],
    ['NOODLE', 6, 'DRY LEAVES'],
    ['NOODLE', 7, 'CABE GILING'],
    ['DIMSUM', 8, 'SIOMAY'],
    ['DIMSUM', 9, 'UDANG KEJU'],
    ['DIMSUM', 10, 'UDANG RAMBUTAN'],
    ['DIMSUM', 11, 'LUMPIA UDANG'],
    ['BAR', 12, 'BIANG CHOCOAN'],
    ['BAR', 13, 'BIANG TEH TARIK'],
    ['BAR', 14, 'BIANG LEMON'],
    ['BAR', 15, 'BIANG ORANGE'],
    ['BAR', 16, 'BIANG TEH'],
    ['BAR', 17, 'BIANG GULA'],
    ['BAR', 18, 'GREEN THAI TEA'],
    ['BAR', 19, 'THAI TEA'],
    ['BAR', 20, 'UHT'],
    ['BAR', 21, 'EVAPORASI'],
];

$today = date('Y-m-d');
$error = '';
$success = '';
$qcOptions = ['Ega','Atika','Luluk'];
$namaSM = 'Alvin Zakaria';

require_once __DIR__ . '/../../config/database.php';
if (db_ready()) {
    $cols = [];
    $q = $conn->query("SHOW COLUMNS FROM tester_product_inspections");
    if ($q) { while ($c = $q->fetch_assoc()) $cols[$c['Field']] = true; }
    $alters = [];
    if (!isset($cols['quality_control'])) $alters[] = "ADD COLUMN quality_control VARCHAR(30) NOT NULL DEFAULT '' AFTER tanggal";
    if (!isset($cols['nama_sm'])) $alters[] = "ADD COLUMN nama_sm VARCHAR(120) NOT NULL DEFAULT 'Alvin Zakaria' AFTER quality_control";
    if ($alters) { try { $conn->query('ALTER TABLE tester_product_inspections '.implode(', ', $alters)); } catch (Throwable $e) { $error = $e->getMessage(); } }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal = trim((string)($_POST['tanggal'] ?? $today));
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $tanggal)) { $tanggal = $today; }
    $qualityControl = trim((string)($_POST['quality_control'] ?? ''));
    if (!in_array($qualityControl, $qcOptions, true)) { $error = 'Nama Quality Control wajib dipilih.'; }

    if ($error) {
        // fall through to render form with error
    } elseif (!db_ready()) {
        $error = 'Database tidak dapat terhubung.';
    } else {
        $conn->begin_transaction();
        try {
            $stmt = $conn->prepare('INSERT INTO tester_product_inspections (tanggal, quality_control, nama_sm, station, no_barang, nama_barang, qty_sampel, kode_produksi, bentuk, warna, aroma, rasa, tekstur, average, resume) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)');
            if (!$stmt) {
                throw new RuntimeException($conn->error);
            }

            foreach ($items as [$station, $no, $nama]) {
                $qty = trim((string)($_POST['qty_sampel'][$no] ?? ''));
                $kode = trim((string)($_POST['kode_produksi'][$no] ?? ''));
                $scores = [];
                foreach (['bentuk','warna','aroma','rasa','tekstur'] as $key) {
                    $v = (int)($_POST[$key][$no] ?? 0);
                    if ($v < 1 || $v > 4) {
                        throw new RuntimeException('Nilai sensory untuk '.$nama.' harus 1 sampai 4 pada semua atribut.');
                    }
                    $scores[$key] = $v;
                }

                $avg = round(array_sum($scores) / 5, 2);
                if ($avg >= 0 && $avg <= 1.0) {
                    $resume = 'WASTE';
                } elseif ($avg <= 2.0) {
                    $resume = 'WASTE';
                } elseif ($avg <= 2.9) {
                    $resume = 'WASTE';
                } else {
                    $resume = 'PRODUK STANDART';
                }

                $stationVal = $station;
                $noVal = $no;
                $namaVal = $nama;
                $bentuk = $scores['bentuk'];
                $warna = $scores['warna'];
                $aroma = $scores['aroma'];
                $rasa = $scores['rasa'];
                $tekstur = $scores['tekstur'];
                $avgVal = $avg;
                $resumeVal = $resume;
                $stmt->bind_param('ssssisssiiiiids', $tanggal, $qualityControl, $namaSM, $stationVal, $noVal, $namaVal, $qty, $kode, $bentuk, $warna, $aroma, $rasa, $tekstur, $avgVal, $resumeVal);
                if (!$stmt->execute()) {
                    throw new RuntimeException($stmt->error);
                }
            }
            $stmt->close();
            $conn->commit();
            $success = 'Data Tester Product berhasil disimpan.';
        } catch (Throwable $e) {
            $conn->rollback();
            $error = $e->getMessage();
        }
    }
}
?>

<style>
.tester-note{margin:0 0 16px;color:#64748b;font-size:13px;line-height:1.5}
.tester-info-grid{grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}
.tester-field{min-width:0}
.tester-field>input,.tester-select-wrap select{width:100%;height:46px;box-sizing:border-box;border:1px solid #cfdceb;border-radius:12px;padding:10px 13px;background:#fff;color:#173a68;font:inherit;outline:none}
.tester-field>input[readonly]{background:#f4f8fc}
.tester-select-wrap{position:relative;display:block}
.tester-select-wrap:after{content:'⌄';position:absolute;right:14px;top:50%;transform:translateY(-55%);color:#54769e;pointer-events:none;font-size:18px}
.tester-select-wrap select{appearance:none;padding-right:38px;cursor:pointer}
.tester-field>input:focus,.tester-select-wrap select:focus{border-color:#77a8ea;box-shadow:0 0 0 3px rgba(37,99,235,.10)}
.tester-scale{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin-bottom:18px}
.tester-scale .scale-item{padding:10px 12px;border:1px solid #dbe6f3;border-radius:12px;background:#f8fbff;font-size:12px;line-height:1.35}
.tester-scale strong{display:block;color:#173a68;margin-bottom:3px}
.tester-table-wrap{overflow:auto;border:1px solid #e4ebf4;border-radius:14px}
.tester-table{width:100%;min-width:1080px;border-collapse:separate;border-spacing:0;background:#fff}
.tester-table th,.tester-table td{padding:10px 9px;border-bottom:1px solid #e7edf5;border-right:1px solid #eef2f7;vertical-align:middle;font-size:12px}
.tester-table th:last-child,.tester-table td:last-child{border-right:0}
.tester-table th{background:#f5f9ff;color:#3f5f86;text-align:center;font-weight:800;white-space:nowrap}
.tester-table th.sensory-group{background:linear-gradient(90deg,#edf5ff,#fdf2f8);color:#173a68}
.tester-table td.no{text-align:center;font-weight:800;color:#31577f;width:42px}
.tester-table td.station{font-weight:800;color:#2563eb;width:85px}
.tester-table td.name{font-weight:700;color:#1e3a5f;min-width:150px}
.tester-table input[type=text],.tester-table input[type=number]{width:100%;min-width:0;height:38px;border:1px solid #cfdceb;border-radius:10px;padding:8px 9px;background:#fff;color:#172554;font:inherit;outline:none;box-sizing:border-box}
.tester-table input[type=number]{text-align:center}
.tester-table input[type=text]:focus,.tester-table input[type=number]:focus{border-color:#7aa9ee;box-shadow:0 0 0 3px rgba(37,99,235,.10)}
.tester-table .average{font-weight:800;text-align:center}
.tester-table .resume{font-weight:800;text-align:center;white-space:nowrap}
.resume-waste{color:#b91c1c;background:#fff1f2;border-radius:9px;padding:7px 8px}
.resume-standard{color:#166534;background:#ecfdf3;border-radius:9px;padding:7px 8px}
.tester-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:18px}
.tester-date{max-width:240px}
@media(max-width:760px){
 .tester-info-grid{grid-template-columns:1fr}
 .tester-scale{grid-template-columns:1fr 1fr}
 .tester-actions{flex-direction:column}
 .tester-actions .btn-action{width:100%}
 .tester-date{max-width:none}
}
@media(max-width:480px){.tester-scale{grid-template-columns:1fr}}
</style>

<div class="page-head">
  <div><h2>Input Tester Product</h2><p>Sensory Product 1–4 dengan Average otomatis</p></div>
  <div class="page-actions"><a class="btn-action back" href="datatesterproduct.php">← Kembali</a></div>
</div>

<?php if ($error): ?><div class="alert alert-error"><?=e($error)?></div><?php endif; ?>
<?php if ($success): ?><div class="alert alert-success"><?=e($success)?></div><?php endif; ?>

<form method="post" autocomplete="off">
  <div class="panel">
    <div class="panel-title">Informasi Tester Product</div>
    <div class="form-grid tester-info-grid">
      <label class="tester-field">Tanggal
        <input type="date" name="tanggal" value="<?=e($today)?>" readonly>
      </label>
      <label class="tester-field">Nama Quality Control
        <span class="tester-select-wrap">
          <select name="quality_control" required>
            <option value="">Pilih Quality Control</option>
            <?php foreach ($qcOptions as $qc): ?>
              <option value="<?=e($qc)?>" <?=((string)($_POST['quality_control'] ?? '')===$qc?'selected':'')?>><?=e($qc)?></option>
            <?php endforeach; ?>
          </select>
        </span>
      </label>
      <label class="tester-field">Nama SM
        <input type="text" value="<?=e($namaSM)?>" readonly>
      </label>
    </div>
  </div>

  <div class="panel" style="margin-top:18px;">
    <div class="panel-title">Skala Penilaian Sensory</div>
    <p class="tester-note">Isi nilai sensory <strong>1 sampai 4</strong> untuk Bentuk, Warna, Aroma, Rasa, dan Tekstur. Average dihitung otomatis dari 5 nilai sensory.</p>
    <div class="tester-scale">
      <div class="scale-item"><strong>0–1</strong>Strong Reject<br><b>WASTE</b></div>
      <div class="scale-item"><strong>1,1–2,0</strong>Middle Fail<br><b>WASTE</b></div>
      <div class="scale-item"><strong>2,1–2,9</strong>Borderline Fail<br><b>WASTE</b></div>
      <div class="scale-item"><strong>3,0–4,0</strong>Strong Pass<br><b>PRODUK STANDART</b></div>
    </div>

    <div class="tester-table-wrap">
      <table class="tester-table">
        <thead>
          <tr>
            <th rowspan="2">STATION</th>
            <th rowspan="2">NO</th>
            <th rowspan="2">NAMA BARANG</th>
            <th rowspan="2">QTY<br>SAMPEL</th>
            <th rowspan="2">KODE<br>PRODUKSI</th>
            <th colspan="5" class="sensory-group">SENSORY PRODUCT</th>
            <th rowspan="2">AVERAGE</th>
            <th rowspan="2">RESUME</th>
          </tr>
          <tr>
            <th>BENTUK</th><th>WARNA</th><th>AROMA</th><th>RASA</th><th>TEKSTUR</th>
          </tr>
        </thead>
        <tbody>
        <?php foreach ($items as [$station,$no,$nama]): ?>
          <tr data-row="<?=e($no)?>">
            <td class="station"><?=e($station)?></td>
            <td class="no"><?=e($no)?></td>
            <td class="name"><?=e($nama)?></td>
            <td><input type="number" min="1" name="qty_sampel[<?=e($no)?>]" placeholder="QTY"></td>
            <td><input type="text" name="kode_produksi[<?=e($no)?>]" placeholder="Kode produksi"></td>
            <?php foreach (['bentuk','warna','aroma','rasa','tekstur'] as $key): ?>
              <td><input class="sensory-input" type="number" min="1" max="4" step="1" required name="<?=$key?>[<?=e($no)?>]" data-no="<?=e($no)?>" placeholder="1–4"></td>
            <?php endforeach; ?>
            <td class="average"><span class="avg-value" data-no="<?=e($no)?>">0.00</span></td>
            <td class="resume"><span class="resume-value" data-no="<?=e($no)?>">-</span></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="tester-actions">
      <button type="reset" class="btn-action back">Reset</button>
      <button type="submit" class="btn-action primary">Simpan Data</button>
    </div>
  </div>
</form>

<script>
(function(){
  const scale = [
    {max:1, label:'WASTE'},
    {max:2, label:'WASTE'},
    {max:2.9, label:'WASTE'},
    {max:4, label:'PRODUK STANDART'}
  ];
  function update(no){
    const fields=[...document.querySelectorAll('.sensory-input[data-no="'+no+'"]')];
    const vals=fields.map(el=>Number(el.value)).filter(v=>v>=1&&v<=4);
    const avg=document.querySelector('.avg-value[data-no="'+no+'"]');
    const resume=document.querySelector('.resume-value[data-no="'+no+'"]');
    if(vals.length!==5){avg.textContent='0.00';resume.textContent='-';resume.className='resume-value';return;}
    const a=vals.reduce((s,v)=>s+v,0)/5;
    const rounded=Math.round(a*100)/100;
    avg.textContent=rounded.toFixed(2);
    const label=rounded<=1?'WASTE':(rounded<=2?'WASTE':(rounded<=2.9?'WASTE':'PRODUK STANDART'));
    resume.textContent=label;
    resume.className='resume-value '+(label==='WASTE'?'resume-waste':'resume-standard');
  }
  document.querySelectorAll('.sensory-input').forEach(el=>el.addEventListener('input',()=>update(el.dataset.no)));
})();
</script>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
