<?php $pageTitle='Quality Control'; require __DIR__.'/includes/header.php'; ?>
<div class="page-head">
  <div>
    <h2>Quality Control</h2>
  </div><div class="page-actions"><a class="btn-action back" href="index.php">← Kembali</a></div>
</div>
<section class="cards grid4">
<?php
$items=[
  ['📝','BA Waste','Dokumentasi waste dan pemusnahan','quality_control/ba_waste/databawaste.php'],
  ['🗑️','Pemusnahan','Dokumentasi proses pemusnahan','quality_control/pemusnahan/datapemusnahan.php'],
  ['🧭','Prepare Phase','Checklist prepare phase','quality_control/prepare_phase/datapreparephase.php'],
  ['✅','Pre-Shift Checklist','Pengecekan sebelum operasional','quality_control/pre_shift_checklist/datapreshiftchecklist.php'],
  ['🔎','Product Inspection','Pemeriksaan produk','quality_control/product_inspection/dataproductinspection.php'],
  ['🍜','Tester Product','Pengecekan tester product','quality_control/tester_product/datatesterproduct.php']
];
foreach($items as $it): ?>
<a class="tile" href="<?=$it[3]?>">
  <span class="tile-icon"><?=$it[0]?></span>
  <h3><?=$it[1]?></h3>
  <p><?=$it[2]?></p>
  <span class="mini-arrow">›</span>
</a>
<?php endforeach; ?>
</section>
<?php require __DIR__.'/includes/footer.php'; ?>
