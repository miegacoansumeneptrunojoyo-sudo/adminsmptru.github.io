<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/so_kitchen.php';
require_once __DIR__ . '/../../config/helpers.php';

$stationKey = 'bar';
$station = so_kitchen_station($stationKey);
if (!$station) {
    http_response_code(404);
    exit('Station tidak ditemukan.');
}
$pageTitle = 'Data SO ' . $station['name'];
$tanggal = so_harian_date($_GET['tanggal'] ?? $_POST['tanggal'] ?? null);
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    $tanggal = so_harian_date($_POST['tanggal'] ?? null);
    if (!db_ready()) {
        $error = 'Database belum terhubung.';
    } else {
        $conn->begin_transaction();
        try {
            $st = $conn->prepare('DELETE FROM so_kitchen_stock WHERE tanggal = ? AND station = ?');
            $st->bind_param('ss', $tanggal, $stationKey);
            $st->execute();
            $st->close();
            if (!empty($station['has_process'])) {
                $st = $conn->prepare('DELETE FROM so_kitchen_process WHERE tanggal = ?');
                $st->bind_param('s', $tanggal);
                $st->execute();
                $st->close();
            }
            $conn->commit();
            redirect_to('databar.php?tanggal=' . urlencode($tanggal) . '&deleted=1');
        } catch (Throwable $ex) {
            $conn->rollback();
            $error = 'Data gagal dihapus: ' . $ex->getMessage();
        }
    }
}

$rows = [];
$hasData = false;
$processRows = [];
if (db_ready()) {
    $st = $conn->prepare('SELECT row_no, nama_barang, pcs_gram, pack, ball, biang FROM so_kitchen_stock WHERE tanggal = ? AND station = ? ORDER BY row_no');
    $st->bind_param('ss', $tanggal, $stationKey);
    $st->execute();
    $result = $st->get_result();
    while ($row = $result->fetch_assoc()) {
        $rows[(int)$row['row_no']] = $row;
    }
    $st->close();
    $hasData = count($rows) > 0;
    if (!empty($station['has_process'])) {
        $ps = $conn->prepare('SELECT row_no, cabe_sebelum, cabe_sesudah, ayam_sebelum, ayam_sesudah FROM so_kitchen_process WHERE tanggal = ? ORDER BY row_no');
        $ps->bind_param('s', $tanggal);
        $ps->execute();
        $pr = $ps->get_result();
        while ($row = $pr->fetch_assoc()) {
            $processRows[(int)$row['row_no']] = $row;
        }
        $ps->close();
    }
}

require __DIR__ . '/../../includes/header.php';
?>
<div class="page-head so-data-page-head">
    <div>
        <h2>Data SO <?= e($station['name']) ?></h2>
    </div>
    <div class="page-actions so-data-actions">
        <a class="btn-action back" href="../../sokitchen.php">← Kembali</a>
        <form class="so-date-inline-form" method="get">
            <input type="date" id="tanggal" name="tanggal" value="<?= e($tanggal) ?>" onchange="this.form.submit()">
        </form>
        <a class="btn-action" href="inputbar.php?tanggal=<?= e($tanggal) ?>">✏️ Edit Data</a>
        <a class="btn-action primary" href="inputbar.php?tanggal=<?= e($tanggal) ?>">＋ Input Data</a>
    </div>
</div>

<?php if (isset($_GET['saved'])): ?><?= flash_message('success', 'Data SO ' . $station['name'] . ' berhasil disimpan untuk ' . $tanggal . '.') ?><?php endif; ?>
<?php if (isset($_GET['deleted'])): ?><?= flash_message('success', 'Data SO ' . $station['name'] . ' berhasil dihapus untuk ' . $tanggal . '.') ?><?php endif; ?>
<?php if ($error): ?><?= flash_message('error', $error) ?><?php endif; ?>

<?php if (!$hasData): ?>
    <div class="panel empty-state">
        <div class="empty-icon">📋</div>
        <h3>Belum ada data</h3>
        <p>Belum ada SO <?= e($station['name']) ?> untuk tanggal <?= e($tanggal) ?>.</p><a class="btn-action" href="inputbar.php?tanggal=<?= e($tanggal) ?>">✏️ Edit Data</a><a class="btn-action primary" href="inputbar.php?tanggal=<?= e($tanggal) ?>">＋ Input Data</a>
    </div>
<?php else: ?>
    <div class="panel so-data-panel">
        <div class="so-form-head">
            <div><span class="station-icon">🥤</span>
                <div>
                    <h3><?= e($station['name']) ?></h3>
                    <p>Stock opname — <?= e($tanggal) ?></p>
                </div>
            </div>
            <form method="post" onsubmit="return confirm('Hapus seluruh data station <?= e($station['name']) ?> untuk tanggal ini?');"><input type="hidden" name="action" value="delete"><input type="hidden" name="tanggal" value="<?= e($tanggal) ?>"><button class="btn-action danger" type="submit">🗑 Hapus Data</button></form>
        </div>
        <div class="table-wrap">
            <table class="so-input-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Pcs/Gram</th>
                        <th>Pack</th>
                        <th>Biang</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>AIR MINERAL</td>
                        <td><?= so_display_number($rows[1]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[1]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[1]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>LEMON TEA</td>
                        <td><?= so_display_number($rows[2]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[2]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[2]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>ORANGE</td>
                        <td><?= so_display_number($rows[3]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[3]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[3]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>SIRUP LECHY</td>
                        <td><?= so_display_number($rows[4]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[4]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[4]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>5</td>
                        <td>SIRUP MOCCA</td>
                        <td><?= so_display_number($rows[5]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[5]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[5]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>6</td>
                        <td>SIRUP ROSE</td>
                        <td><?= so_display_number($rows[6]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[6]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[6]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>7</td>
                        <td>SUNQUICK</td>
                        <td><?= so_display_number($rows[7]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[7]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[7]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>8</td>
                        <td>TEA TARIK</td>
                        <td><?= so_display_number($rows[8]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[8]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[8]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>9</td>
                        <td>VANILLA LATTE</td>
                        <td><?= so_display_number($rows[9]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[9]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[9]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>10</td>
                        <td>SUSU KENTAL MANIS (SKM)</td>
                        <td><?= so_display_number($rows[10]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[10]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[10]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>11</td>
                        <td>SUSU UHT</td>
                        <td><?= so_display_number($rows[11]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[11]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[11]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>12</td>
                        <td>BUAH APEL</td>
                        <td><?= so_display_number($rows[12]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[12]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[12]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>13</td>
                        <td>BUAH BELIMBING</td>
                        <td><?= so_display_number($rows[13]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[13]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[13]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>14</td>
                        <td>BUAH PEER</td>
                        <td><?= so_display_number($rows[14]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[14]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[14]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>15</td>
                        <td>BUAH STRAWBERRY</td>
                        <td><?= so_display_number($rows[15]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[15]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[15]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>16</td>
                        <td>CINCAU</td>
                        <td><?= so_display_number($rows[16]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[16]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[16]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>17</td>
                        <td>JELLY BUBBLE</td>
                        <td><?= so_display_number($rows[17]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[17]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[17]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>18</td>
                        <td>JELLY MIE</td>
                        <td><?= so_display_number($rows[18]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[18]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[18]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>19</td>
                        <td>NATA DE COCO</td>
                        <td><?= so_display_number($rows[19]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[19]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[19]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>20</td>
                        <td>BLACK THAI TEA</td>
                        <td><?= so_display_number($rows[20]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[20]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[20]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>21</td>
                        <td>CREAMER</td>
                        <td><?= so_display_number($rows[21]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[21]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[21]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>22</td>
                        <td>GREEN THAI TEA</td>
                        <td><?= so_display_number($rows[22]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[22]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[22]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>23</td>
                        <td>MILO/COKLAT</td>
                        <td><?= so_display_number($rows[23]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[23]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[23]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>24</td>
                        <td>EVAPORASI</td>
                        <td><?= so_display_number($rows[24]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[24]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[24]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>25</td>
                        <td>JERUK NIPIS</td>
                        <td><?= so_display_number($rows[25]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[25]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[25]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>26</td>
                        <td>GULA</td>
                        <td><?= so_display_number($rows[26]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[26]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[26]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>27</td>
                        <td>TEA GOPEK</td>
                        <td><?= so_display_number($rows[27]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[27]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[27]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>28</td>
                        <td>TEA NAGA</td>
                        <td><?= so_display_number($rows[28]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[28]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[28]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>29</td>
                        <td>GALON</td>
                        <td><?= so_display_number($rows[29]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[29]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[29]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>30</td>
                        <td>ES TUBE</td>
                        <td><?= so_display_number($rows[30]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[30]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[30]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>31</td>
                        <td>CUP 12</td>
                        <td><?= so_display_number($rows[31]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[31]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[31]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>32</td>
                        <td>CUP 14</td>
                        <td><?= so_display_number($rows[32]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[32]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[32]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>33</td>
                        <td>CUP 16</td>
                        <td><?= so_display_number($rows[33]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[33]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[33]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>34</td>
                        <td>CUP SEALER</td>
                        <td><?= so_display_number($rows[34]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[34]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[34]['biang'] ?? null) ?></td>
                    </tr>
                    <tr>
                        <td>35</td>
                        <td>CUP SEALER</td>
                        <td><?= so_display_number($rows[35]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[35]['pack'] ?? null) ?></td>
                        <td><?= so_display_number($rows[35]['biang'] ?? null) ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

<?php endif; ?>
<?php require __DIR__ . '/../../includes/footer.php'; ?>