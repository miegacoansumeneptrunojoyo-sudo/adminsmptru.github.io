<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/so_kitchen.php';
require_once __DIR__ . '/../../config/helpers.php';

$stationKey = 'bar';
$station = so_kitchen_station($stationKey);
if (!$station) { http_response_code(404); exit('Station tidak ditemukan.'); }
$pageTitle = 'Input SO ' . $station['name'];
$tanggal = so_harian_date($_GET['tanggal'] ?? $_POST['tanggal'] ?? null);
$success = '';
$error = '';

function num_or_null($value): ?float {
    if ($value === null || $value === '') return null;
    $value = str_replace(',', '.', trim((string)$value));
    return is_numeric($value) ? (float)$value : null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal = so_harian_date($_POST['tanggal'] ?? null);
    if (!db_ready()) {
        $error = 'Database belum terhubung. Import database/adminsmptru.sql lalu periksa config/database.php.';
    } else {
        $pcs = $_POST['pcs_gram'] ?? [];
        $pack = $_POST['pack'] ?? [];
        $ball = $_POST['ball'] ?? [];
        $biang = $_POST['biang'] ?? [];
        $conn->begin_transaction();
        try {
            $del = $conn->prepare('DELETE FROM so_kitchen_stock WHERE tanggal = ? AND station = ?');
            $del->bind_param('ss', $tanggal, $stationKey);
            $del->execute();
            $del->close();

            $ins = $conn->prepare('INSERT INTO so_kitchen_stock (tanggal, station, row_no, nama_barang, pcs_gram, pack, ball, biang) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
            foreach ($station['items'] as $i => $itemName) {
                $rowNo = $i + 1;
                $vPcs = num_or_null($pcs[$rowNo] ?? null);
                $vPack = num_or_null($pack[$rowNo] ?? null);
                $vBall = in_array('ball', $station['columns'], true) ? num_or_null($ball[$rowNo] ?? null) : null;
                $vBiang = in_array('biang', $station['columns'], true) ? num_or_null($biang[$rowNo] ?? null) : null;
                $ins->bind_param('ssisdddd', $tanggal, $stationKey, $rowNo, $itemName, $vPcs, $vPack, $vBall, $vBiang);
                $ins->execute();
            }
            $ins->close();

            if (!empty($station['has_process'])) {
                $delP = $conn->prepare('DELETE FROM so_kitchen_process WHERE tanggal = ?');
                $delP->bind_param('s', $tanggal);
                $delP->execute();
                $delP->close();

                $cBefore = $_POST['cabe_sebelum'] ?? [];
                $cAfter = $_POST['cabe_sesudah'] ?? [];
                $aBefore = $_POST['ayam_sebelum'] ?? [];
                $aAfter = $_POST['ayam_sesudah'] ?? [];
                $insP = $conn->prepare('INSERT INTO so_kitchen_process (tanggal, row_no, cabe_sebelum, cabe_sesudah, ayam_sebelum, ayam_sesudah) VALUES (?, ?, ?, ?, ?, ?)');
                for ($i = 1; $i <= 20; $i++) {
                    $cv1 = num_or_null($cBefore[$i] ?? null);
                    $cv2 = num_or_null($cAfter[$i] ?? null);
                    $av1 = num_or_null($aBefore[$i] ?? null);
                    $av2 = num_or_null($aAfter[$i] ?? null);
                    $insP->bind_param('sidddd', $tanggal, $i, $cv1, $cv2, $av1, $av2);
                    $insP->execute();
                }
                $insP->close();
            }

            $conn->commit();
            header('Location: databar.php?tanggal=' . urlencode($tanggal) . '&saved=1');
            exit;
        } catch (Throwable $ex) {
            $conn->rollback();
            $error = 'Data gagal disimpan: ' . $ex->getMessage();
        }
    }
}

$existing = [];
$processExisting = [];
if (db_ready()) {
    $stmt = $conn->prepare('SELECT row_no, pcs_gram, pack, ball, biang FROM so_kitchen_stock WHERE tanggal = ? AND station = ? ORDER BY row_no');
    $stmt->bind_param('ss', $tanggal, $stationKey);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) { $existing[(int)$row['row_no']] = $row; }
    $stmt->close();

    if (!empty($station['has_process'])) {
        $ps = $conn->prepare('SELECT row_no, cabe_sebelum, cabe_sesudah, ayam_sebelum, ayam_sesudah FROM so_kitchen_process WHERE tanggal = ? ORDER BY row_no');
        $ps->bind_param('s', $tanggal);
        $ps->execute();
        $pr = $ps->get_result();
        while ($row = $pr->fetch_assoc()) { $processExisting[(int)$row['row_no']] = $row; }
        $ps->close();
    }
}

require __DIR__ . '/../../includes/header.php';
?>
<div class="page-head">
  <div>
    <small>Dashboard › SO Kitchen › <?=e($station['name'])?> › Input</small>
    <h2>Input SO <?=e($station['name'])?></h2>
  </div>
  <div class="page-actions">
    <a class="btn-action back" href="databar.php?tanggal=<?=e($tanggal)?>">← Kembali</a>
  </div>
</div>
<?php if ($error): ?><?=flash_message('error', $error)?><?php endif; ?>
<?php if ($success): ?><?=flash_message('success', $success)?><?php endif; ?>

<form method="post" class="so-entry-form">
  <div class="panel so-form-panel">
    <div class="so-form-head">
      <div class="station-title-wrap">
        <div class="station-title-main">
          <span class="station-icon">🥤</span>
          <div><h3><?=e($station['name'])?></h3><p><?=e($station['description'])?></p></div>
        </div>
      </div>
      <div class="so-inline-date">
        <label for="tanggal">Tanggal</label>
        <input type="date" name="tanggal" id="tanggal" value="<?=e($tanggal)?>" required>
      </div>
    </div>
    <div class="table-wrap">
      <table class="so-input-table">
        <thead><tr><th>No</th><th>Nama Barang</th><th>Pcs/Gram</th><th>Pack</th><th>Biang</th></tr></thead>
        <tbody>
        <tr><td>1</td><td>AIR MINERAL</td><td><input type="number" step="0.01" min="0" name="pcs_gram[1]" value="<?=so_input_value($existing[1]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[1]" value="<?=so_input_value($existing[1]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[1]" value="<?=so_input_value($existing[1] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>2</td><td>LEMON TEA</td><td><input type="number" step="0.01" min="0" name="pcs_gram[2]" value="<?=so_input_value($existing[2]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[2]" value="<?=so_input_value($existing[2]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[2]" value="<?=so_input_value($existing[2] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>3</td><td>ORANGE</td><td><input type="number" step="0.01" min="0" name="pcs_gram[3]" value="<?=so_input_value($existing[3]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[3]" value="<?=so_input_value($existing[3]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[3]" value="<?=so_input_value($existing[3] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>4</td><td>SIRUP LECHY</td><td><input type="number" step="0.01" min="0" name="pcs_gram[4]" value="<?=so_input_value($existing[4]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[4]" value="<?=so_input_value($existing[4]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[4]" value="<?=so_input_value($existing[4] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>5</td><td>SIRUP MOCCA</td><td><input type="number" step="0.01" min="0" name="pcs_gram[5]" value="<?=so_input_value($existing[5]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[5]" value="<?=so_input_value($existing[5]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[5]" value="<?=so_input_value($existing[5] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>6</td><td>SIRUP ROSE</td><td><input type="number" step="0.01" min="0" name="pcs_gram[6]" value="<?=so_input_value($existing[6]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[6]" value="<?=so_input_value($existing[6]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[6]" value="<?=so_input_value($existing[6] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>7</td><td>SUNQUICK</td><td><input type="number" step="0.01" min="0" name="pcs_gram[7]" value="<?=so_input_value($existing[7]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[7]" value="<?=so_input_value($existing[7]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[7]" value="<?=so_input_value($existing[7] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>8</td><td>TEA TARIK</td><td><input type="number" step="0.01" min="0" name="pcs_gram[8]" value="<?=so_input_value($existing[8]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[8]" value="<?=so_input_value($existing[8]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[8]" value="<?=so_input_value($existing[8] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>9</td><td>VANILLA LATTE</td><td><input type="number" step="0.01" min="0" name="pcs_gram[9]" value="<?=so_input_value($existing[9]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[9]" value="<?=so_input_value($existing[9]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[9]" value="<?=so_input_value($existing[9] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>10</td><td>SUSU KENTAL MANIS (SKM)</td><td><input type="number" step="0.01" min="0" name="pcs_gram[10]" value="<?=so_input_value($existing[10]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[10]" value="<?=so_input_value($existing[10]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[10]" value="<?=so_input_value($existing[10] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>11</td><td>SUSU UHT</td><td><input type="number" step="0.01" min="0" name="pcs_gram[11]" value="<?=so_input_value($existing[11]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[11]" value="<?=so_input_value($existing[11]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[11]" value="<?=so_input_value($existing[11] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>12</td><td>BUAH APEL</td><td><input type="number" step="0.01" min="0" name="pcs_gram[12]" value="<?=so_input_value($existing[12]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[12]" value="<?=so_input_value($existing[12]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[12]" value="<?=so_input_value($existing[12] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>13</td><td>BUAH BELIMBING</td><td><input type="number" step="0.01" min="0" name="pcs_gram[13]" value="<?=so_input_value($existing[13]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[13]" value="<?=so_input_value($existing[13]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[13]" value="<?=so_input_value($existing[13] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>14</td><td>BUAH PEER</td><td><input type="number" step="0.01" min="0" name="pcs_gram[14]" value="<?=so_input_value($existing[14]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[14]" value="<?=so_input_value($existing[14]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[14]" value="<?=so_input_value($existing[14] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>15</td><td>BUAH STRAWBERRY</td><td><input type="number" step="0.01" min="0" name="pcs_gram[15]" value="<?=so_input_value($existing[15]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[15]" value="<?=so_input_value($existing[15]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[15]" value="<?=so_input_value($existing[15] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>16</td><td>CINCAU</td><td><input type="number" step="0.01" min="0" name="pcs_gram[16]" value="<?=so_input_value($existing[16]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[16]" value="<?=so_input_value($existing[16]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[16]" value="<?=so_input_value($existing[16] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>17</td><td>JELLY BUBBLE</td><td><input type="number" step="0.01" min="0" name="pcs_gram[17]" value="<?=so_input_value($existing[17]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[17]" value="<?=so_input_value($existing[17]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[17]" value="<?=so_input_value($existing[17] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>18</td><td>JELLY MIE</td><td><input type="number" step="0.01" min="0" name="pcs_gram[18]" value="<?=so_input_value($existing[18]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[18]" value="<?=so_input_value($existing[18]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[18]" value="<?=so_input_value($existing[18] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>19</td><td>NATA DE COCO</td><td><input type="number" step="0.01" min="0" name="pcs_gram[19]" value="<?=so_input_value($existing[19]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[19]" value="<?=so_input_value($existing[19]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[19]" value="<?=so_input_value($existing[19] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>20</td><td>BLACK THAI TEA</td><td><input type="number" step="0.01" min="0" name="pcs_gram[20]" value="<?=so_input_value($existing[20]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[20]" value="<?=so_input_value($existing[20]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[20]" value="<?=so_input_value($existing[20] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>21</td><td>CREAMER</td><td><input type="number" step="0.01" min="0" name="pcs_gram[21]" value="<?=so_input_value($existing[21]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[21]" value="<?=so_input_value($existing[21]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[21]" value="<?=so_input_value($existing[21] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>22</td><td>GREEN THAI TEA</td><td><input type="number" step="0.01" min="0" name="pcs_gram[22]" value="<?=so_input_value($existing[22]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[22]" value="<?=so_input_value($existing[22]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[22]" value="<?=so_input_value($existing[22] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>23</td><td>MILO/COKLAT</td><td><input type="number" step="0.01" min="0" name="pcs_gram[23]" value="<?=so_input_value($existing[23]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[23]" value="<?=so_input_value($existing[23]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[23]" value="<?=so_input_value($existing[23] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>24</td><td>EVAPORASI</td><td><input type="number" step="0.01" min="0" name="pcs_gram[24]" value="<?=so_input_value($existing[24]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[24]" value="<?=so_input_value($existing[24]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[24]" value="<?=so_input_value($existing[24] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>25</td><td>JERUK NIPIS</td><td><input type="number" step="0.01" min="0" name="pcs_gram[25]" value="<?=so_input_value($existing[25]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[25]" value="<?=so_input_value($existing[25]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[25]" value="<?=so_input_value($existing[25] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>26</td><td>GULA</td><td><input type="number" step="0.01" min="0" name="pcs_gram[26]" value="<?=so_input_value($existing[26]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[26]" value="<?=so_input_value($existing[26]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[26]" value="<?=so_input_value($existing[26] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>27</td><td>TEA GOPEK</td><td><input type="number" step="0.01" min="0" name="pcs_gram[27]" value="<?=so_input_value($existing[27]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[27]" value="<?=so_input_value($existing[27]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[27]" value="<?=so_input_value($existing[27] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>28</td><td>TEA NAGA</td><td><input type="number" step="0.01" min="0" name="pcs_gram[28]" value="<?=so_input_value($existing[28]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[28]" value="<?=so_input_value($existing[28]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[28]" value="<?=so_input_value($existing[28] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>29</td><td>GALON</td><td><input type="number" step="0.01" min="0" name="pcs_gram[29]" value="<?=so_input_value($existing[29]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[29]" value="<?=so_input_value($existing[29]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[29]" value="<?=so_input_value($existing[29] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>30</td><td>ES TUBE</td><td><input type="number" step="0.01" min="0" name="pcs_gram[30]" value="<?=so_input_value($existing[30]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[30]" value="<?=so_input_value($existing[30]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[30]" value="<?=so_input_value($existing[30] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>31</td><td>CUP 12</td><td><input type="number" step="0.01" min="0" name="pcs_gram[31]" value="<?=so_input_value($existing[31]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[31]" value="<?=so_input_value($existing[31]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[31]" value="<?=so_input_value($existing[31] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>32</td><td>CUP 14</td><td><input type="number" step="0.01" min="0" name="pcs_gram[32]" value="<?=so_input_value($existing[32]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[32]" value="<?=so_input_value($existing[32]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[32]" value="<?=so_input_value($existing[32] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>33</td><td>CUP 16</td><td><input type="number" step="0.01" min="0" name="pcs_gram[33]" value="<?=so_input_value($existing[33]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[33]" value="<?=so_input_value($existing[33]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[33]" value="<?=so_input_value($existing[33] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>34</td><td>CUP SEALER</td><td><input type="number" step="0.01" min="0" name="pcs_gram[34]" value="<?=so_input_value($existing[34]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[34]" value="<?=so_input_value($existing[34]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[34]" value="<?=so_input_value($existing[34] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>35</td><td>CUP SEALER</td><td><input type="number" step="0.01" min="0" name="pcs_gram[35]" value="<?=so_input_value($existing[35]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[35]" value="<?=so_input_value($existing[35]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="biang[35]" value="<?=so_input_value($existing[35] ['biang'] ?? '')?>" inputmode="decimal"></td></tr>
        </tbody>
      </table>
    </div>
  </div>

  

  <div class="form-submit-bar">
    <a class="btn-action back" href="databar.php?tanggal=<?=e($tanggal)?>">Batal</a>
    <button type="submit" class="btn-action primary">💾 Simpan Data</button>
  </div>
</form>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
