<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/so_kitchen.php';
require_once __DIR__ . '/../../config/helpers.php';

$stationKey = 'kasir';
$station = so_kitchen_station($stationKey);
if (!$station) {
    http_response_code(404);
    exit('Station tidak ditemukan.');
}
$pageTitle = 'Data SO ' . $station['name'];
$tanggal = so_harian_date($_GET['tanggal'] ?? $_POST['tanggal'] ?? null);
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    $tanggal = so_harian_date($_POST['tanggal'] ?? null);
    if (!db_ready()) {
        $error = 'Database belum terhubung.';
    } else {
        $conn->begin_transaction();
        try {
            $st = $conn->prepare('DELETE FROM so_kitchen_stock WHERE tanggal = ? AND station = ?');
            $st->bind_param('ss', $tanggal, $stationKey);
            $st->execute();
            $st->close();
            if (!empty($station['has_process'])) {
                $st = $conn->prepare('DELETE FROM so_kitchen_process WHERE tanggal = ?');
                $st->bind_param('s', $tanggal);
                $st->execute();
                $st->close();
            }
            $conn->commit();
            redirect_to('datakasir.php?tanggal=' . urlencode($tanggal) . '&deleted=1');
        } catch (Throwable $ex) {
            $conn->rollback();
            $error = 'Data gagal dihapus: ' . $ex->getMessage();
        }
    }
}

$rows = [];
$hasData = false;
$processRows = [];
if (db_ready()) {
    $st = $conn->prepare('SELECT row_no, nama_barang, pcs_gram, pack, ball, biang FROM so_kitchen_stock WHERE tanggal = ? AND station = ? ORDER BY row_no');
    $st->bind_param('ss', $tanggal, $stationKey);
    $st->execute();
    $result = $st->get_result();
    while ($row = $result->fetch_assoc()) {
        $rows[(int)$row['row_no']] = $row;
    }
    $st->close();
    $hasData = count($rows) > 0;
    if (!empty($station['has_process'])) {
        $ps = $conn->prepare('SELECT row_no, cabe_sebelum, cabe_sesudah, ayam_sebelum, ayam_sesudah FROM so_kitchen_process WHERE tanggal = ? ORDER BY row_no');
        $ps->bind_param('s', $tanggal);
        $ps->execute();
        $pr = $ps->get_result();
        while ($row = $pr->fetch_assoc()) {
            $processRows[(int)$row['row_no']] = $row;
        }
        $ps->close();
    }
}

require __DIR__ . '/../../includes/header.php';
?>
<div class="page-head so-data-page-head">
    <div>
        <h2>Data SO <?= e($station['name']) ?></h2>
    </div>
    <div class="page-actions so-data-actions">
        <a class="btn-action back" href="../../sokitchen.php">← Kembali</a>
        <form class="so-date-inline-form" method="get">
            <input type="date" id="tanggal" name="tanggal" value="<?= e($tanggal) ?>" onchange="this.form.submit()">
        </form>
        <a class="btn-action" href="inputkasir.php?tanggal=<?= e($tanggal) ?>">✏️ Edit Data</a>
        <a class="btn-action primary" href="inputkasir.php?tanggal=<?= e($tanggal) ?>">＋ Input Data</a>
    </div>
</div>

<?php if (isset($_GET['saved'])): ?><?= flash_message('success', 'Data SO ' . $station['name'] . ' berhasil disimpan untuk ' . $tanggal . '.') ?><?php endif; ?>
<?php if (isset($_GET['deleted'])): ?><?= flash_message('success', 'Data SO ' . $station['name'] . ' berhasil dihapus untuk ' . $tanggal . '.') ?><?php endif; ?>
<?php if ($error): ?><?= flash_message('error', $error) ?><?php endif; ?>

<?php if (!$hasData): ?>
    <div class="panel empty-state">
        <div class="empty-icon">📋</div>
        <h3>Belum ada data</h3>
        <p>Belum ada SO <?= e($station['name']) ?> untuk tanggal <?= e($tanggal) ?>.</p><a class="btn-action" href="inputkasir.php?tanggal=<?= e($tanggal) ?>">✏️ Edit Data</a><a class="btn-action primary" href="inputkasir.php?tanggal=<?= e($tanggal) ?>">＋ Input Data</a>
    </div>
<?php else: ?>
    <div class="panel so-data-panel">
        <div class="so-form-head">
            <div><span class="station-icon">🧾</span>
                <div>
                    <h3><?= e($station['name']) ?></h3>
                    <p>Stock opname — <?= e($tanggal) ?></p>
                </div>
            </div>
            <form method="post" onsubmit="return confirm('Hapus seluruh data station <?= e($station['name']) ?> untuk tanggal ini?');"><input type="hidden" name="action" value="delete"><input type="hidden" name="tanggal" value="<?= e($tanggal) ?>"><button class="btn-action danger" type="submit">🗑 Hapus Data</button></form>
        </div>
        <div class="table-wrap">
            <table class="so-input-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Barang</th>
                        <th>Pcs/Gram</th>
                        <th>Pack</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>KERTAS THERMAL PRINTER</td>
                        <td><?= so_display_number($rows[1]['pcs_gram'] ?? null) ?></td>
                        <td><?= so_display_number($rows[1]['pack'] ?? null) ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

<?php endif; ?>
<?php require __DIR__ . '/../../includes/footer.php'; ?>