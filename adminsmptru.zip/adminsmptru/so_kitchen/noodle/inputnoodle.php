<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/so_kitchen.php';
require_once __DIR__ . '/../../config/helpers.php';

$stationKey = 'noodle';
$station = so_kitchen_station($stationKey);
if (!$station) { http_response_code(404); exit('Station tidak ditemukan.'); }
$pageTitle = 'Input SO ' . $station['name'];
$tanggal = so_harian_date($_GET['tanggal'] ?? $_POST['tanggal'] ?? null);
$success = '';
$error = '';

function num_or_null($value): ?float {
    if ($value === null || $value === '') return null;
    $value = str_replace(',', '.', trim((string)$value));
    return is_numeric($value) ? (float)$value : null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal = so_harian_date($_POST['tanggal'] ?? null);
    if (!db_ready()) {
        $error = 'Database belum terhubung. Import database/adminsmptru.sql lalu periksa config/database.php.';
    } else {
        $pcs = $_POST['pcs_gram'] ?? [];
        $pack = $_POST['pack'] ?? [];
        $ball = $_POST['ball'] ?? [];
        $biang = $_POST['biang'] ?? [];
        $conn->begin_transaction();
        try {
            $del = $conn->prepare('DELETE FROM so_kitchen_stock WHERE tanggal = ? AND station = ?');
            $del->bind_param('ss', $tanggal, $stationKey);
            $del->execute();
            $del->close();

            $ins = $conn->prepare('INSERT INTO so_kitchen_stock (tanggal, station, row_no, nama_barang, pcs_gram, pack, ball, biang) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
            foreach ($station['items'] as $i => $itemName) {
                $rowNo = $i + 1;
                $vPcs = num_or_null($pcs[$rowNo] ?? null);
                $vPack = num_or_null($pack[$rowNo] ?? null);
                $vBall = in_array('ball', $station['columns'], true) ? num_or_null($ball[$rowNo] ?? null) : null;
                $vBiang = in_array('biang', $station['columns'], true) ? num_or_null($biang[$rowNo] ?? null) : null;
                $ins->bind_param('ssisdddd', $tanggal, $stationKey, $rowNo, $itemName, $vPcs, $vPack, $vBall, $vBiang);
                $ins->execute();
            }
            $ins->close();

            if (!empty($station['has_process'])) {
                $delP = $conn->prepare('DELETE FROM so_kitchen_process WHERE tanggal = ?');
                $delP->bind_param('s', $tanggal);
                $delP->execute();
                $delP->close();

                $cBefore = $_POST['cabe_sebelum'] ?? [];
                $cAfter = $_POST['cabe_sesudah'] ?? [];
                $aBefore = $_POST['ayam_sebelum'] ?? [];
                $aAfter = $_POST['ayam_sesudah'] ?? [];
                $insP = $conn->prepare('INSERT INTO so_kitchen_process (tanggal, row_no, cabe_sebelum, cabe_sesudah, ayam_sebelum, ayam_sesudah) VALUES (?, ?, ?, ?, ?, ?)');
                for ($i = 1; $i <= 20; $i++) {
                    $cv1 = num_or_null($cBefore[$i] ?? null);
                    $cv2 = num_or_null($cAfter[$i] ?? null);
                    $av1 = num_or_null($aBefore[$i] ?? null);
                    $av2 = num_or_null($aAfter[$i] ?? null);
                    $insP->bind_param('sidddd', $tanggal, $i, $cv1, $cv2, $av1, $av2);
                    $insP->execute();
                }
                $insP->close();
            }

            $conn->commit();
            header('Location: datanoodle.php?tanggal=' . urlencode($tanggal) . '&saved=1');
            exit;
        } catch (Throwable $ex) {
            $conn->rollback();
            $error = 'Data gagal disimpan: ' . $ex->getMessage();
        }
    }
}

$existing = [];
$processExisting = [];
if (db_ready()) {
    $stmt = $conn->prepare('SELECT row_no, pcs_gram, pack, ball, biang FROM so_kitchen_stock WHERE tanggal = ? AND station = ? ORDER BY row_no');
    $stmt->bind_param('ss', $tanggal, $stationKey);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) { $existing[(int)$row['row_no']] = $row; }
    $stmt->close();

    if (!empty($station['has_process'])) {
        $ps = $conn->prepare('SELECT row_no, cabe_sebelum, cabe_sesudah, ayam_sebelum, ayam_sesudah FROM so_kitchen_process WHERE tanggal = ? ORDER BY row_no');
        $ps->bind_param('s', $tanggal);
        $ps->execute();
        $pr = $ps->get_result();
        while ($row = $pr->fetch_assoc()) { $processExisting[(int)$row['row_no']] = $row; }
        $ps->close();
    }
}

require __DIR__ . '/../../includes/header.php';
?>
<div class="page-head">
  <div>
    <small>Dashboard › SO Kitchen › <?=e($station['name'])?> › Input</small>
    <h2>Input SO <?=e($station['name'])?></h2>
  </div>
  <div class="page-actions">
    <a class="btn-action back" href="datanoodle.php?tanggal=<?=e($tanggal)?>">← Kembali</a>
  </div>
</div>
<?php if ($error): ?><?=flash_message('error', $error)?><?php endif; ?>
<?php if ($success): ?><?=flash_message('success', $success)?><?php endif; ?>

<form method="post" class="so-entry-form">
  <div class="panel so-form-panel">
    <div class="so-form-head">
      <div class="station-title-wrap">
        <div class="station-title-main">
          <span class="station-icon">🍜</span>
          <div><h3><?=e($station['name'])?></h3><p><?=e($station['description'])?></p></div>
        </div>
      </div>
      <div class="so-inline-date">
        <label for="tanggal">Tanggal</label>
        <input type="date" name="tanggal" id="tanggal" value="<?=e($tanggal)?>" required>
      </div>
    </div>
    <div class="table-wrap">
      <table class="so-input-table">
        <thead><tr><th>No</th><th>Nama Barang</th><th>Pcs/Gram</th><th>Pack</th></tr></thead>
        <tbody>
        <tr><td>1</td><td>CABE RAWIT</td><td><input type="number" step="0.01" min="0" name="pcs_gram[1]" value="<?=so_input_value($existing[1]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[1]" value="<?=so_input_value($existing[1]['pack'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>2</td><td>MIE</td><td><input type="number" step="0.01" min="0" name="pcs_gram[2]" value="<?=so_input_value($existing[2]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[2]" value="<?=so_input_value($existing[2]['pack'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>3</td><td>KECAP</td><td><input type="number" step="0.01" min="0" name="pcs_gram[3]" value="<?=so_input_value($existing[3]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[3]" value="<?=so_input_value($existing[3]['pack'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>4</td><td>BASIC MIE</td><td><input type="number" step="0.01" min="0" name="pcs_gram[4]" value="<?=so_input_value($existing[4]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[4]" value="<?=so_input_value($existing[4]['pack'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>5</td><td>AYAM CINCANG</td><td><input type="number" step="0.01" min="0" name="pcs_gram[5]" value="<?=so_input_value($existing[5]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[5]" value="<?=so_input_value($existing[5]['pack'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>6</td><td>BAWANG GORENG</td><td><input type="number" step="0.01" min="0" name="pcs_gram[6]" value="<?=so_input_value($existing[6]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[6]" value="<?=so_input_value($existing[6]['pack'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>7</td><td>MINYAK MIE</td><td><input type="number" step="0.01" min="0" name="pcs_gram[7]" value="<?=so_input_value($existing[7]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[7]" value="<?=so_input_value($existing[7]['pack'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>8</td><td>PANGSIT GORENG</td><td><input type="number" step="0.01" min="0" name="pcs_gram[8]" value="<?=so_input_value($existing[8]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[8]" value="<?=so_input_value($existing[8]['pack'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>9</td><td>DAUN BAWANG</td><td><input type="number" step="0.01" min="0" name="pcs_gram[9]" value="<?=so_input_value($existing[9]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[9]" value="<?=so_input_value($existing[9]['pack'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>10</td><td>KERUPUK</td><td><input type="number" step="0.01" min="0" name="pcs_gram[10]" value="<?=so_input_value($existing[10]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[10]" value="<?=so_input_value($existing[10]['pack'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>11</td><td>FOAM MIE</td><td><input type="number" step="0.01" min="0" name="pcs_gram[11]" value="<?=so_input_value($existing[11]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[11]" value="<?=so_input_value($existing[11]['pack'] ?? '')?>" inputmode="decimal"></td></tr>
        </tbody>
      </table>
    </div>
  </div>

  

  <div class="form-submit-bar">
    <a class="btn-action back" href="datanoodle.php?tanggal=<?=e($tanggal)?>">Batal</a>
    <button type="submit" class="btn-action primary">💾 Simpan Data</button>
  </div>
</form>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
