<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/so_kitchen.php';
require_once __DIR__ . '/../../config/helpers.php';

$stationKey = 'produksi';
$station = so_kitchen_station($stationKey);
if (!$station) {
  http_response_code(404);
  exit('Station tidak ditemukan.');
}
$pageTitle = 'Data SO ' . $station['name'];
$tanggal = so_harian_date($_GET['tanggal'] ?? $_POST['tanggal'] ?? null);
$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
  $tanggal = so_harian_date($_POST['tanggal'] ?? null);
  if (!db_ready()) {
    $error = 'Database belum terhubung.';
  } else {
    $conn->begin_transaction();
    try {
      $st = $conn->prepare('DELETE FROM so_kitchen_stock WHERE tanggal = ? AND station = ?');
      $st->bind_param('ss', $tanggal, $stationKey);
      $st->execute();
      $st->close();
      if (!empty($station['has_process'])) {
        $st = $conn->prepare('DELETE FROM so_kitchen_process WHERE tanggal = ?');
        $st->bind_param('s', $tanggal);
        $st->execute();
        $st->close();
      }
      $conn->commit();
      redirect_to('dataproduksi.php?tanggal=' . urlencode($tanggal) . '&deleted=1');
    } catch (Throwable $ex) {
      $conn->rollback();
      $error = 'Data gagal dihapus: ' . $ex->getMessage();
    }
  }
}

$rows = [];
$hasData = false;
$processRows = [];
if (db_ready()) {
  $st = $conn->prepare('SELECT row_no, nama_barang, pcs_gram, pack, ball, biang FROM so_kitchen_stock WHERE tanggal = ? AND station = ? ORDER BY row_no');
  $st->bind_param('ss', $tanggal, $stationKey);
  $st->execute();
  $result = $st->get_result();
  while ($row = $result->fetch_assoc()) {
    $rows[(int)$row['row_no']] = $row;
  }
  $st->close();
  $hasData = count($rows) > 0;
  if (!empty($station['has_process'])) {
    $ps = $conn->prepare('SELECT row_no, cabe_sebelum, cabe_sesudah, ayam_sebelum, ayam_sesudah FROM so_kitchen_process WHERE tanggal = ? ORDER BY row_no');
    $ps->bind_param('s', $tanggal);
    $ps->execute();
    $pr = $ps->get_result();
    while ($row = $pr->fetch_assoc()) {
      $processRows[(int)$row['row_no']] = $row;
    }
    $ps->close();
  }
}

require __DIR__ . '/../../includes/header.php';
?>
<div class="page-head so-data-page-head">
  <div>
    <h2>Data SO <?= e($station['name']) ?></h2>
  </div>
  <div class="page-actions so-data-actions">
    <a class="btn-action back" href="../../sokitchen.php">← Kembali</a>
    <form class="so-date-inline-form" method="get">
      <input type="date" id="tanggal" name="tanggal" value="<?= e($tanggal) ?>" onchange="this.form.submit()">
    </form>
    <a class="btn-action" href="inputproduksi.php?tanggal=<?= e($tanggal) ?>">✏️ Edit Data</a>
    <a class="btn-action primary" href="inputproduksi.php?tanggal=<?= e($tanggal) ?>">＋ Input Data</a>
  </div>
</div>

<?php if (isset($_GET['saved'])): ?><?= flash_message('success', 'Data SO ' . $station['name'] . ' berhasil disimpan untuk ' . $tanggal . '.') ?><?php endif; ?>
<?php if (isset($_GET['deleted'])): ?><?= flash_message('success', 'Data SO ' . $station['name'] . ' berhasil dihapus untuk ' . $tanggal . '.') ?><?php endif; ?>
<?php if ($error): ?><?= flash_message('error', $error) ?><?php endif; ?>

<?php if (!$hasData): ?>
  <div class="panel empty-state">
    <div class="empty-icon">📋</div>
    <h3>Belum ada data</h3>
    <p>Belum ada SO <?= e($station['name']) ?> untuk tanggal <?= e($tanggal) ?>.</p><a class="btn-action" href="inputproduksi.php?tanggal=<?= e($tanggal) ?>">✏️ Edit Data</a><a class="btn-action primary" href="inputproduksi.php?tanggal=<?= e($tanggal) ?>">＋ Input Data</a>
  </div>
<?php else: ?>
  <div class="panel so-data-panel">
    <div class="so-form-head">
      <div><span class="station-icon">🏭</span>
        <div>
          <h3><?= e($station['name']) ?></h3>
          <p>Stock opname — <?= e($tanggal) ?></p>
        </div>
      </div>
      <form method="post" onsubmit="return confirm('Hapus seluruh data station <?= e($station['name']) ?> untuk tanggal ini?');"><input type="hidden" name="action" value="delete"><input type="hidden" name="tanggal" value="<?= e($tanggal) ?>"><button class="btn-action danger" type="submit">🗑 Hapus Data</button></form>
    </div>
    <div class="table-wrap">
      <table class="so-input-table">
        <thead>
          <tr>
            <th>No</th>
            <th>Nama Barang</th>
            <th>Pcs/Gram</th>
            <th>Pack</th>
            <th>Ball</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>1</td>
            <td>ADONAN PANGSIT</td>
            <td><?= so_display_number($rows[1]['pcs_gram'] ?? null) ?></td>
            <td><?= so_display_number($rows[1]['pack'] ?? null) ?></td>
            <td><?= so_display_number($rows[1]['ball'] ?? null) ?></td>
          </tr>
          <tr>
            <td>2</td>
            <td>CABE UTUH</td>
            <td><?= so_display_number($rows[2]['pcs_gram'] ?? null) ?></td>
            <td><?= so_display_number($rows[2]['pack'] ?? null) ?></td>
            <td><?= so_display_number($rows[2]['ball'] ?? null) ?></td>
          </tr>
          <tr>
            <td>3</td>
            <td>AYAM CINCANG</td>
            <td><?= so_display_number($rows[3]['pcs_gram'] ?? null) ?></td>
            <td><?= so_display_number($rows[3]['pack'] ?? null) ?></td>
            <td><?= so_display_number($rows[3]['ball'] ?? null) ?></td>
          </tr>
          <tr>
            <td>4</td>
            <td>KULIT PANGSIT</td>
            <td><?= so_display_number($rows[4]['pcs_gram'] ?? null) ?></td>
            <td><?= so_display_number($rows[4]['pack'] ?? null) ?></td>
            <td><?= so_display_number($rows[4]['ball'] ?? null) ?></td>
          </tr>
          <tr>
            <td>5</td>
            <td>KERUPUK MIE MENTAH</td>
            <td><?= so_display_number($rows[5]['pcs_gram'] ?? null) ?></td>
            <td><?= so_display_number($rows[5]['pack'] ?? null) ?></td>
            <td><?= so_display_number($rows[5]['ball'] ?? null) ?></td>
          </tr>
          <tr>
            <td>6</td>
            <td>MINYAK GORENG</td>
            <td><?= so_display_number($rows[6]['pcs_gram'] ?? null) ?></td>
            <td><?= so_display_number($rows[6]['pack'] ?? null) ?></td>
            <td><?= so_display_number($rows[6]['ball'] ?? null) ?></td>
          </tr>
          <tr>
            <td>7</td>
            <td>LPG</td>
            <td><?= so_display_number($rows[7]['pcs_gram'] ?? null) ?></td>
            <td><?= so_display_number($rows[7]['pack'] ?? null) ?></td>
            <td><?= so_display_number($rows[7]['ball'] ?? null) ?></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
  <div class="panel so-process-panel">
    <div class="so-form-head">
      <div><span class="station-icon">⚙️</span>
        <div>
          <h3>Proses Produksi / Persusutan</h3>
        </div>
      </div>
      <span class="form-note">Susut = Sebelum − Sesudah</span>
    </div>
    <?php
    $maxProcessRow = $processRows ? max(array_keys($processRows)) : 1;
    $maxProcessRow = max(1, $maxProcessRow);
    $totalCabeSusut = 0.0;
    $totalAyamSusut = 0.0;
    $hasTotalCabe = false;
    $hasTotalAyam = false;
    for ($i = 1; $i <= $maxProcessRow; $i++) {
      $r = $processRows[$i] ?? [];
      if (($r['cabe_sebelum'] ?? null) !== null && ($r['cabe_sesudah'] ?? null) !== null) {
        $totalCabeSusut += (float)$r['cabe_sebelum'] - (float)$r['cabe_sesudah'];
        $hasTotalCabe = true;
      }
      if (($r['ayam_sebelum'] ?? null) !== null && ($r['ayam_sesudah'] ?? null) !== null) {
        $totalAyamSusut += (float)$r['ayam_sebelum'] - (float)$r['ayam_sesudah'];
        $hasTotalAyam = true;
      }
    }
    ?>
    <div class="table-wrap">
      <table class="so-input-table process-table data-process">
        <thead>
          <tr>
            <th>No</th>
            <th colspan="3">CABE GILING</th>
            <th colspan="3">AYAM CINCANG</th>
          </tr>
          <tr>
            <th></th>
            <th>Sebelum</th>
            <th>Sesudah</th>
            <th>Susut</th>
            <th>Sebelum</th>
            <th>Sesudah</th>
            <th>Susut</th>
          </tr>
        </thead>
        <tbody>
          <?php for ($i = 1; $i <= $maxProcessRow; $i++): $r = $processRows[$i] ?? []; ?>
            <tr>
              <td data-label="No"><?= e($i) ?></td>
              <td data-label="Cabe Sebelum"><?= so_display_number($r['cabe_sebelum'] ?? null) ?></td>
              <td data-label="Cabe Sesudah"><?= so_display_number($r['cabe_sesudah'] ?? null) ?></td>
              <td data-label="Cabe Susut"><?= so_display_number(($r['cabe_sebelum'] ?? null) !== null && ($r['cabe_sesudah'] ?? null) !== null ? ((float)$r['cabe_sebelum'] - (float)$r['cabe_sesudah']) : null) ?></td>
              <td data-label="Ayam Sebelum"><?= so_display_number($r['ayam_sebelum'] ?? null) ?></td>
              <td data-label="Ayam Sesudah"><?= so_display_number($r['ayam_sesudah'] ?? null) ?></td>
              <td data-label="Ayam Susut"><?= so_display_number(($r['ayam_sebelum'] ?? null) !== null && ($r['ayam_sesudah'] ?? null) !== null ? ((float)$r['ayam_sebelum'] - (float)$r['ayam_sesudah']) : null) ?></td>
            </tr>
          <?php endfor; ?>
        </tbody>
        <tfoot>
          <tr>
            <th colspan="3">TOTAL SUSUT CABE GILING</th>
            <th><?= $hasTotalCabe ? so_display_number($totalCabeSusut) : '-' ?></th>
            <th colspan="2">TOTAL SUSUT AYAM CINCANG</th>
            <th><?= $hasTotalAyam ? so_display_number($totalAyamSusut) : '-' ?></th>
          </tr>
        </tfoot>
      </table>
    </div>
  </div>
<?php endif; ?>
<?php require __DIR__ . '/../../includes/footer.php'; ?>