<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/so_kitchen.php';
require_once __DIR__ . '/../../config/helpers.php';

$stationKey = 'produksi';
$station = so_kitchen_station($stationKey);
if (!$station) { http_response_code(404); exit('Station tidak ditemukan.'); }
$pageTitle = 'Input SO ' . $station['name'];
$tanggal = so_harian_date($_GET['tanggal'] ?? $_POST['tanggal'] ?? null);
$success = '';
$error = '';

function num_or_null($value): ?float {
    if ($value === null || $value === '') return null;
    $value = str_replace(',', '.', trim((string)$value));
    return is_numeric($value) ? (float)$value : null;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal = so_harian_date($_POST['tanggal'] ?? null);
    if (!db_ready()) {
        $error = 'Database belum terhubung. Import database/adminsmptru.sql lalu periksa config/database.php.';
    } else {
        $pcs = $_POST['pcs_gram'] ?? [];
        $pack = $_POST['pack'] ?? [];
        $ball = $_POST['ball'] ?? [];
        $biang = $_POST['biang'] ?? [];
        $conn->begin_transaction();
        try {
            $del = $conn->prepare('DELETE FROM so_kitchen_stock WHERE tanggal = ? AND station = ?');
            $del->bind_param('ss', $tanggal, $stationKey);
            $del->execute();
            $del->close();

            $ins = $conn->prepare('INSERT INTO so_kitchen_stock (tanggal, station, row_no, nama_barang, pcs_gram, pack, ball, biang) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
            foreach ($station['items'] as $i => $itemName) {
                $rowNo = $i + 1;
                $vPcs = num_or_null($pcs[$rowNo] ?? null);
                $vPack = num_or_null($pack[$rowNo] ?? null);
                $vBall = in_array('ball', $station['columns'], true) ? num_or_null($ball[$rowNo] ?? null) : null;
                $vBiang = in_array('biang', $station['columns'], true) ? num_or_null($biang[$rowNo] ?? null) : null;
                $ins->bind_param('ssisdddd', $tanggal, $stationKey, $rowNo, $itemName, $vPcs, $vPack, $vBall, $vBiang);
                $ins->execute();
            }
            $ins->close();

            if (!empty($station['has_process'])) {
                $delP = $conn->prepare('DELETE FROM so_kitchen_process WHERE tanggal = ?');
                $delP->bind_param('s', $tanggal);
                $delP->execute();
                $delP->close();

                $cBefore = $_POST['cabe_sebelum'] ?? [];
                $cAfter = $_POST['cabe_sesudah'] ?? [];
                $aBefore = $_POST['ayam_sebelum'] ?? [];
                $aAfter = $_POST['ayam_sesudah'] ?? [];
                $rowKeys = array_unique(array_merge(
                    array_keys($cBefore), array_keys($cAfter),
                    array_keys($aBefore), array_keys($aAfter)
                ));
                $rowKeys = array_values(array_filter(array_map('intval', $rowKeys), static fn($n) => $n > 0));
                sort($rowKeys);

                $insP = $conn->prepare('INSERT INTO so_kitchen_process (tanggal, row_no, cabe_sebelum, cabe_sesudah, ayam_sebelum, ayam_sesudah) VALUES (?, ?, ?, ?, ?, ?)');
                foreach ($rowKeys as $i) {
                    $cv1 = num_or_null($cBefore[$i] ?? null);
                    $cv2 = num_or_null($cAfter[$i] ?? null);
                    $av1 = num_or_null($aBefore[$i] ?? null);
                    $av2 = num_or_null($aAfter[$i] ?? null);
                    $insP->bind_param('sidddd', $tanggal, $i, $cv1, $cv2, $av1, $av2);
                    $insP->execute();
                }
                $insP->close();
            }

            $conn->commit();
            header('Location: dataproduksi.php?tanggal=' . urlencode($tanggal) . '&saved=1');
            exit;
        } catch (Throwable $ex) {
            $conn->rollback();
            $error = 'Data gagal disimpan: ' . $ex->getMessage();
        }
    }
}

$existing = [];
$processExisting = [];
if (db_ready()) {
    $stmt = $conn->prepare('SELECT row_no, pcs_gram, pack, ball, biang FROM so_kitchen_stock WHERE tanggal = ? AND station = ? ORDER BY row_no');
    $stmt->bind_param('ss', $tanggal, $stationKey);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($row = $res->fetch_assoc()) { $existing[(int)$row['row_no']] = $row; }
    $stmt->close();

    if (!empty($station['has_process'])) {
        $ps = $conn->prepare('SELECT row_no, cabe_sebelum, cabe_sesudah, ayam_sebelum, ayam_sesudah FROM so_kitchen_process WHERE tanggal = ? ORDER BY row_no');
        $ps->bind_param('s', $tanggal);
        $ps->execute();
        $pr = $ps->get_result();
        while ($row = $pr->fetch_assoc()) { $processExisting[(int)$row['row_no']] = $row; }
        $ps->close();
    }
}

require __DIR__ . '/../../includes/header.php';
?>
<div class="page-head">
  <div>
    <small>Dashboard › SO Kitchen › <?=e($station['name'])?> › Input</small>
    <h2>Input SO <?=e($station['name'])?></h2>
  </div>
  <div class="page-actions">
    <a class="btn-action back" href="dataproduksi.php?tanggal=<?=e($tanggal)?>">← Kembali</a>
  </div>
</div>
<?php if ($error): ?><?=flash_message('error', $error)?><?php endif; ?>
<?php if ($success): ?><?=flash_message('success', $success)?><?php endif; ?>

<form method="post" class="so-entry-form">
  <div class="panel so-form-panel">
    <div class="so-form-head">
      <div class="station-title-wrap">
        <div class="station-title-main">
          <span class="station-icon">🏭</span>
          <div><h3><?=e($station['name'])?></h3><p><?=e($station['description'])?></p></div>
        </div>
      </div>
      <div class="so-inline-date">
        <label for="tanggal">Tanggal</label>
        <input type="date" name="tanggal" id="tanggal" value="<?=e($tanggal)?>" required>
      </div>
    </div>
    <div class="table-wrap">
      <table class="so-input-table">
        <thead><tr><th>No</th><th>Nama Barang</th><th>Pcs/Gram</th><th>Pack</th><th>Ball</th></tr></thead>
        <tbody>
        <tr><td>1</td><td>ADONAN PANGSIT</td><td><input type="number" step="0.01" min="0" name="pcs_gram[1]" value="<?=so_input_value($existing[1]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[1]" value="<?=so_input_value($existing[1]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="ball[1]" value="<?=so_input_value($existing[1] ['ball'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>2</td><td>CABE UTUH</td><td><input type="number" step="0.01" min="0" name="pcs_gram[2]" value="<?=so_input_value($existing[2]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[2]" value="<?=so_input_value($existing[2]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="ball[2]" value="<?=so_input_value($existing[2] ['ball'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>3</td><td>AYAM CINCANG</td><td><input type="number" step="0.01" min="0" name="pcs_gram[3]" value="<?=so_input_value($existing[3]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[3]" value="<?=so_input_value($existing[3]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="ball[3]" value="<?=so_input_value($existing[3] ['ball'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>4</td><td>KULIT PANGSIT</td><td><input type="number" step="0.01" min="0" name="pcs_gram[4]" value="<?=so_input_value($existing[4]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[4]" value="<?=so_input_value($existing[4]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="ball[4]" value="<?=so_input_value($existing[4] ['ball'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>5</td><td>KERUPUK MIE MENTAH</td><td><input type="number" step="0.01" min="0" name="pcs_gram[5]" value="<?=so_input_value($existing[5]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[5]" value="<?=so_input_value($existing[5]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="ball[5]" value="<?=so_input_value($existing[5] ['ball'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>6</td><td>MINYAK GORENG</td><td><input type="number" step="0.01" min="0" name="pcs_gram[6]" value="<?=so_input_value($existing[6]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[6]" value="<?=so_input_value($existing[6]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="ball[6]" value="<?=so_input_value($existing[6] ['ball'] ?? '')?>" inputmode="decimal"></td></tr>
<tr><td>7</td><td>LPG</td><td><input type="number" step="0.01" min="0" name="pcs_gram[7]" value="<?=so_input_value($existing[7]['pcs_gram'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="pack[7]" value="<?=so_input_value($existing[7]['pack'] ?? '')?>" inputmode="decimal"></td><td><input type="number" step="0.01" min="0" name="ball[7]" value="<?=so_input_value($existing[7] ['ball'] ?? '')?>" inputmode="decimal"></td></tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="panel so-process-panel">
    <div class="so-form-head">
      <div><span class="station-icon">⚙️</span><div><h3>Proses Produksi / Persusutan</h3></div></div>
      <span class="form-note">Susut = Sebelum − Sesudah</span>
    </div>

    <?php
      $maxExistingProcessRow = $processExisting ? max(array_keys($processExisting)) : 1;
      $processRowCount = max(1, $maxExistingProcessRow);
    ?>
    <div class="table-wrap">
      <table class="so-input-table process-table" id="processTable">
        <thead>
          <tr>
            <th>No</th>
            <th colspan="3">CABE GILING</th>
            <th colspan="3">AYAM CINCANG</th>
          </tr>
          <tr>
            <th></th>
            <th>Sebelum</th><th>Sesudah</th><th>Susut</th>
            <th>Sebelum</th><th>Sesudah</th><th>Susut</th>
          </tr>
        </thead>
        <tbody id="processBody">
        <?php for ($i = 1; $i <= $processRowCount; $i++):
          $r = $processExisting[$i] ?? [];
        ?>
          <tr data-process-row="<?=e($i)?>">
            <td><?=e($i)?></td>
            <td><input type="number" step="0.01" min="0" name="cabe_sebelum[<?=e($i)?>]" value="<?=so_input_value($r['cabe_sebelum'] ?? '')?>" inputmode="decimal" class="process-input cabe-sebelum"></td>
            <td><input type="number" step="0.01" min="0" name="cabe_sesudah[<?=e($i)?>]" value="<?=so_input_value($r['cabe_sesudah'] ?? '')?>" inputmode="decimal" class="process-input cabe-sesudah"></td>
            <td><input type="text" class="process-susut cabe-susut" value="" readonly tabindex="-1"></td>
            <td><input type="number" step="0.01" min="0" name="ayam_sebelum[<?=e($i)?>]" value="<?=so_input_value($r['ayam_sebelum'] ?? '')?>" inputmode="decimal" class="process-input ayam-sebelum"></td>
            <td><input type="number" step="0.01" min="0" name="ayam_sesudah[<?=e($i)?>]" value="<?=so_input_value($r['ayam_sesudah'] ?? '')?>" inputmode="decimal" class="process-input ayam-sesudah"></td>
            <td><input type="text" class="process-susut ayam-susut" value="" readonly tabindex="-1"></td>
          </tr>
        <?php endfor; ?>
        </tbody>
        <tfoot>
          <tr>
            <th colspan="3">TOTAL SUSUT CABE GILING</th>
            <th><input type="text" id="totalCabeSusut" class="process-total" value="" readonly tabindex="-1"></th>
            <th colspan="2">TOTAL SUSUT AYAM CINCANG</th>
            <th><input type="text" id="totalAyamSusut" class="process-total" value="" readonly tabindex="-1"></th>
          </tr>
        </tfoot>
      </table>
    </div>

    <div class="process-add-wrap">
      <button type="button" class="btn-action secondary" id="addProcessRow">＋ Tambah Baris</button>
    </div>
  </div>

  <div class="form-submit-bar">
    <a class="btn-action back" href="dataproduksi.php?tanggal=<?=e($tanggal)?>">Batal</a>
    <button type="submit" class="btn-action primary">💾 Simpan Data</button>
  </div>
</form>
<script>
(function(){
  const body = document.getElementById('processBody');
  const addButton = document.getElementById('addProcessRow');
  const totalCabe = document.getElementById('totalCabeSusut');
  const totalAyam = document.getElementById('totalAyamSusut');
  if (!body || !addButton) return;

  function num(v){
    if (v === '' || v == null) return null;
    const n = parseFloat(String(v).replace(',', '.'));
    return Number.isFinite(n) ? n : null;
  }

  function fmt(v){
    if (v == null || !Number.isFinite(v)) return '';
    return Number.isInteger(v) ? String(v) : v.toFixed(2).replace(/0+$/,'').replace(/\.$/,'');
  }

  function updateTotals(){
    let totalC = 0, totalA = 0;
    let hasC = false, hasA = false;
    body.querySelectorAll('tr[data-process-row]').forEach(row => {
      const cs = num(row.querySelector('.cabe-sebelum')?.value);
      const ca = num(row.querySelector('.cabe-sesudah')?.value);
      const as = num(row.querySelector('.ayam-sebelum')?.value);
      const aa = num(row.querySelector('.ayam-sesudah')?.value);

      const cSusut = (cs != null && ca != null) ? cs - ca : null;
      const aSusut = (as != null && aa != null) ? as - aa : null;

      const cOut = row.querySelector('.cabe-susut');
      const aOut = row.querySelector('.ayam-susut');
      if (cOut) cOut.value = fmt(cSusut);
      if (aOut) aOut.value = fmt(aSusut);

      if (cSusut != null){ totalC += cSusut; hasC = true; }
      if (aSusut != null){ totalA += aSusut; hasA = true; }
    });
    if (totalCabe) totalCabe.value = hasC ? fmt(totalC) : '';
    if (totalAyam) totalAyam.value = hasA ? fmt(totalA) : '';
  }

  function nextRowNo(){
    let max = 0;
    body.querySelectorAll('tr[data-process-row]').forEach(row => {
      max = Math.max(max, parseInt(row.dataset.processRow || '0', 10));
    });
    return max + 1;
  }

  function addRow(){
    const i = nextRowNo();
    const tr = document.createElement('tr');
    tr.dataset.processRow = i;
    tr.innerHTML = `
      <td>${i}</td>
      <td><input type="number" step="0.01" min="0" name="cabe_sebelum[${i}]" inputmode="decimal" class="process-input cabe-sebelum"></td>
      <td><input type="number" step="0.01" min="0" name="cabe_sesudah[${i}]" inputmode="decimal" class="process-input cabe-sesudah"></td>
      <td><input type="text" class="process-susut cabe-susut" readonly tabindex="-1"></td>
      <td><input type="number" step="0.01" min="0" name="ayam_sebelum[${i}]" inputmode="decimal" class="process-input ayam-sebelum"></td>
      <td><input type="number" step="0.01" min="0" name="ayam_sesudah[${i}]" inputmode="decimal" class="process-input ayam-sesudah"></td>
      <td><input type="text" class="process-susut ayam-susut" readonly tabindex="-1"></td>`;
    body.appendChild(tr);
    attachRow(tr);
    tr.scrollIntoView({behavior:'smooth', block:'nearest'});
  }

  function attachRow(row){
    row.querySelectorAll('.process-input').forEach(input => input.addEventListener('input', updateTotals));
  }

  body.querySelectorAll('tr[data-process-row]').forEach(attachRow);
  updateTotals();
  addButton.addEventListener('click', addRow);
})();
</script>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
