<?php
require_once __DIR__ . '/config/config.php';
require_once __DIR__ . '/config/database.php';
require_once __DIR__ . '/config/helpers.php';

$pageTitle = 'SO Harian';
$tanggal = $_GET['tanggal'] ?? date('Y-m-d');
if (!preg_match('/^\\d{4}-\\d{2}-\\d{2}$/', $tanggal)) {
    $tanggal = date('Y-m-d');
}

$masterRows = [];
$soGudang = [];
$soKitchen = [];
$sourceErrors = [];

/**
 * Normalisasi nama barang untuk pencocokan antar sumber.
 */
function normalize_item_name(string $value): string
{
    $value = trim(mb_strtoupper($value, 'UTF-8'));
    $value = preg_replace('/\\s+/', ' ', $value);
    return $value;
}

/**
 * Apakah tabel tersedia di database.
 */
function table_exists(mysqli $conn, string $table): bool
{
    $table = $conn->real_escape_string($table);
    $result = $conn->query("SHOW TABLES LIKE '{$table}'");
    return $result && $result->num_rows > 0;
}

/**
 * Unit pada master SO Harian yang dapat mengambil nilai dari SO Kitchen.
 * Pcs/Gram -> kolom pcs_gram, Pack -> pack, Ball -> ball, Biang -> biang.
 */
function kitchen_source_field(string $unit): ?string
{
    $unit = strtolower(trim($unit));
    if ($unit === 'pack') return 'pack';
    if ($unit === 'ball') return 'ball';
    if ($unit === 'biang') return 'biang';
    if (in_array($unit, ['pcs', 'gr', 'kg', 'ml'], true)) return 'pcs_gram';
    return null;
}

/**
 * Ambil nilai sumber SO Gudang berdasarkan nama barang + jenis kolom.
 * KRT/BALL dipakai untuk satuan gudang seperti karton/ball/karung/tabung,
 * sedangkan PACK/SLOP dipakai untuk satuan pack/slop.
 */
function get_gudang_value(array $map, string $name, string $unit): ?float
{
    $unit = strtolower(trim($unit));
    $column = null;
    if (in_array($unit, ['karton','krt','ball','karung','tabung','krb'], true)) {
        $column = 'krt_ball';
    } elseif (in_array($unit, ['pack','slop'], true)) {
        $column = 'pack_slop';
    }
    if ($column === null) return null;

    $key = normalize_item_name($name);
    if (!isset($map[$key]) || !array_key_exists($column, $map[$key])) return null;
    return $map[$key][$column] === null ? null : (float)$map[$key][$column];
}

/**
 * Ambil nilai agregat SO Kitchen berdasarkan nama + field.
 */
function kitchen_source_key(string $name): string
{
    $key = normalize_item_name($name);
    // Baris master SO Harian ini bersumber dari item SO Kitchen PANGSIT GORENG.
    $aliases = [
        'SISA PANGSIT GORENG JATIM' => 'PANGSIT GORENG',
    ];
    return $aliases[$key] ?? $key;
}

function get_kitchen_value(array $map, string $name, string $field): ?float
{
    $key = kitchen_source_key($name);
    if (!isset($map[$key]) || !array_key_exists($field, $map[$key])) return null;
    return $map[$key][$field] === null ? null : (float)$map[$key][$field];
}

if (db_ready()) {
    // Master SO Harian yang menjadi daftar baris tampilan.
    $res = $conn->query("SELECT id, row_no, nama_barang, satuan, source_value, kind, source_formula FROM so_harian_master ORDER BY row_no ASC");
    if ($res) {
        while ($r = $res->fetch_assoc()) $masterRows[] = $r;
    }

    // Sumber 1: SO Gudang.
    // Struktur tabel: so_gudang_stock(item_id, krt_ball, pack_slop) + master so_gudang_items(nama_barang).
    if (table_exists($conn, 'so_gudang_stock') && table_exists($conn, 'so_gudang_items')) {
        $sqlGudang = "SELECT i.nama_barang, SUM(s.krt_ball) AS krt_ball, SUM(s.pack_slop) AS pack_slop
                      FROM so_gudang_stock s
                      INNER JOIN so_gudang_items i ON i.id = s.item_id
                      WHERE s.tanggal = ?
                      GROUP BY i.id, i.nama_barang";
        $stmt = $conn->prepare($sqlGudang);
        if ($stmt) {
            $stmt->bind_param('s', $tanggal);
            $stmt->execute();
            $res = $stmt->get_result();
            while ($r = $res->fetch_assoc()) {
                $key = normalize_item_name((string)$r['nama_barang']);
                $soGudang[$key] = [
                    'krt_ball' => $r['krt_ball'] === null ? null : (float)$r['krt_ball'],
                    'pack_slop' => $r['pack_slop'] === null ? null : (float)$r['pack_slop'],
                ];
            }
            $stmt->close();
        } else {
            $sourceErrors[] = 'Tabel SO Gudang tersedia tetapi query tidak dapat disiapkan: ' . $conn->error;
        }
    } else {
        $sourceErrors[] = 'Tabel sumber SO Gudang belum tersedia.';
    }

    // Sumber 2: SO Kitchen. Data diambil dari semua station pada tanggal tersebut.
    if (table_exists($conn, 'so_kitchen_stock')) {
        $stmt = $conn->prepare("SELECT nama_barang, SUM(pcs_gram) AS pcs_gram, SUM(pack) AS pack, SUM(ball) AS ball, SUM(biang) AS biang FROM so_kitchen_stock WHERE tanggal = ? GROUP BY nama_barang");
        if ($stmt) {
            $stmt->bind_param('s', $tanggal);
            $stmt->execute();
            $res = $stmt->get_result();
            while ($r = $res->fetch_assoc()) {
                $key = normalize_item_name($r['nama_barang']);
                $soKitchen[$key] = [
                    'pcs_gram' => $r['pcs_gram'] === null ? null : (float)$r['pcs_gram'],
                    'pack' => $r['pack'] === null ? null : (float)$r['pack'],
                    'ball' => $r['ball'] === null ? null : (float)$r['ball'],
                    'biang' => $r['biang'] === null ? null : (float)$r['biang'],
                ];
            }
            $stmt->close();
        } else {
            $sourceErrors[] = 'Tabel SO Kitchen tersedia tetapi query tidak dapat disiapkan.';
        }
    } else {
        $sourceErrors[] = 'Tabel sumber SO Kitchen belum tersedia.';
    }
}

$rowsView = [];
foreach ($masterRows as $row) {
    $isTotal = $row['kind'] === 'total';
    $gudang = null;
    $kitchen = null;
    $total = null;

    if (!$isTotal) {
        $gudang = get_gudang_value($soGudang, (string)$row['nama_barang'], (string)$row['satuan']);
        $field = kitchen_source_field((string)$row['satuan']);
        if ($field !== null) {
            $kitchen = get_kitchen_value($soKitchen, (string)$row['nama_barang'], $field);
        }
        if ($gudang !== null || $kitchen !== null) {
            $total = (float)($gudang ?? 0) + (float)($kitchen ?? 0);
        }
    }

    $rowsView[] = [
        'id' => (int)$row['id'],
        'row_no' => (int)$row['row_no'],
        'nama_barang' => (string)$row['nama_barang'],
        'satuan' => (string)$row['satuan'],
        'kind' => $row['kind'],
        'source_formula' => (string)($row['source_formula'] ?? ''),
        'so_gudang' => $gudang,
        'so_kitchen' => $kitchen,
        'total' => $total,
    ];
}

function format_source_value(?float $value): string
{
    if ($value === null) return '—';
    if ((int)$value == $value) return number_format((float)$value, 0, ',', '.');
    return rtrim(rtrim(number_format((float)$value, 2, ',', '.'), '0'), ',');
}

require __DIR__ . '/includes/header.php';
?>
<div class="page-head">
  <div>
    <h2>SO Harian</h2>
  </div>
  <div class="page-actions">
    <a class="btn-action back" href="index.php">← Kembali</a>
    <button class="btn-action primary" type="button" id="exportSoBtn">⬇ Ekspor</button>
  </div>
</div>

<?php if ($sourceErrors): ?>
  <div class="panel source-info-panel">
    <div class="source-info-grid">
      <div class="source-card <?=!in_array('Tabel sumber SO Gudang belum tersedia.', $sourceErrors, true) ? 'ready' : 'warning'?>">
        <span class="source-icon">📦</span>
        <div><strong>SO Gudang</strong><small><?=!in_array('Tabel sumber SO Gudang belum tersedia.', $sourceErrors, true) ? 'Data sumber terhubung' : 'Menunggu tabel sumber'?></small></div>
      </div>
      <div class="source-card <?=!in_array('Tabel sumber SO Kitchen belum tersedia.', $sourceErrors, true) ? 'ready' : 'warning'?>">
        <span class="source-icon">🍳</span>
        <div><strong>SO Kitchen</strong><small><?=!in_array('Tabel sumber SO Kitchen belum tersedia.', $sourceErrors, true) ? 'Data sumber terhubung' : 'Menunggu tabel sumber'?></small></div>
      </div>
    </div>
  </div>
<?php endif; ?>

<?php if (!$masterRows): ?>
  <section class="panel empty-state">
    <div class="empty-icon">📋</div>
    <h3>Master SO belum tersedia</h3>
    <p>Import <code>database/adminsmptru.sql</code> terlebih dahulu agar seluruh daftar barang muncul.</p>
  </section>
<?php else: ?>
<section class="panel so-full-table-panel">
  <div class="so-form-head">
    <div class="so-title-wrap">
      <div class="station-icon">📋</div>
      <div>
        <h3>Data SO Harian Lengkap</h3>
        <p><?=count(array_filter($masterRows, fn($r)=>$r['kind']==='item'))?> baris sumber • <?=count(array_filter($masterRows, fn($r)=>$r['kind']==='total'))?> baris total</p>
      </div>
    </div>
    <form class="so-date-inline-form" method="get">
      <input type="date" id="tanggalSO" name="tanggal" value="<?=e($tanggal)?>" onchange="this.form.submit()">
    </form>
  </div>

  <div class="so-toolbar">
    <label class="so-search-box">⌕ <input id="soSearch" type="search" placeholder="Cari nama barang atau satuan..."></label>
    <span id="soResultCount" class="so-result-count"></span>
  </div>

  <div class="table-wrap so-full-table-wrap">
    <table class="so-full-table so-readonly-table" id="soFullTable">
      <thead>
        <tr>
          <th>No</th>
          <th>Nama Barang</th>
          <th>Satuan</th>
          <th>Total</th>
          <th>SO Gudang</th>
          <th>SO Kitchen</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($rowsView as $row):
          $isTotal = $row['kind'] === 'total';
          $searchText = strtolower($row['nama_barang'].' '.$row['satuan']);
      ?>
        <?php if ($isTotal): ?>
          <tr class="so-total-row" data-search="<?=e($searchText)?>">
            <td><?=e($row['row_no'])?></td>
            <td><div class="item-name"><?=e($row['nama_barang'])?></div></td>
            <td><span class="unit-chip"><?=e($row['satuan'])?></span></td>
            <td><span class="total-chip">TOTAL</span></td>
            <td><span class="readonly-value muted">—</span></td>
            <td><span class="readonly-value muted">—</span></td>
          </tr>
        <?php else: ?>
          <tr data-search="<?=e($searchText)?>">
            <td><?=e($row['row_no'])?></td>
            <td>
              <div class="item-name"><?=e($row['nama_barang'])?></div>
              <?php if ($row['source_formula']): ?><small class="source-ref">Ref. sumber: <?=e($row['source_formula'])?></small><?php endif; ?>
            </td>
            <td><span class="unit-chip"><?=e($row['satuan'])?></span></td>
            <td><span class="readonly-value total-value"><?=e(format_source_value($row['total']))?></span></td>
            <td><span class="readonly-value gudang-value"><?=e(format_source_value($row['so_gudang']))?></span></td>
            <td><span class="readonly-value kitchen-value"><?=e(format_source_value($row['so_kitchen']))?></span></td>
          </tr>
        <?php endif; ?>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>

<div class="form-submit-bar">
  <a class="btn-action back" href="index.php">← Kembali</a>
  <button class="btn-action primary" type="button" id="exportSoBottom">⬇ Ekspor</button>
</div>
<?php endif; ?>

<script>
(function(){
  const input=document.getElementById('soSearch');
  const table=document.getElementById('soFullTable');
  const count=document.getElementById('soResultCount');
  if(!input || !table) return;
  const rows=[...table.querySelectorAll('tbody tr')];

  function render(){
    const q=input.value.trim().toLowerCase(); let visible=0;
    rows.forEach(row=>{
      const hit=!q || (row.dataset.search||'').includes(q);
      row.style.display=hit?'':'none';
      if(hit) visible++;
    });
    if(count) count.textContent=visible+' baris tampil';
  }
  input.addEventListener('input',render); render();

  function excelCell(value){
    return String(value ?? '')
      .replace(/&/g,'&amp;')
      .replace(/</g,'&lt;')
      .replace(/>/g,'&gt;')
      .replace(/"/g,'&quot;');
  }

  function exportSoHarian(){
    const rowsHtml=[];
    rows.forEach(row=>{
      if(row.style.display==='none') return;
      const cells=row.querySelectorAll('td');
      if(cells.length < 6) return;
      const isTotal=row.classList.contains('so-total-row');
      const values=[...cells].map(c=>(c.innerText||'').trim());
      rowsHtml.push(`
        <tr class="${isTotal ? 'total-row' : ''}">
          <td class="no">${excelCell(values[0])}</td>
          <td>${excelCell(values[1])}</td>
          <td>${excelCell(values[2])}</td>
          <td class="num">${excelCell(values[3])}</td>
          <td class="num">${excelCell(values[4])}</td>
          <td class="num">${excelCell(values[5])}</td>
        </tr>`);
    });

    const tanggalLabel = <?=json_encode(date('d/m/Y', strtotime($tanggal)))?>;
    const html=`<!DOCTYPE html>
<html><head><meta charset="UTF-8"><style>
body{font-family:Arial,sans-serif;font-size:10pt;color:#111;background:#fff}
table{border-collapse:collapse}.main{width:100%}.main th{background:#d9eaf7;font-weight:700;text-align:center;border:1px solid #000;padding:6px}.main td{border:1px solid #000;padding:4px;vertical-align:middle}.main td.no{text-align:center;width:55px}.main td.num{text-align:center;width:90px}.total-row td{background:#d9eaf7;font-weight:700}.meta td{border:none;padding:4px 8px}.meta .label{font-weight:700}.meta a{color:#0563c1;text-decoration:underline}
</style></head><body>
<table class="meta"><tr><td class="label">tgl:</td><td>${excelCell(tanggalLabel)}</td></tr>
<tr><td class="label">SO GUDANG</td><td><a href="https://docs.google.com/spreadsheets/d/1SF-gblWgIpXHbecDSjG-F6U0davMUYFHx-WYz-aKPMs/edit?gid=768607024#gid=768607024">https://docs.google.com/spreadsheets/d/1SF-gblWgIpXHbecDSjG-F6U0davMUYFHx-WYz-aKPMs/edit?gid=768607024#gid=768607024</a></td></tr>
<tr><td class="label">SO KITCHEN</td><td><a href="https://docs.google.com/spreadsheets/d/1DWQTnA9ayyscuqfg3EjaPUiLIsYEuqKKwUN3GUh4P0U/edit?gid=536718134#gid=536718134">https://docs.google.com/spreadsheets/d/1DWQTnA9ayyscuqfg3EjaPUiLIsYEuqKKwUN3GUh4P0U/edit?gid=536718134#gid=536718134</a></td></tr></table><br>
<table class="main"><thead><tr><th>No</th><th>nama_barang</th><th>satuan</th><th>total</th><th>so_gudang</th><th>so_kitchen</th></tr></thead><tbody>${rowsHtml.join('')}</tbody></table>
</body></html>`;

    const blob=new Blob([html],{type:'application/vnd.ms-excel;charset=utf-8;'});
    const url=URL.createObjectURL(blob);
    const a=document.createElement('a');
    a.href=url;
    a.download='SO_Harian_<?=$tanggal?>.xls';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  const exportBtn=document.getElementById('exportSoBtn');
  const exportBottom=document.getElementById('exportSoBottom');
  if(exportBtn) exportBtn.addEventListener('click',exportSoHarian);
  if(exportBottom) exportBottom.addEventListener('click',exportSoHarian);
})();
</script>

<?php require __DIR__ . '/includes/footer.php'; ?>
