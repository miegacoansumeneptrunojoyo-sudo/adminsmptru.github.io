<?php $pageTitle='SO Kitchen'; require __DIR__.'/includes/header.php'; ?>
<div class="page-head">
  <div>
    <h2>SO Kitchen</h2>
  </div><div class="page-actions"><a class="btn-action back" href="index.php">← Kembali</a></div>
</div>
<section class="cards grid4">
<?php
$items=[
  ['🧾','Kasir','Stock dan kebutuhan kasir','so_kitchen/kasir/datakasir.php'],
  ['🍜','Noodle','Stock dan kebutuhan noodle','so_kitchen/noodle/datanoodle.php'],
  ['🧑‍🍳','Presenter','Stock dan kebutuhan presenter','so_kitchen/presenter/datapresenter.php'],
  ['🥟','Dimsum','Stock dan kebutuhan dimsum','so_kitchen/dimsum/datadimsum.php'],
  ['🥤','Bar','Stock dan kebutuhan bar','so_kitchen/bar/databar.php'],
  ['🏭','Produksi','Stock dan proses produksi','so_kitchen/produksi/dataproduksi.php']
];
foreach($items as $it): ?>
<a class="tile" href="<?=$it[3]?>">
  <span class="tile-icon"><?=$it[0]?></span>
  <h3><?=$it[1]?></h3>
  <p><?=$it[2]?></p>
  <span class="mini-arrow">›</span>
</a>
<?php endforeach; ?>
</section>
<?php require __DIR__.'/includes/footer.php'; ?>
