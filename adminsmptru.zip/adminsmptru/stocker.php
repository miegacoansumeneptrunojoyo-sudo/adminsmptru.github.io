<?php
require_once __DIR__ . '/config.php';
$pageTitle='Stocker';
require __DIR__.'/includes/header.php';
?>
<div class="page-head">
  <div>
    <h2>Stocker</h2>
  </div>
  <div class="page-actions"><a class="btn-action back" href="index.php">← Kembali</a></div>
</div>
<section class="cards grid4 stocker-menu-grid">
<?php
$items=[
  ['📋','Stocker Checklist','Pengecekan rutin stocker','stocker/stocker_checklist/datastockerchecklist.php'],
  ['🏢','Storage Inspection','Pemeriksaan kondisi dan penyimpanan','stocker/storage_inspection/datastorageinspection.php'],
  ['🚚','Incoming Inspection Eksternal','Penerimaan barang dari sumber eksternal','stocker/incoming_inspection/dataexternal.php'],
  ['🔎','Incoming Inspection Internal','Penerimaan / pemeriksaan barang internal','stocker/incoming_inspection/datainternal.php'],
  ['🛒','Rekap Belanja Gudang','Rekap pengeluaran gudang','stocker/rekap_belanja_gudang/datarekapbelanjagudang.php'],
  ['⚠️','Critical Produk','Monitoring produk kritis','stocker/critical_produk/datacriticalproduk.php'],
  ['❄️','Frozen','Monitoring stok frozen','stocker/frozen/datafrozen.php'],
  ['📦','SO Gudang','Input & rekap stock opname gudang','stocker/sogudang.php']
];
foreach($items as $it): ?>
<a class="tile" href="<?=$it[3]?>">
  <span class="tile-icon"><?=$it[0]?></span>
  <h3><?=$it[1]?></h3>
  <p><?=$it[2]?></p>
  <span class="mini-arrow">›</span>
</a>
<?php endforeach; ?>
</section>
<?php require __DIR__.'/includes/footer.php'; ?>
