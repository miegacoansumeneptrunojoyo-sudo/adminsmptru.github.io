<?php
require_once __DIR__.'/../../config/config.php';
require_once __DIR__.'/../../config/database.php';
require_once __DIR__.'/../../config/helpers.php';

function critical_data_ensure_tables(): bool
{
    global $conn;
    if (!db_ready()) return false;
    $a=$conn->query("CREATE TABLE IF NOT EXISTS `critical_produk_inspection` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `tanggal` DATE NOT NULL, `nama_sm` VARCHAR(180) NOT NULL,
      `grooming_supplier` VARCHAR(10) NOT NULL, `peralatan_kerja` VARCHAR(10) NOT NULL, `kebersihan_area_unloading` VARCHAR(10) NOT NULL,
      `pemeriksaan_sampling` VARCHAR(10) NOT NULL, `procedure_penghitungan_product` VARCHAR(10) NOT NULL, `waktu_pemindahan_frozen` VARCHAR(10) NOT NULL,
      `suhu_truk` VARCHAR(80) DEFAULT NULL, `nama_stocker` VARCHAR(120) NOT NULL, `nama_manager` VARCHAR(180) NOT NULL,
      `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), KEY `idx_critical_inspection_date` (`tanggal`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $b=$conn->query("CREATE TABLE IF NOT EXISTS `critical_produk_inspection_samples` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `inspection_id` BIGINT UNSIGNED NOT NULL, `nama_produk` VARCHAR(120) NOT NULL,
      `nama_supp` VARCHAR(180) DEFAULT NULL, `kode_lot` VARCHAR(120) DEFAULT NULL, `nama_produsen` VARCHAR(180) DEFAULT NULL,
      `alamat` TEXT DEFAULT NULL, `negara` VARCHAR(80) NOT NULL DEFAULT 'Indonesia', `jumlah_satuan_barang` VARCHAR(180) DEFAULT NULL,
      `kode_halal` VARCHAR(10) DEFAULT NULL, `production_date` DATE DEFAULT NULL, `jumlah_sampel` VARCHAR(80) DEFAULT NULL,
      `temperatur_product` VARCHAR(10) DEFAULT NULL, `diameter_mie` VARCHAR(10) DEFAULT NULL, `ketebalan_kulit_pangsit` VARCHAR(10) DEFAULT NULL,
      `lebar_kulit_kerupuk` VARCHAR(10) DEFAULT NULL, `kondisi_cabe_buah` VARCHAR(10) DEFAULT NULL, `kondisi_truck` VARCHAR(10) NOT NULL,
      `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), KEY `idx_critical_sample_inspection` (`inspection_id`),
      CONSTRAINT `fk_critical_sample_inspection` FOREIGN KEY (`inspection_id`) REFERENCES `critical_produk_inspection` (`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    return $a && $b;
}

$date = (string)($_GET['date'] ?? date('Y-m-d'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date)) $date=date('Y-m-d');
$rows=[]; $samples=[]; $error='';
if(!critical_data_ensure_tables()) $error='Database belum siap: '.db_error_message();
if(!$error && db_ready()){
  $st=$conn->prepare("SELECT * FROM critical_produk_inspection WHERE tanggal=? ORDER BY id DESC");
  if($st){$st->bind_param('s',$date);$st->execute();$res=$st->get_result();while($r=$res->fetch_assoc())$rows[]=$r;$st->close();}
  if($rows){
    $ids=array_map(fn($r)=>(int)$r['id'],$rows);
    foreach($ids as $id){
      $st=$conn->prepare("SELECT * FROM critical_produk_inspection_samples WHERE inspection_id=? ORDER BY id ASC");
      if($st){$st->bind_param('i',$id);$st->execute();$res=$st->get_result();$samples[$id]=[];while($r=$res->fetch_assoc())$samples[$id][]=$r;$st->close();}
    }
  }
}
function fmt_date_id($v){$t=strtotime($v);return $t?date('d/m/Y',$t):$v;}
function badgeCritical($v){$v=strtoupper((string)$v);return $v==='AC'?'badge-ac':($v==='UN'?'badge-un':'badge-empty');}
$pageTitle='Data Critical Produk'; require __DIR__.'/../../includes/header.php';
?>
<style>
.critical-data{padding-bottom:30px}.critical-data-head{display:flex;align-items:center;gap:12px;justify-content:space-between;margin-bottom:18px}.critical-data-head h1{margin:0;color:#123f78;font-size:28px}.critical-head-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.critical-data-btn{border:0;border-radius:12px;padding:11px 16px;font-weight:900;text-decoration:none;display:inline-flex;align-items:center;gap:7px;cursor:pointer}.critical-data-btn.back{background:#f1f5fb;color:#25466b;border:1px solid #dce6f2}.critical-data-btn.primary{background:linear-gradient(110deg,#176fe8,#f14d98);color:#fff}.critical-filter{display:flex;align-items:center;gap:9px}.critical-filter label{font-size:13px;font-weight:900;color:#234267}.critical-filter input{height:42px;border:1px solid #d5e0ee;border-radius:11px;background:#fff;padding:0 12px;color:#203b5d}.critical-show{height:42px;border:0;border-radius:11px;padding:0 15px;background:linear-gradient(110deg,#176fe8,#2676e9);color:#fff;font-weight:900}.critical-empty{background:#fff;border:1px solid #dbe5f1;border-radius:20px;min-height:148px;display:grid;place-items:center;text-align:center;box-shadow:0 8px 28px rgba(32,74,124,.06)}.critical-empty h3{margin:0 0 6px;color:#123f78}.critical-empty p{margin:0;color:#71819a}.inspection-card{background:#fff;border:1px solid #dce6f2;border-radius:20px;overflow:hidden;box-shadow:0 8px 28px rgba(32,74,124,.06);margin-bottom:18px}.inspection-card-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;padding:17px 20px;background:linear-gradient(100deg,#eef7ff,#fff6fa);border-bottom:1px solid #e3ebf4}.inspection-card-head h2{margin:0;color:#123f78;font-size:17px}.inspection-meta{margin-top:5px;color:#71819a;font-size:12px}.inspection-status{display:flex;gap:7px;flex-wrap:wrap}.badge-ac,.badge-un,.badge-empty{display:inline-flex;align-items:center;justify-content:center;min-width:38px;height:27px;padding:0 9px;border-radius:999px;font-size:11px;font-weight:900}.badge-ac{background:#e9f8ef;color:#187645}.badge-un{background:#fff0f2;color:#b7264d}.badge-empty{background:#eef2f7;color:#748197}.inspection-body{padding:18px 20px}.critical-summary-table,.critical-sample-table{width:100%;border-collapse:separate;border-spacing:0;border:1px solid #dce6f2;border-radius:14px;overflow:hidden}.critical-summary-table th,.critical-summary-table td,.critical-sample-table th,.critical-sample-table td{padding:10px 11px;border-bottom:1px solid #e8eef5;border-right:1px solid #e8eef5;text-align:left;vertical-align:top;font-size:12px}.critical-summary-table th,.critical-sample-table th{background:#f4f8fd;color:#24476e;font-weight:900}.critical-summary-table tr:last-child td,.critical-sample-table tr:last-child td{border-bottom:0}.critical-summary-table th:last-child,.critical-summary-table td:last-child,.critical-sample-table th:last-child,.critical-sample-table td:last-child{border-right:0}.sample-title{margin:18px 0 10px;font-size:14px;color:#24476e}.table-scroll{overflow:auto;border-radius:14px}.critical-sample-table{min-width:1200px}.inspection-actions{display:flex;justify-content:flex-end;margin-top:14px}.edit-btn{background:#eef6ff;color:#176fcf;border:1px solid #cfe4fb;border-radius:10px;padding:8px 12px;font-weight:900;text-decoration:none;font-size:12px}@media(max-width:950px){.critical-data-head{align-items:flex-start;flex-direction:column}.critical-head-actions{width:100%}.critical-filter{width:100%;flex-wrap:wrap}.critical-filter input{flex:1;min-width:150px}.inspection-card-head{flex-direction:column}.critical-summary-table{display:block;overflow:auto;white-space:nowrap}.critical-summary-table table{width:900px}}
</style>
<div class="critical-data">
  <div class="critical-data-head">
    <h1>Data Critical Produk</h1>
    <div class="critical-head-actions">
      <a class="critical-data-btn back" href="../../stocker.php">← Kembali</a>
      <form class="critical-filter" method="get">
        <input id="date" type="date" name="date" value="<?=e($date)?>">
        <button class="critical-show" type="submit">Tampilkan</button>
      </form>
      <a class="critical-data-btn primary" href="inputcriticalproduk.php">＋ Input Data</a>
    </div>
  </div>

  <?php if($error): ?><div class="critical-empty"><div><h3>Database belum siap</h3><p><?=e($error)?></p></div></div>
  <?php elseif(!$rows): ?>
    <div class="critical-empty"><div><h3>Belum ada data</h3><p>Silakan pilih tanggal atau klik ＋ Input Data untuk menambahkan data.</p></div></div>
  <?php else: ?>
    <?php foreach($rows as $row): $id=(int)$row['id']; $smSamples=$samples[$id]??[]; ?>
      <div class="inspection-card">
        <div class="inspection-card-head">
          <div><h2>Incoming External Goods Inspection (Critical Product)</h2><div class="inspection-meta">Tanggal <?=e(fmt_date_id($row['tanggal']))?> · Nama SM <?=e($row['nama_sm'])?> · Nama Stocker <?=e($row['nama_stocker'])?></div></div>
          <div class="inspection-status"><span class="<?=e(badgeCritical($row['grooming_supplier']))?>"><?=e($row['grooming_supplier'])?></span><span class="<?=e(badgeCritical($row['peralatan_kerja']))?>"><?=e($row['peralatan_kerja'])?></span><span class="<?=e(badgeCritical($row['kebersihan_area_unloading']))?>"><?=e($row['kebersihan_area_unloading'])?></span><span class="<?=e(badgeCritical($row['pemeriksaan_sampling']))?>"><?=e($row['pemeriksaan_sampling'])?></span><span class="<?=e(badgeCritical($row['procedure_penghitungan_product']))?>"><?=e($row['procedure_penghitungan_product'])?></span><span class="<?=e(badgeCritical($row['waktu_pemindahan_frozen']))?>"><?=e($row['waktu_pemindahan_frozen'])?></span></div>
        </div>
        <div class="inspection-body">
          <table class="critical-summary-table">
            <thead><tr><th>Grooming Supplier</th><th>Peralatan Kerja</th><th>Kebersihan Area Unloading</th><th>Pemeriksaan Sampling</th><th>Procedure Penghitungan</th><th>Waktu Pemindahan Frozen</th><th>Suhu Truk</th><th>Manager</th></tr></thead>
            <tbody><tr><td><span class="<?=e(badgeCritical($row['grooming_supplier']))?>"><?=e($row['grooming_supplier'])?></span></td><td><span class="<?=e(badgeCritical($row['peralatan_kerja']))?>"><?=e($row['peralatan_kerja'])?></span></td><td><span class="<?=e(badgeCritical($row['kebersihan_area_unloading']))?>"><?=e($row['kebersihan_area_unloading'])?></span></td><td><span class="<?=e(badgeCritical($row['pemeriksaan_sampling']))?>"><?=e($row['pemeriksaan_sampling'])?></span></td><td><span class="<?=e(badgeCritical($row['procedure_penghitungan_product']))?>"><?=e($row['procedure_penghitungan_product'])?></span></td><td><span class="<?=e(badgeCritical($row['waktu_pemindahan_frozen']))?>"><?=e($row['waktu_pemindahan_frozen'])?></span></td><td><?=e($row['suhu_truk'] ?: '-')?></td><td><?=e($row['nama_manager'])?></td></tr></tbody>
          </table>
          <div class="sample-title">Metode Pengambilan Sampel</div>
          <?php if(!$smSamples): ?><div class="critical-empty" style="min-height:90px"><div><p>Belum ada data sample.</p></div></div><?php else: ?>
            <div class="table-scroll">
              <table class="critical-sample-table">
                <thead><tr><th>No</th><th>Nama Produk</th><th>Nama Supp</th><th>Kode Lot</th><th>Nama Produsen</th><th>Alamat</th><th>Negara</th><th>Jumlah & Satuan</th><th>Kode Halal</th><th>Production Date</th><th>Jumlah Sampel</th><th>Temperatur Product</th><th>Diameter Mie</th><th>Ketebalan Kulit Pangsit</th><th>Lebar Kulit / Kerupuk</th><th>Cabe / Buah</th><th>Kondisi Truck</th></tr></thead>
                <tbody><?php foreach($smSamples as $i=>$s): ?><tr><td><?=($i+1)?></td><td><?=e($s['nama_produk'])?></td><td><?=e($s['nama_supp']?:'-')?></td><td><?=e($s['kode_lot']?:'-')?></td><td><?=e($s['nama_produsen']?:'-')?></td><td><?=nl2br(e($s['alamat']?:'-'))?></td><td><?=e($s['negara'])?></td><td><?=e($s['jumlah_satuan_barang']?:'-')?></td><td><span class="<?=e(badgeCritical($s['kode_halal']))?>"><?=e($s['kode_halal']?:'-')?></span></td><td><?=e($s['production_date']?fmt_date_id($s['production_date']):'-')?></td><td><?=e($s['jumlah_sampel']?:'-')?></td><td><?=e($s['temperatur_product']?:'-')?></td><td><?=e($s['diameter_mie']?:'-')?></td><td><?=e($s['ketebalan_kulit_pangsit']?:'-')?></td><td><?=e($s['lebar_kulit_kerupuk']?:'-')?></td><td><?=e($s['kondisi_cabe_buah']?:'-')?></td><td><span class="<?=e(badgeCritical($s['kondisi_truck']))?>"><?=e($s['kondisi_truck'])?></span></td></tr><?php endforeach; ?></tbody>
              </table>
            </div>
          <?php endif; ?>
          <div class="inspection-actions"><a class="edit-btn" href="editcriticalproduk.php?id=<?=$id?>">✏️ Edit Data</a></div>
        </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</div>
<?php require __DIR__.'/../../includes/footer.php'; ?>
