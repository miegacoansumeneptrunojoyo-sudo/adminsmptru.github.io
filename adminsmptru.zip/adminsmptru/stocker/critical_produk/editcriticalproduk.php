<?php
require_once __DIR__.'/../../config/config.php';
require_once __DIR__.'/../../config/database.php';
require_once __DIR__.'/../../config/helpers.php';

function critical_edit_ensure_tables(): bool
{
    global $conn;
    if(!db_ready()) return false;
    $a=$conn->query("CREATE TABLE IF NOT EXISTS `critical_produk_inspection` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `tanggal` DATE NOT NULL, `nama_sm` VARCHAR(180) NOT NULL,
      `grooming_supplier` VARCHAR(10) NOT NULL, `peralatan_kerja` VARCHAR(10) NOT NULL, `kebersihan_area_unloading` VARCHAR(10) NOT NULL,
      `pemeriksaan_sampling` VARCHAR(10) NOT NULL, `procedure_penghitungan_product` VARCHAR(10) NOT NULL, `waktu_pemindahan_frozen` VARCHAR(10) NOT NULL,
      `suhu_truk` VARCHAR(80) DEFAULT NULL, `nama_stocker` VARCHAR(120) NOT NULL, `nama_manager` VARCHAR(180) NOT NULL,
      `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), KEY `idx_critical_inspection_date` (`tanggal`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    $b=$conn->query("CREATE TABLE IF NOT EXISTS `critical_produk_inspection_samples` (
      `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT, `inspection_id` BIGINT UNSIGNED NOT NULL, `nama_produk` VARCHAR(120) NOT NULL,
      `nama_supp` VARCHAR(180) DEFAULT NULL, `kode_lot` VARCHAR(120) DEFAULT NULL, `nama_produsen` VARCHAR(180) DEFAULT NULL,
      `alamat` TEXT DEFAULT NULL, `negara` VARCHAR(80) NOT NULL DEFAULT 'Indonesia', `jumlah_satuan_barang` VARCHAR(180) DEFAULT NULL,
      `kode_halal` VARCHAR(10) DEFAULT NULL, `production_date` DATE DEFAULT NULL, `jumlah_sampel` VARCHAR(80) DEFAULT NULL,
      `temperatur_product` VARCHAR(10) DEFAULT NULL, `diameter_mie` VARCHAR(10) DEFAULT NULL, `ketebalan_kulit_pangsit` VARCHAR(10) DEFAULT NULL,
      `lebar_kulit_kerupuk` VARCHAR(10) DEFAULT NULL, `kondisi_cabe_buah` VARCHAR(10) DEFAULT NULL, `kondisi_truck` VARCHAR(10) NOT NULL,
      `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY (`id`), KEY `idx_critical_sample_inspection` (`inspection_id`),
      CONSTRAINT `fk_critical_sample_inspection` FOREIGN KEY (`inspection_id`) REFERENCES `critical_produk_inspection` (`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    return $a && $b;
}
function critical_edit_clean_samples(array $samples): array {
  $out=[]; foreach($samples as $sample){ if(!is_array($sample)) continue; $v=[];
    foreach(['nama_produk','nama_supp','kode_lot','nama_produsen','alamat','jumlah_satuan_barang','kode_halal','production_date','jumlah_sampel','temperatur_product','diameter_mie','ketebalan_kulit_pangsit','lebar_kulit_kerupuk','kondisi_cabe_buah','kondisi_truck'] as $f) $v[$f]=trim((string)($sample[$f]??''));
    $v['negara']='Indonesia'; if($v['nama_produk']!=='')$out[]=$v;
  } return $out;
}
$id=(int)($_GET['id']??$_POST['id']??0); $error=''; $row=null; $samples=[];
if($id<=0)exit('ID tidak valid.');
if(!critical_edit_ensure_tables()) $error='Database belum siap: '.db_error_message();
if(!$error){$st=$conn->prepare('SELECT * FROM critical_produk_inspection WHERE id=?');$st->bind_param('i',$id);$st->execute();$res=$st->get_result();$row=$res->fetch_assoc();$st->close();if(!$row)exit('Data tidak ditemukan.');
  $st=$conn->prepare('SELECT * FROM critical_produk_inspection_samples WHERE inspection_id=? ORDER BY id');$st->bind_param('i',$id);$st->execute();$res=$st->get_result();while($s=$res->fetch_assoc())$samples[]=$s;$st->close();
}
if($_SERVER['REQUEST_METHOD']==='POST'&&!$error){
  $checks=['grooming_supplier','peralatan_kerja','kebersihan_area_unloading','pemeriksaan_sampling','procedure_penghitungan_product','waktu_pemindahan_frozen'];
  foreach($checks as $f){if(!in_array($_POST[$f]??'', ['AC','UN'],true)){$error='Semua hasil pengecekan kendaraan wajib dipilih AC atau UN.';break;}}
  $namaStocker=trim((string)($_POST['nama_stocker']??''));$suhuTruk=trim((string)($_POST['suhu_truk']??''));$newSamples=critical_edit_clean_samples($_POST['samples']??[]);
  if(!$error&&!$namaStocker)$error='Nama Stocker wajib dipilih.';
  if(!$error&&!$newSamples)$error='Minimal 1 sample produk harus diisi.';
  if(!$error){foreach($newSamples as $s){
    if(!in_array($s['kode_halal'],['AC','UN'],true)||!in_array($s['kondisi_truck'],['AC','UN'],true)){$error='Kode Halal dan Kondisi Truck pada setiap sample wajib dipilih AC atau UN.';break;}
    if(in_array($s['nama_produk'],['Mie Mentah','Kulit Pangsit','Krupuk Mie'],true)&&!in_array($s['temperatur_product'],['AC','UN'],true)){$error='Temperatur Product wajib dipilih untuk Mie Mentah, Kulit Pangsit, dan Krupuk Mie.';break;}
    if($s['nama_produk']==='Mie Mentah'&&!in_array($s['diameter_mie'],['AC','UN'],true)){$error='Ukuran Diameter Mie wajib dipilih untuk Mie Mentah.';break;}
    if($s['nama_produk']==='Kulit Pangsit'&&!in_array($s['ketebalan_kulit_pangsit'],['AC','UN'],true)){$error='Ketebalan Kulit Pangsit wajib dipilih untuk Kulit Pangsit.';break;}
    if(in_array($s['nama_produk'],['Kulit Pangsit','Krupuk Mie'],true)&&!in_array($s['lebar_kulit_kerupuk'],['AC','UN'],true)){$error='Ukuran Lebar wajib dipilih untuk Kulit Pangsit dan Krupuk Mie.';break;}
    if(in_array($s['nama_produk'],['Cabe Rawit','Apel','Belimbing','Peer','Strawberry','Cincau','Jeruk Nipis'],true)&&!in_array($s['kondisi_cabe_buah'],['AC','UN'],true)){$error='Pemeriksaan Cabe/Buah wajib dipilih untuk produk fresh.';break;}
  }}
  if(!$error){$conn->begin_transaction();try{
    $st=$conn->prepare("UPDATE critical_produk_inspection SET grooming_supplier=?,peralatan_kerja=?,kebersihan_area_unloading=?,pemeriksaan_sampling=?,procedure_penghitungan_product=?,waktu_pemindahan_frozen=?,suhu_truk=?,nama_stocker=? WHERE id=?");
    $st->bind_param('ssssssssi',$_POST['grooming_supplier'],$_POST['peralatan_kerja'],$_POST['kebersihan_area_unloading'],$_POST['pemeriksaan_sampling'],$_POST['procedure_penghitungan_product'],$_POST['waktu_pemindahan_frozen'],$suhuTruk,$namaStocker,$id);if(!$st->execute())throw new Exception($st->error);$st->close();
    $del=$conn->prepare('DELETE FROM critical_produk_inspection_samples WHERE inspection_id=?');$del->bind_param('i',$id);$del->execute();$del->close();
    $ins=$conn->prepare("INSERT INTO critical_produk_inspection_samples (inspection_id,nama_produk,nama_supp,kode_lot,nama_produsen,alamat,negara,jumlah_satuan_barang,kode_halal,production_date,jumlah_sampel,temperatur_product,diameter_mie,ketebalan_kulit_pangsit,lebar_kulit_kerupuk,kondisi_cabe_buah,kondisi_truck) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    foreach($newSamples as $s){$pd=$s['production_date']!==''?$s['production_date']:null;$ins->bind_param('issssssssssssssss',$id,$s['nama_produk'],$s['nama_supp'],$s['kode_lot'],$s['nama_produsen'],$s['alamat'],$s['negara'],$s['jumlah_satuan_barang'],$s['kode_halal'],$pd,$s['jumlah_sampel'],$s['temperatur_product'],$s['diameter_mie'],$s['ketebalan_kulit_pangsit'],$s['lebar_kulit_kerupuk'],$s['kondisi_cabe_buah'],$s['kondisi_truck']);if(!$ins->execute())throw new Exception($ins->error);} $ins->close();$conn->commit();redirect_to('datacriticalproduk.php?date='.urlencode($row['tanggal']));
  }catch(Throwable $ex){$conn->rollback();$error='Data gagal diperbarui: '.$ex->getMessage();}
  }
}
if($_SERVER['REQUEST_METHOD']==='POST'&&!$error){$row['grooming_supplier']=$_POST['grooming_supplier'];$row['peralatan_kerja']=$_POST['peralatan_kerja'];$row['kebersihan_area_unloading']=$_POST['kebersihan_area_unloading'];$row['pemeriksaan_sampling']=$_POST['pemeriksaan_sampling'];$row['procedure_penghitungan_product']=$_POST['procedure_penghitungan_product'];$row['waktu_pemindahan_frozen']=$_POST['waktu_pemindahan_frozen'];$row['suhu_truk']=$_POST['suhu_truk'];$row['nama_stocker']=$_POST['nama_stocker'];$samples=$_POST['samples']??[];}
$pageTitle='Edit Critical Produk';require __DIR__.'/../../includes/header.php';
?>
<style>
.critical-edit{padding-bottom:30px}.critical-edit-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px}.critical-edit-head h1{margin:0;color:#123f78;font-size:27px}.critical-e-panel{background:#fff;border:1px solid #dbe6f4;border-radius:20px;box-shadow:0 8px 28px rgba(32,74,124,.07);overflow:hidden;margin-bottom:18px}.critical-e-head{padding:15px 20px;background:linear-gradient(100deg,#087cf0,#1769e8);color:#fff;font-weight:900}.critical-e-body{padding:18px 20px}.critical-e-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:15px}.critical-e-grid label{display:flex;flex-direction:column;gap:7px;font-weight:800;color:#2d4667;font-size:13px}.critical-e-grid .full{grid-column:1/-1}.critical-e-grid input,.critical-e-grid select,.critical-e-grid textarea{min-height:44px;border:1px solid #d5e0ee;border-radius:11px;padding:11px 12px;background:#fbfdff;color:#203b5d}.critical-e-grid textarea{resize:vertical}.critical-e-grid input:focus,.critical-e-grid select:focus,.critical-e-grid textarea:focus{border-color:#287cf0;box-shadow:0 0 0 3px rgba(40,124,240,.1)}.critical-e-checks{display:grid;grid-template-columns:1fr 130px;border:1px solid #dce6f2;border-radius:14px;overflow:hidden}.critical-e-checks>div{padding:11px 13px;border-bottom:1px solid #e7eef5}.critical-e-checks>div:nth-last-child(-n+2){border-bottom:0}.critical-e-checks .res{border-left:1px solid #e7eef5}.critical-e-checks select{width:100%;height:40px;border:1px solid #d5e0ee;border-radius:10px}.sample-edit-card{border:1px solid #dce6f2;border-radius:16px;padding:16px;margin-bottom:13px;background:#fcfeff}.sample-edit-card h3{margin:0 0 12px;color:#1a4d82;font-size:14px}.sample-remove{margin-top:8px;border:0;background:#fff0f5;color:#c53c72;border-radius:10px;padding:8px 11px;font-weight:800}.sample-cond{display:none}.sample-cond.show{display:flex}.e-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:18px}.e-btn{border:0;border-radius:12px;padding:11px 17px;font-weight:900;text-decoration:none;cursor:pointer}.e-back{background:#eef3fa;color:#41516b}.e-save{background:#176fe8;color:#fff}@media(max-width:850px){.critical-e-grid{grid-template-columns:1fr}.critical-e-grid .full{grid-column:auto}.critical-edit-head{align-items:flex-start;gap:10px;flex-direction:column}.critical-e-checks{grid-template-columns:1fr 105px}}
</style>
<div class="critical-edit">
  <div class="critical-edit-head"><h1>Edit Critical Produk</h1><a class="e-btn e-back" href="datacriticalproduk.php?date=<?=e($row['tanggal'])?>">← Kembali</a></div>
  <?php if($error): ?><div class="alert alert-error"><?=e($error)?></div><?php endif; ?>
  <form method="post">
    <input type="hidden" name="id" value="<?=$id?>">
    <div class="critical-e-panel"><div class="critical-e-head">Informasi Inspeksi</div><div class="critical-e-body"><div class="critical-e-grid"><label>Tanggal<input type="text" value="<?=e($row['tanggal'])?>" readonly></label><label>Nama SM<input type="text" value="Alvin Zakaria" readonly></label></div></div></div>
    <div class="critical-e-panel"><div class="critical-e-head">Pengecekan Kebersihan Box dan Fungsi Pendingin</div><div class="critical-e-body"><div class="critical-e-checks">
      <?php $checks=['grooming_supplier'=>'Grooming Supplier','peralatan_kerja'=>'Peralatan Kerja lengkap','kebersihan_area_unloading'=>'Kebersihan area unloading','pemeriksaan_sampling'=>'Pemeriksaan Sampling','procedure_penghitungan_product'=>'Procedure Penghitungan product','waktu_pemindahan_frozen'=>'Waktu yang dibutuhkan untuk memindahkan product frozen ke CS / Freezer'];foreach($checks as $n=>$lab):?><div><?=e($lab)?></div><div class="res"><select name="<?=$n?>"><option value="">Pilih</option><option value="UN" <?=($row[$n]==='UN'?'selected':'')?>>UN</option><option value="AC" <?=($row[$n]==='AC'?'selected':'')?>>AC</option></select></div><?php endforeach;?></div></div></div>
    <div class="critical-e-panel"><div class="critical-e-head">Metode Pengambilan Sampel</div><div class="critical-e-body">
      <div id="editSamples">
      <?php $products=['Mie Mentah','Kulit Pangsit','Krupuk Mie','Cabe Rawit','Apel','Belimbing','Peer','Strawberry','Cincau','Jeruk Nipis']; foreach($samples as $i=>$s): ?>
        <div class="sample-edit-card" data-card><h3>Sample <?=($i+1)?></h3><div class="critical-e-grid">
          <label>Nama Produk<select name="samples[<?=$i?>][nama_produk]" data-product><option value="">Pilih produk</option><?php foreach($products as $p):?><option value="<?=e($p)?>" <?=($s['nama_produk']===$p?'selected':'')?>><?=e($p)?></option><?php endforeach;?></select></label>
          <label>Nama Supp<input name="samples[<?=$i?>][nama_supp]" value="<?=e($s['nama_supp'])?>"></label><label>Kode Lot<input name="samples[<?=$i?>][kode_lot]" value="<?=e($s['kode_lot'])?>"></label><label>Nama Produsen<input name="samples[<?=$i?>][nama_produsen]" value="<?=e($s['nama_produsen'])?>"></label>
          <label class="full">Alamat<textarea name="samples[<?=$i?>][alamat]" rows="2"><?=e($s['alamat'])?></textarea></label><label>Negara<input value="Indonesia" readonly></label><label>Jumlah dan Satuan Barang<input name="samples[<?=$i?>][jumlah_satuan_barang]" value="<?=e($s['jumlah_satuan_barang'])?>"></label><label>Kode Halal<select name="samples[<?=$i?>][kode_halal]"><option value="">Pilih</option><option value="AC" <?=($s['kode_halal']==='AC'?'selected':'')?>>AC</option><option value="UN" <?=($s['kode_halal']==='UN'?'selected':'')?>>UN</option></select></label><label>Production Date<input type="date" name="samples[<?=$i?>][production_date]" value="<?=e($s['production_date'])?>"></label><label>Jumlah Sampel<input name="samples[<?=$i?>][jumlah_sampel]" value="<?=e($s['jumlah_sampel'])?>"></label>
          <label class="sample-cond temp full">Temperatur Product (min -12 °C)<select name="samples[<?=$i?>][temperatur_product]"><option value="">Pilih</option><option value="AC" <?=($s['temperatur_product']==='AC'?'selected':'')?>>AC</option><option value="UN" <?=($s['temperatur_product']==='UN'?'selected':'')?>>UN</option></select></label>
          <label class="sample-cond mie">Ukuran Diameter Mie (1,5 - 1,6 mm)<select name="samples[<?=$i?>][diameter_mie]"><option value="">Pilih</option><option value="AC" <?=($s['diameter_mie']==='AC'?'selected':'')?>>AC</option><option value="UN" <?=($s['diameter_mie']==='UN'?'selected':'')?>>UN</option></select></label>
          <label class="sample-cond kulit">Ketebalan Kulit Pangsit (0,65 - 0,7 mm)<select name="samples[<?=$i?>][ketebalan_kulit_pangsit]"><option value="">Pilih</option><option value="AC" <?=($s['ketebalan_kulit_pangsit']==='AC'?'selected':'')?>>AC</option><option value="UN" <?=($s['ketebalan_kulit_pangsit']==='UN'?'selected':'')?>>UN</option></select></label>
          <label class="sample-cond lebar">Lebar Kulit Pangsit (12 x 12 cm) dan Kerupuk Mie (3 x 3 cm)<select name="samples[<?=$i?>][lebar_kulit_kerupuk]"><option value="">Pilih</option><option value="AC" <?=($s['lebar_kulit_kerupuk']==='AC'?'selected':'')?>>AC</option><option value="UN" <?=($s['lebar_kulit_kerupuk']==='UN'?'selected':'')?>>UN</option></select></label>
          <label class="sample-cond fresh full">Cabe Rawit (80% warna merah) dan Buah (segar, tidak ada yang busuk / mengandung larva)<select name="samples[<?=$i?>][kondisi_cabe_buah]"><option value="">Pilih</option><option value="AC" <?=($s['kondisi_cabe_buah']==='AC'?'selected':'')?>>AC</option><option value="UN" <?=($s['kondisi_cabe_buah']==='UN'?'selected':'')?>>UN</option></select></label>
          <label class="full">Kondisi Truck / Armada Supplier (Tidak ada barang najis, Tidak ada bahan kimia, bersih)<select name="samples[<?=$i?>][kondisi_truck]"><option value="">Pilih</option><option value="AC" <?=($s['kondisi_truck']==='AC'?'selected':'')?>>AC</option><option value="UN" <?=($s['kondisi_truck']==='UN'?'selected':'')?>>UN</option></select></label>
        </div><button type="button" class="sample-remove" data-remove <?=($i===0?'disabled':'')?>>× Hapus Sample</button></div>
      <?php endforeach; ?>
      </div><button type="button" class="critical-add" id="addEditSample">＋ Tambah Sample</button>
      <div class="critical-e-grid" style="margin-top:15px"><label>Suhu Truk<input name="suhu_truk" value="<?=e($row['suhu_truk'])?>" placeholder="Contoh: -18 °C"></label><label>Nama Stocker<select name="nama_stocker"><option value="Arjuna" <?=($row['nama_stocker']==='Arjuna'?'selected':'')?>>Arjuna</option><option value="Kafi" <?=($row['nama_stocker']==='Kafi'?'selected':'')?>>Kafi</option></select></label></div>
      <div class="e-actions"><a class="e-btn e-back" href="datacriticalproduk.php?date=<?=e($row['tanggal'])?>">Batal</a><button class="e-btn e-save" type="submit">Simpan Perubahan</button></div>
    </div></div>
  </form>
</div>
<script>
(function(){const wrap=document.getElementById('editSamples'),add=document.getElementById('addEditSample');function show(card){const p=card.querySelector('[data-product]')?.value||'';const sets={temp:['Mie Mentah','Kulit Pangsit','Krupuk Mie'],mie:['Mie Mentah'],kulit:['Kulit Pangsit'],lebar:['Kulit Pangsit','Krupuk Mie'],fresh:['Cabe Rawit','Apel','Belimbing','Peer','Strawberry','Cincau','Jeruk Nipis']};Object.keys(sets).forEach(cls=>{const el=card.querySelector('.'+cls);if(!el)return;const ok=sets[cls].includes(p);el.classList.toggle('show',ok);const s=el.querySelector('select');if(s){s.required=ok;if(!ok)s.value='';}})}function renumber(){wrap.querySelectorAll('[data-card]').forEach((c,i)=>{c.querySelector('h3').textContent='Sample '+(i+1);c.querySelectorAll('[name]').forEach(el=>el.name=el.name.replace(/samples\[\d+\]/,'samples['+i+']'));const b=c.querySelector('[data-remove]');if(b)b.disabled=i===0;});}wrap.addEventListener('change',e=>{if(e.target.matches('[data-product]'))show(e.target.closest('[data-card]'))});wrap.addEventListener('click',e=>{if(e.target.matches('[data-remove]')&&!e.target.disabled){e.target.closest('[data-card]').remove();renumber()}});wrap.querySelectorAll('[data-card]').forEach(show);add.addEventListener('click',()=>{const src=wrap.querySelector('[data-card]'),i=wrap.querySelectorAll('[data-card]').length,c=src.cloneNode(true);c.querySelectorAll('[name]').forEach(el=>{el.name=el.name.replace(/samples\[\d+\]/,'samples['+i+']');if(el.tagName==='INPUT'||el.tagName==='TEXTAREA')el.value='';if(el.tagName==='SELECT')el.selectedIndex=0});c.querySelector('[data-remove]').disabled=false;wrap.appendChild(c);show(c)});})();
</script>
<?php require __DIR__.'/../../includes/footer.php'; ?>
