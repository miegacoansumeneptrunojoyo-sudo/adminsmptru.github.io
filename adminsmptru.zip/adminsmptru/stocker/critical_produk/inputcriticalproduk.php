<?php
require_once __DIR__.'/../../config/config.php';
require_once __DIR__.'/../../config/database.php';
require_once __DIR__.'/../../config/helpers.php';

function critical_ensure_tables(): bool
{
    global $conn;
    if (!db_ready()) return false;

    $sqlMain = "CREATE TABLE IF NOT EXISTS `critical_produk_inspection` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `tanggal` DATE NOT NULL,
        `nama_sm` VARCHAR(180) NOT NULL,
        `grooming_supplier` VARCHAR(10) NOT NULL,
        `peralatan_kerja` VARCHAR(10) NOT NULL,
        `kebersihan_area_unloading` VARCHAR(10) NOT NULL,
        `pemeriksaan_sampling` VARCHAR(10) NOT NULL,
        `procedure_penghitungan_product` VARCHAR(10) NOT NULL,
        `waktu_pemindahan_frozen` VARCHAR(10) NOT NULL,
        `suhu_truk` VARCHAR(80) DEFAULT NULL,
        `nama_stocker` VARCHAR(120) NOT NULL,
        `nama_manager` VARCHAR(180) NOT NULL,
        `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `idx_critical_inspection_date` (`tanggal`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

    $sqlSample = "CREATE TABLE IF NOT EXISTS `critical_produk_inspection_samples` (
        `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        `inspection_id` BIGINT UNSIGNED NOT NULL,
        `nama_produk` VARCHAR(120) NOT NULL,
        `nama_supp` VARCHAR(180) DEFAULT NULL,
        `kode_lot` VARCHAR(120) DEFAULT NULL,
        `nama_produsen` VARCHAR(180) DEFAULT NULL,
        `alamat` TEXT DEFAULT NULL,
        `negara` VARCHAR(80) NOT NULL DEFAULT 'Indonesia',
        `jumlah_satuan_barang` VARCHAR(180) DEFAULT NULL,
        `kode_halal` VARCHAR(10) DEFAULT NULL,
        `production_date` DATE DEFAULT NULL,
        `jumlah_sampel` VARCHAR(80) DEFAULT NULL,
        `suhu_truk` VARCHAR(80) DEFAULT NULL,
        `temperatur_product` VARCHAR(10) DEFAULT NULL,
        `diameter_mie` VARCHAR(10) DEFAULT NULL,
        `ketebalan_kulit_pangsit` VARCHAR(10) DEFAULT NULL,
        `lebar_kulit_kerupuk` VARCHAR(10) DEFAULT NULL,
        `kondisi_cabe_buah` VARCHAR(10) DEFAULT NULL,
        `kondisi_truck` VARCHAR(10) NOT NULL,
        `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (`id`),
        KEY `idx_critical_sample_inspection` (`inspection_id`),
        CONSTRAINT `fk_critical_sample_inspection` FOREIGN KEY (`inspection_id`) REFERENCES `critical_produk_inspection` (`id`) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";

    $ok = $conn->query($sqlMain) && $conn->query($sqlSample);
    if ($ok) {
        $col = $conn->query("SHOW COLUMNS FROM `critical_produk_inspection_samples` LIKE 'suhu_truk'");
        if ($col && $col->num_rows === 0) {
            $conn->query("ALTER TABLE `critical_produk_inspection_samples` ADD COLUMN `suhu_truk` VARCHAR(80) DEFAULT NULL AFTER `jumlah_sampel`");
        }
    }
    return $ok;
}

function critical_clean_samples(array $samples): array
{
    $out = [];
    foreach ($samples as $sample) {
        if (!is_array($sample)) continue;
        $item = [
            'nama_produk' => trim((string)($sample['nama_produk'] ?? '')),
            'nama_supp' => trim((string)($sample['nama_supp'] ?? '')),
            'kode_lot' => trim((string)($sample['kode_lot'] ?? '')),
            'nama_produsen' => trim((string)($sample['nama_produsen'] ?? '')),
            'alamat' => trim((string)($sample['alamat'] ?? '')),
            'negara' => 'Indonesia',
            'jumlah_satuan_barang' => trim((string)($sample['jumlah_satuan_barang'] ?? '')),
            'kode_halal' => trim((string)($sample['kode_halal'] ?? '')),
            'production_date' => trim((string)($sample['production_date'] ?? '')),
            'jumlah_sampel' => trim((string)($sample['jumlah_sampel'] ?? '')),
            'suhu_truk' => trim((string)($sample['suhu_truk'] ?? '')),
            'temperatur_product' => trim((string)($sample['temperatur_product'] ?? '')),
            'diameter_mie' => trim((string)($sample['diameter_mie'] ?? '')),
            'ketebalan_kulit_pangsit' => trim((string)($sample['ketebalan_kulit_pangsit'] ?? '')),
            'lebar_kulit_kerupuk' => trim((string)($sample['lebar_kulit_kerupuk'] ?? '')),
            'kondisi_cabe_buah' => trim((string)($sample['kondisi_cabe_buah'] ?? '')),
            'kondisi_truck' => trim((string)($sample['kondisi_truck'] ?? '')),
        ];
        if ($item['nama_produk'] !== '') $out[] = $item;
    }
    return $out;
}

function critical_render_sample_card(int $i, array $s = []): void
{
    $products = ['Mie Mentah','Kulit Pangsit','Krupuk Mie','Cabe Rawit','Apel','Belimbing','Peer','Strawberry','Cincau','Jeruk Nipis'];
    ?>
    <div class="critical-sample-card" data-sample-card data-index="<?=$i?>">
      <div class="critical-sample-head">
        <div><span class="critical-step">Sample <b class="sample-number"><?=($i+1)?></b></span></div>
        <button type="button" class="critical-remove" data-remove-sample <?=($i===0?'disabled':'')?> >× Hapus</button>
      </div>
      <div class="critical-grid">
        <label>Nama Produk
          <select name="samples[<?=$i?>][nama_produk]" class="sample-product" data-index="<?=$i?>" required>
            <option value="">Pilih produk</option>
            <?php foreach($products as $p): ?><option value="<?=e($p)?>" <?=((($s['nama_produk'] ?? '') === $p)?'selected':'')?>><?=e($p)?></option><?php endforeach; ?>
          </select>
        </label>
        <label>Nama Supp<input type="text" name="samples[<?=$i?>][nama_supp]" value="<?=e($s['nama_supp'] ?? '')?>"></label>
        <label>Kode Lot<input type="text" name="samples[<?=$i?>][kode_lot]" value="<?=e($s['kode_lot'] ?? '')?>"></label>
        <label>Nama Produsen<input type="text" name="samples[<?=$i?>][nama_produsen]" value="<?=e($s['nama_produsen'] ?? '')?>"></label>
        <label class="full">Alamat<textarea name="samples[<?=$i?>][alamat]" rows="2"><?=e($s['alamat'] ?? '')?></textarea></label>
        <label>Negara<input type="text" value="Indonesia" readonly class="locked-input"><input type="hidden" name="samples[<?=$i?>][negara]" value="Indonesia"></label>
        <label>Jumlah dan Satuan Barang<input type="text" name="samples[<?=$i?>][jumlah_satuan_barang]" value="<?=e($s['jumlah_satuan_barang'] ?? '')?>" placeholder="Contoh: 1 pack, 2 karton, 1 slop"></label>
        <label>Kode Halal
          <select name="samples[<?=$i?>][kode_halal]"><option value="">Pilih</option><option value="AC" <?=((($s['kode_halal'] ?? '')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($s['kode_halal'] ?? '')==='UN')?'selected':'')?>>UN</option></select>
        </label>
        <label>Production Date<input type="date" name="samples[<?=$i?>][production_date]" value="<?=e($s['production_date'] ?? '')?>"></label>
        <label>Jumlah Sampel<input type="text" name="samples[<?=$i?>][jumlah_sampel]" value="<?=e($s['jumlah_sampel'] ?? '')?>" placeholder="Contoh: 2 sample"></label>
      </div>

      <div class="critical-conditional-grid">
        <label class="conditional-field only-temp" data-show-for="Mie Mentah|Kulit Pangsit|Krupuk Mie">Suhu Truk
          <input type="text" name="samples[<?=$i?>][suhu_truk]" value="<?=e($s['suhu_truk'] ?? '')?>" placeholder="Contoh: -18 °C">
        </label>
        <label class="conditional-field only-temp" data-show-for="Mie Mentah|Kulit Pangsit|Krupuk Mie">Temperatur Product (min -12 °C)
          <select name="samples[<?=$i?>][temperatur_product]"><option value="">Pilih</option><option value="AC" <?=((($s['temperatur_product'] ?? '')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($s['temperatur_product'] ?? '')==='UN')?'selected':'')?>>UN</option></select>
        </label>
        <label class="conditional-field only-mie" data-show-for="Mie Mentah">Ukuran Diameter Mie (1,5 - 1,6 mm)
          <select name="samples[<?=$i?>][diameter_mie]"><option value="">Pilih</option><option value="AC" <?=((($s['diameter_mie'] ?? '')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($s['diameter_mie'] ?? '')==='UN')?'selected':'')?>>UN</option></select>
        </label>
        <label class="conditional-field only-kulit" data-show-for="Kulit Pangsit">Ketebalan Kulit Pangsit (0,65 - 0,7 mm)
          <select name="samples[<?=$i?>][ketebalan_kulit_pangsit]"><option value="">Pilih</option><option value="AC" <?=((($s['ketebalan_kulit_pangsit'] ?? '')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($s['ketebalan_kulit_pangsit'] ?? '')==='UN')?'selected':'')?>>UN</option></select>
        </label>
        <label class="conditional-field only-lebar" data-show-for="Kulit Pangsit|Krupuk Mie">Lebar Kulit Pangsit (12 x 12 cm) dan Kerupuk Mie (3 x 3 cm)
          <select name="samples[<?=$i?>][lebar_kulit_kerupuk]"><option value="">Pilih</option><option value="AC" <?=((($s['lebar_kulit_kerupuk'] ?? '')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($s['lebar_kulit_kerupuk'] ?? '')==='UN')?'selected':'')?>>UN</option></select>
        </label>
        <label class="conditional-field only-fresh" data-show-for="Cabe Rawit|Apel|Belimbing|Peer|Strawberry|Cincau|Jeruk Nipis">Cabe Rawit (80% warna merah) dan Buah (segar, tidak ada yang busuk / mengandung larva)
          <select name="samples[<?=$i?>][kondisi_cabe_buah]"><option value="">Pilih</option><option value="AC" <?=((($s['kondisi_cabe_buah'] ?? '')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($s['kondisi_cabe_buah'] ?? '')==='UN')?'selected':'')?>>UN</option></select>
        </label>
      </div>

      <div class="critical-divider"></div>
      <div class="critical-grid">
        <label class="full">Kondisi Truck / Armada Supplier (Tidak ada barang najis, Tidak ada bahan kimia, bersih)
          <select name="samples[<?=$i?>][kondisi_truck]" required><option value="">Pilih</option><option value="AC" <?=((($s['kondisi_truck'] ?? '')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($s['kondisi_truck'] ?? '')==='UN')?'selected':'')?>>UN</option></select>
        </label>
      </div>
    </div>
    <?php
}

$message=''; $error='';
$today = date('Y-m-d');
$namaSm = 'Alvin Zakaria';
$namaManager = $namaSm;
$postSamples = is_array($_POST['samples'] ?? null) ? $_POST['samples'] : [[]];
$bulanIndo = ['01'=>'Januari','02'=>'Februari','03'=>'Maret','04'=>'April','05'=>'Mei','06'=>'Juni','07'=>'Juli','08'=>'Agustus','09'=>'September','10'=>'Oktober','11'=>'November','12'=>'Desember'];
$tanggalDisplay = date('d').' '.($bulanIndo[date('m')] ?? date('m')).' '.date('Y');

if ($_SERVER['REQUEST_METHOD']==='POST') {
    if (!critical_ensure_tables()) {
        $error = 'Database belum siap: '.db_error_message();
    } else {
        $checks = [
            'grooming_supplier','peralatan_kerja','kebersihan_area_unloading',
            'pemeriksaan_sampling','procedure_penghitungan_product','waktu_pemindahan_frozen'
        ];
        $main = [];
        foreach($checks as $field){ $main[$field] = trim((string)($_POST[$field] ?? '')); }
        $namaStocker = trim((string)($_POST['nama_stocker'] ?? ''));
        $samples = critical_clean_samples($postSamples);
        $suhuParts=[];
        foreach($samples as $smpl){
            if(($smpl['suhu_truk'] ?? '') !== '') $suhuParts[] = ($smpl['nama_produk'] ?? 'Produk').': '.$smpl['suhu_truk'];
        }
        $suhuTruk = implode(' | ', $suhuParts);

        $allowedCheck = ['AC','UN'];
        foreach($checks as $field){ if(!in_array($main[$field], $allowedCheck, true)){ $error='Semua hasil pengecekan kendaraan wajib dipilih AC atau UN.'; break; } }
        if (!$error && !$namaStocker) $error='Nama Stocker wajib dipilih.';
        if (!$error && !$samples) $error='Minimal 1 sample produk harus diisi.';
        if (!$error) {
            foreach($samples as $sample){
                if (!$sample['kode_halal'] || !in_array($sample['kode_halal'], ['AC','UN'], true)) { $error='Kode Halal pada setiap sample wajib dipilih AC atau UN.'; break; }
                if (!$sample['kondisi_truck'] || !in_array($sample['kondisi_truck'], ['AC','UN'], true)) { $error='Kondisi Truck / Armada Supplier pada setiap sample wajib dipilih AC atau UN.'; break; }
                if (in_array($sample['nama_produk'], ['Mie Mentah','Kulit Pangsit','Krupuk Mie'], true)) {
                    if (trim((string)$sample['suhu_truk']) === '') { $error='Suhu Truk wajib diisi untuk Mie Mentah, Kulit Pangsit, dan Krupuk Mie.'; break; }
                    if (!in_array($sample['temperatur_product'], ['AC','UN'], true)) { $error='Temperatur Product wajib dipilih untuk Mie Mentah, Kulit Pangsit, dan Krupuk Mie.'; break; }
                }
                if ($sample['nama_produk']==='Mie Mentah' && !in_array($sample['diameter_mie'], ['AC','UN'], true)) { $error='Ukuran Diameter Mie wajib dipilih untuk Mie Mentah.'; break; }
                if ($sample['nama_produk']==='Kulit Pangsit' && !in_array($sample['ketebalan_kulit_pangsit'], ['AC','UN'], true)) { $error='Ketebalan Kulit Pangsit wajib dipilih untuk Kulit Pangsit.'; break; }
                if (in_array($sample['nama_produk'], ['Kulit Pangsit','Krupuk Mie'], true) && !in_array($sample['lebar_kulit_kerupuk'], ['AC','UN'], true)) { $error='Ukuran Lebar wajib dipilih untuk Kulit Pangsit dan Krupuk Mie.'; break; }
                if (in_array($sample['nama_produk'], ['Cabe Rawit','Apel','Belimbing','Peer','Strawberry','Cincau','Jeruk Nipis'], true) && !in_array($sample['kondisi_cabe_buah'], ['AC','UN'], true)) { $error='Pemeriksaan Cabe/Buah wajib dipilih untuk produk fresh.'; break; }
            }
        }

        if (!$error) {
            $conn->begin_transaction();
            try {
                $stmt=$conn->prepare("INSERT INTO critical_produk_inspection (tanggal,nama_sm,grooming_supplier,peralatan_kerja,kebersihan_area_unloading,pemeriksaan_sampling,procedure_penghitungan_product,waktu_pemindahan_frozen,suhu_truk,nama_stocker,nama_manager) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
                if(!$stmt) throw new Exception('Query header tidak dapat disiapkan.');
                $stmt->bind_param('sssssssssss',$today,$namaSm,$main['grooming_supplier'],$main['peralatan_kerja'],$main['kebersihan_area_unloading'],$main['pemeriksaan_sampling'],$main['procedure_penghitungan_product'],$main['waktu_pemindahan_frozen'],$suhuTruk,$namaStocker,$namaManager);
                if(!$stmt->execute()) throw new Exception($stmt->error);
                $inspectionId=$stmt->insert_id; $stmt->close();

                $sampleStmt=$conn->prepare("INSERT INTO critical_produk_inspection_samples (inspection_id,nama_produk,nama_supp,kode_lot,nama_produsen,alamat,negara,jumlah_satuan_barang,kode_halal,production_date,jumlah_sampel,suhu_truk,temperatur_product,diameter_mie,ketebalan_kulit_pangsit,lebar_kulit_kerupuk,kondisi_cabe_buah,kondisi_truck) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                if(!$sampleStmt) throw new Exception('Query sample tidak dapat disiapkan.');
                foreach($samples as $s){
                    $prodDate = $s['production_date'] !== '' ? $s['production_date'] : null;
                    $sampleStmt->bind_param('isssssssssssssssss',$inspectionId,$s['nama_produk'],$s['nama_supp'],$s['kode_lot'],$s['nama_produsen'],$s['alamat'],$s['negara'],$s['jumlah_satuan_barang'],$s['kode_halal'],$prodDate,$s['jumlah_sampel'],$s['suhu_truk'],$s['temperatur_product'],$s['diameter_mie'],$s['ketebalan_kulit_pangsit'],$s['lebar_kulit_kerupuk'],$s['kondisi_cabe_buah'],$s['kondisi_truck']);
                    if(!$sampleStmt->execute()) throw new Exception($sampleStmt->error);
                }
                $sampleStmt->close();
                $conn->commit();
                redirect_to('datacriticalproduk.php?date='.urlencode($today));
            } catch(Throwable $ex){
                $conn->rollback();
                $error='Data gagal disimpan: '.$ex->getMessage();
            }
        }
    }
}

$pageTitle='Input Critical Produk';
require __DIR__.'/../../includes/header.php';
?>
<style>
.critical-page{background:#f7faff;padding:4px 0 30px}
.critical-top{display:flex;justify-content:space-between;align-items:center;gap:16px;margin-bottom:16px}
.critical-top h1{margin:0;color:#123f78;font-size:29px}
.critical-top p{margin:5px 0 0;color:#72839b;font-size:13px}
.critical-panel{background:#fff;border:1px solid #dbe6f4;border-radius:20px;box-shadow:0 8px 28px rgba(32,74,124,.07);overflow:hidden;margin-bottom:18px}
.critical-section-head{padding:16px 20px;background:linear-gradient(100deg,#087cf0,#1769e8);color:#fff;font-weight:800;font-size:15px}
.critical-section-body{padding:20px}
.critical-meta{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}
.critical-meta-field{display:flex;flex-direction:column;gap:8px;color:#2d4667;font-weight:800;font-size:13px}.critical-meta-value{min-height:48px;display:flex;align-items:center;gap:9px;border:1px solid #d5e0ee;border-radius:12px;background:linear-gradient(180deg,#ffffff,#f7fbff);padding:0 13px;color:#21466f;font-weight:800;box-shadow:inset 0 1px 0 rgba(255,255,255,.9)}.critical-meta-value.locked-meta{background:#f4f8fd;color:#31557d}.meta-icon{font-size:16px}.critical-meta-field select{width:100%;border:1px solid #d5e0ee;border-radius:12px;background:#fff;padding:11px 12px;outline:none;color:#203b5d;min-height:48px;font-weight:800}
.critical-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:15px}
.critical-grid label,.critical-conditional-grid label{display:flex;flex-direction:column;gap:7px;color:#2d4667;font-weight:800;font-size:13px}
.critical-grid label.full,.critical-conditional-grid label.full{grid-column:1/-1}
.critical-grid input,.critical-grid select,.critical-grid textarea,.critical-conditional-grid input,.critical-conditional-grid select{width:100%;border:1px solid #d5e0ee;border-radius:11px;background:#fbfdff;padding:11px 12px;outline:none;color:#203b5d;min-height:44px}
.critical-grid textarea{min-height:86px;resize:vertical}
.critical-grid input:focus,.critical-grid select:focus,.critical-grid textarea:focus,.critical-conditional-grid input:focus,.critical-conditional-grid select:focus{border-color:#287cf0;box-shadow:0 0 0 3px rgba(40,124,240,.10)}
.locked-input{background:#f2f6fb!important;color:#64748b!important;font-weight:700}
.critical-check-table{display:grid;grid-template-columns:minmax(0,1fr) 130px;gap:0;border:1px solid #dce6f2;border-radius:14px;overflow:hidden}
.critical-check-row{display:contents}
.critical-check-label,.critical-check-result{padding:13px 14px;border-bottom:1px solid #e8eef6;background:#fff}
.critical-check-label{font-weight:700;color:#274461}
.critical-check-result{border-left:1px solid #e8eef6}
.critical-check-result select{width:100%;height:40px;border:1px solid #d5e0ee;border-radius:10px;background:#fff;padding:0 10px;font-weight:800;color:#203b5d}
.critical-check-table .critical-check-row:last-child .critical-check-label,.critical-check-table .critical-check-row:last-child .critical-check-result{border-bottom:0}
.critical-note{padding:12px 14px;border-radius:12px;background:#fff3f8;border:1px solid #ffd7e9;color:#8d315d;font-size:12px;margin-top:14px}
.critical-sample-card{border:1px solid #dce6f2;border-radius:17px;background:#fcfeff;padding:17px;margin-top:14px}
.critical-sample-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:14px}
.critical-step{display:inline-flex;gap:6px;align-items:center;padding:7px 10px;border-radius:999px;background:#eaf4ff;color:#166dcc;font-weight:900;font-size:12px}
.critical-step b{background:#fff;border-radius:50%;min-width:23px;height:23px;display:inline-grid;place-items:center}
.critical-remove{border:0;background:#fff0f5;color:#c53c72;border-radius:10px;padding:8px 11px;font-weight:800;cursor:pointer}
.critical-remove:disabled{opacity:.45;cursor:not-allowed}
.critical-conditional-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:15px;margin-top:15px}
.conditional-field{display:none!important}
.conditional-field.is-visible{display:flex!important}
.critical-divider{height:1px;background:#e7eef7;margin:16px 0}
.critical-add{margin-top:14px;border:1px dashed #7fb6ee;background:#eef8ff;color:#1672d2;border-radius:12px;padding:11px 16px;font-weight:900;cursor:pointer}
.critical-actions{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:18px 20px;background:#f7fbff;border-top:1px solid #e3ebf5}
.critical-actions .left-note{color:#71829a;font-size:12px}
.critical-actions .buttons{display:flex;gap:10px}
.critical-btn{border:0;border-radius:12px;padding:12px 18px;font-weight:900;cursor:pointer;text-decoration:none;display:inline-flex;align-items:center;justify-content:center}
.critical-btn.back{background:#eef3fa;color:#41516b}
.critical-btn.save{background:linear-gradient(135deg,#0b88f3,#1769e8);color:#fff}
.critical-sign{display:grid;grid-template-columns:1fr 1fr;border:1px solid #ccd8e6;border-radius:12px;overflow:hidden;margin-top:18px}
.critical-sign-col{display:grid;grid-template-rows:34px 120px 34px;background:#fff}
.critical-sign-col+ .critical-sign-col{border-left:1px solid #ccd8e6}
.critical-sign-title,.critical-sign-name{border-bottom:1px solid #ccd8e6;display:grid;place-items:center;font-weight:800;color:#213e61;font-size:12px}
.critical-sign-space{background:#fff}
.critical-sign-name{border-bottom:0;border-top:1px solid #ccd8e6;font-weight:700}.critical-sign-meta{display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:14px}.critical-sign-meta>div{background:#f7fbff;border:1px solid #dce6f2;border-radius:12px;padding:11px 13px;display:flex;justify-content:space-between;align-items:center;gap:12px}.critical-sign-meta span{font-size:12px;color:#71829a;font-weight:700}.critical-sign-meta strong{font-size:13px;color:#1e4f85}
.alert{padding:12px 14px;border-radius:12px;margin-bottom:14px}.alert-error{background:#fff0f2;color:#b8264c;border:1px solid #ffd1db}
@media(max-width:900px){.critical-meta,.critical-grid,.critical-conditional-grid,.critical-sign-meta{grid-template-columns:1fr}.critical-grid label.full,.critical-conditional-grid label.full{grid-column:auto}.critical-check-table{grid-template-columns:minmax(0,1fr) 110px}.critical-top{align-items:flex-start;flex-direction:column}.critical-top h1{font-size:24px}.critical-actions{align-items:stretch;flex-direction:column}.critical-actions .buttons{width:100%}.critical-actions .critical-btn{flex:1}.critical-sign{grid-template-columns:1fr}.critical-sign-col+ .critical-sign-col{border-left:0;border-top:1px solid #ccd8e6}}
</style>
<div class="critical-page">
  <div class="critical-top">
    <div><h1>Input Critical Produk</h1><p>Incoming External Goods Inspection — Critical Product</p></div>
    <a class="critical-btn back" href="datacriticalproduk.php">← Kembali</a>
  </div>

  <?php if($error): ?><div class="alert alert-error"><?=e($error)?></div><?php endif; ?>

  <form method="post" autocomplete="off">
    <div class="critical-panel">
      <div class="critical-section-head">Informasi Inspeksi</div>
      <div class="critical-section-body">
        <div class="critical-meta">
          <div class="critical-meta-field">
            <span>Tanggal</span>
            <div class="critical-meta-value"><span class="meta-icon">📅</span><span><?=e($tanggalDisplay)?></span></div>
            <input type="hidden" name="tanggal" value="<?=e($today)?>">
          </div>
          <div class="critical-meta-field">
            <span>Nama SM</span>
            <div class="critical-meta-value locked-meta"><span class="meta-icon">👤</span><span><?=e($namaSm)?></span></div>
            <input type="hidden" name="nama_sm" value="<?=e($namaSm)?>">
          </div>
          <label class="critical-meta-field">
            <span>Nama Stocker</span>
            <?php $stock=(string)($_POST['nama_stocker']??''); ?>
            <select id="namaStocker" name="nama_stocker" required><option value="">Pilih Nama Stocker</option><option value="Arjuna" <?=($stock==='Arjuna'?'selected':'')?>>Arjuna</option><option value="Kafi" <?=($stock==='Kafi'?'selected':'')?>>Kafi</option></select>
          </label>
        </div>
      </div>
    </div>

    <div class="critical-panel">
      <div class="critical-section-head">Lakukan Pengecekan Kebersihan Box dan Fungsi Pendingin pada Kendaraan</div>
      <div class="critical-section-body">
        <div class="critical-check-table">
          <?php
          $checks=[
            'grooming_supplier'=>'Grooming Supplier',
            'peralatan_kerja'=>'Peralatan Kerja lengkap',
            'kebersihan_area_unloading'=>'Kebersihan area unloading',
            'pemeriksaan_sampling'=>'Pemeriksaan Sampling',
            'procedure_penghitungan_product'=>'Procedure Penghitungan product',
            'waktu_pemindahan_frozen'=>'Waktu yang dibutuhkan untuk memindahkan product frozen ke CS / Freezer',
          ];
          foreach($checks as $name=>$label):
            $val=(string)($_POST[$name] ?? '');
          ?>
            <div class="critical-check-row">
              <div class="critical-check-label"><?=e($label)?></div>
              <div class="critical-check-result"><select name="<?=e($name)?>" required><option value="">Pilih</option><option value="UN" <?=($val==='UN'?'selected':'')?>>UN</option><option value="AC" <?=($val==='AC'?'selected':'')?>>AC</option></select></div>
            </div>
          <?php endforeach; ?>
        </div>
        <div class="critical-note">Gunakan <strong>AC</strong> apabila kondisi sesuai standar dan <strong>UN</strong> apabila kondisi tidak sesuai standar.</div>
      </div>
    </div>

    <div class="critical-panel">
      <div class="critical-section-head">Metode Pengambilan Sampel</div>
      <div class="critical-section-body">
        <div id="critical-samples">
          <?php
            $sampleInput = (is_array($_POST['samples'] ?? null) && count($_POST['samples'])>0) ? $_POST['samples'] : [[]];
            foreach($sampleInput as $i=>$s) critical_render_sample_card((int)$i, is_array($s)?$s:[]);
          ?>
        </div>
        <button type="button" class="critical-add" id="addSample">＋ Tambah Sample</button>
      </div>
      <div class="critical-actions">
        <div class="left-note">Kolom pemeriksaan khusus akan muncul otomatis sesuai produk yang dipilih.</div>
        <div class="buttons"><a class="critical-btn back" href="datacriticalproduk.php">Batal</a><button class="critical-btn save" type="submit">Simpan Data</button></div>
      </div>
    </div>

    <div class="critical-panel">
      <div class="critical-section-head">Penanggung Jawab</div>
      <div class="critical-section-body">
        <input type="hidden" name="nama_manager" value="<?=e($namaManager)?>">
        <div class="critical-sign-meta">
          <div><span>Nama SM</span><strong id="signatureSm"><?=e($namaSm)?></strong></div>
          <div><span>Nama Stocker</span><strong id="signatureStocker">—</strong></div>
        </div>
        <div class="critical-sign">
          <div class="critical-sign-col">
            <div class="critical-sign-title">DILAPORKAN OLEH</div>
            <div class="critical-sign-space"></div>
            <div class="critical-sign-name" id="signatureStockerBottom">NAMA STOCKER</div>
          </div>
          <div class="critical-sign-col">
            <div class="critical-sign-title">DISETUJUI OLEH</div>
            <div class="critical-sign-space"></div>
            <div class="critical-sign-name" id="signatureManagerBottom">NAMA MANAGER</div>
          </div>
        </div>
      </div>
    </div>
  </form>
</div>

<script>
(function(){
  const wrap=document.getElementById('critical-samples');
  const add=document.getElementById('addSample');
  function updateCard(card){
    const product=card.querySelector('.sample-product')?.value||'';
    card.querySelectorAll('.conditional-field').forEach(el=>{
      const list=(el.dataset.showFor||'').split('|').map(v=>v.trim()).filter(Boolean);
      const show=list.includes(product);
      el.classList.toggle('is-visible',show);
      const sel=el.querySelector('select');
      const inp=el.querySelector('input');
      if(sel){ sel.required=show; if(!show) sel.value=''; }
      if(inp){ inp.required=show; if(!show) inp.value=''; }
    });
  }
  function renumber(){
    wrap.querySelectorAll('[data-sample-card]').forEach((card,idx)=>{
      card.dataset.index=idx;
      const n=card.querySelector('.sample-number'); if(n) n.textContent=idx+1;
      const del=card.querySelector('[data-remove-sample]'); if(del) del.disabled=(idx===0);
    });
  }
  wrap.addEventListener('change',e=>{
    if(e.target.classList.contains('sample-product')) updateCard(e.target.closest('[data-sample-card]'));
  });
  wrap.addEventListener('click',e=>{
    const btn=e.target.closest('[data-remove-sample]');
    if(!btn || btn.disabled) return;
    const card=btn.closest('[data-sample-card]');
    if(card) {card.remove();renumber();}
  });
  document.querySelectorAll('[data-sample-card]').forEach(updateCard);

  const stockerSelect=document.getElementById('namaStocker');
  const signatureStocker=document.getElementById('signatureStocker');
  const signatureStockerBottom=document.getElementById('signatureStockerBottom');
  const signatureManagerBottom=document.getElementById('signatureManagerBottom');
  const signatureSm=document.getElementById('signatureSm');
  function updateSignature(){
    const sm='<?=e($namaSm)?>';
    const stocker=stockerSelect ? (stockerSelect.value||'') : '';
    if(signatureSm) signatureSm.textContent=sm || '—';
    if(signatureStocker) signatureStocker.textContent=stocker || '—';
    if(signatureStockerBottom) signatureStockerBottom.textContent=stocker || 'NAMA STOCKER';
    if(signatureManagerBottom) signatureManagerBottom.textContent=sm || 'NAMA MANAGER';
  }
  if(stockerSelect) stockerSelect.addEventListener('change',updateSignature);
  updateSignature();

  add.addEventListener('click',()=>{
    const source=wrap.querySelector('[data-sample-card]');
    const idx=wrap.querySelectorAll('[data-sample-card]').length;
    const clone=source.cloneNode(true);
    clone.querySelectorAll('[name]').forEach(el=>{
      el.name=el.name.replace(/samples\[\d+\]/,'samples['+idx+']');
      if(el.tagName==='INPUT' || el.tagName==='TEXTAREA') {
        if(el.type==='hidden') el.value='Indonesia'; else el.value='';
      }
      if(el.tagName==='SELECT') el.selectedIndex=0;
    });
    const n=clone.querySelector('.sample-number'); if(n) n.textContent=idx+1;
    const del=clone.querySelector('[data-remove-sample]'); if(del) del.disabled=false;
    wrap.appendChild(clone); updateCard(clone);
    clone.scrollIntoView({behavior:'smooth',block:'center'});
  });
})();
</script>
<?php require __DIR__.'/../../includes/footer.php'; ?>
