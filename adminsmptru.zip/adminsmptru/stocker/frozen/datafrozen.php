<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/helpers.php';

$tanggal = $_GET['tanggal'] ?? date('Y-m-d');
$rows = [];
$error = '';

if (!db_ready()) {
    $error = 'Database belum terhubung: ' . db_error_message();
} else {
    $st = $conn->prepare("SELECT * FROM frozen_stock WHERE tanggal = ? ORDER BY id DESC");
    if ($st) {
        $st->bind_param('s', $tanggal);
        $st->execute();
        $res = $st->get_result();
        while ($r = $res->fetch_assoc()) $rows[] = $r;
        $st->close();
    } else {
        $error = 'Query data Frozen gagal disiapkan.';
    }
}

$pageTitle = 'Data Frozen';
require __DIR__ . '/../../includes/header.php';
?>
<div class="page-head">
  <div><h2>Data Frozen</h2></div>
  <div class="page-actions">
    <a class="btn-action back" href="../../stocker.php">← Kembali</a>
    <form class="critical-filter" method="get">
      <input type="date" name="tanggal" value="<?=e($tanggal)?>" aria-label="Tanggal">
      <button class="critical-show" type="submit">Tampilkan</button>
    </form>
    <a class="btn-action primary" href="inputfrozen.php?tanggal=<?=urlencode($tanggal)?>">＋ Input Data</a>
  </div>
</div>

<?php if ($error): ?><?=flash_message('error',$error)?><?php endif; ?>

<?php if (!$rows): ?>
<div class="panel empty-state">
  <div class="empty-icon">❄️</div>
  <h3>Belum ada data Frozen</h3>
  <p>Belum ada data untuk tanggal <?=e($tanggal)?>.</p>
  <a class="btn-action primary" href="inputfrozen.php?tanggal=<?=urlencode($tanggal)?>">＋ Input Data</a>
</div>
<?php else: ?>
<div class="panel">
  <div class="table-wrap">
    <table class="data-table">
      <thead>
        <tr>
          <th>No</th><th>Tanggal</th><th>Nama Barang</th><th>Lot</th><th>Expired</th>
          <th>Jumlah</th><th>Suhu</th><th>Status</th><th>Catatan</th><th>Aksi</th>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($rows as $i => $r): ?>
        <tr>
          <td><?=e((string)($i+1))?></td>
          <td><?=e($r['tanggal'])?></td>
          <td><?=e($r['nama_barang'])?></td>
          <td><?=e($r['kode_lot'])?></td>
          <td><?=e($r['expired'] ?? '')?></td>
          <td><?=e($r['jumlah'] ?? '')?></td>
          <td><?=e($r['suhu'] ?? '')?></td>
          <td><span class="badge <?=($r['status']==='Baik'?'success':'')?>"><?=e($r['status'] ?? '')?></span></td>
          <td><?=e($r['catatan'] ?? '')?></td>
          <td data-label="Aksi"><a class="btn-action" href="editfrozen.php?id=<?=e((string)$r['id'])?>">✏️ Edit</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
