<?php
require_once __DIR__.'/../../config/config.php';
require_once __DIR__.'/../../config/database.php';
require_once __DIR__.'/../../config/helpers.php';
$id=(int)($_GET['id'] ?? $_POST['id'] ?? 0); $message=''; $error=''; $row=null;
if($id<=0){ http_response_code(400); exit('ID tidak valid.'); }
if(!db_ready()){ $error='Database belum terhubung: '.db_error_message(); } else {
  $st=$conn->prepare('SELECT * FROM `frozen_stock` WHERE id=?'); $st->bind_param('i',$id); $st->execute(); $res=$st->get_result(); $row=$res->fetch_assoc(); $st->close();
  if(!$row){ http_response_code(404); exit('Data tidak ditemukan.'); }
}
if($_SERVER['REQUEST_METHOD']==='POST' && !$error && db_ready()){
  $tanggal=(string)($_POST['tanggal'] ?? $row['tanggal'] ?? '');
  $nama_barang=trim((string)($_POST['nama_barang'] ?? $row['nama_barang'] ?? ''));
  $kode_lot=trim((string)($_POST['kode_lot'] ?? $row['kode_lot'] ?? ''));
  $expired=(string)($_POST['expired'] ?? $row['expired'] ?? '');
  $jumlah=trim((string)($_POST['jumlah'] ?? $row['jumlah'] ?? ''));
  $suhu=trim((string)($_POST['suhu'] ?? $row['suhu'] ?? ''));
  $status=trim((string)($_POST['status'] ?? $row['status'] ?? ''));
  $catatan=trim((string)($_POST['catatan'] ?? $row['catatan'] ?? ''));
  $st=$conn->prepare('UPDATE `frozen_stock` SET `tanggal`=?, `nama_barang`=?, `kode_lot`=?, `expired`=?, `jumlah`=?, `suhu`=?, `status`=?, `catatan`=? WHERE id=?');
  if($st){ $st->bind_param('ssssssssi', $tanggal, $nama_barang, $kode_lot, $expired, $jumlah, $suhu, $status, $catatan, $id); if($st->execute()){ $st->close(); redirect_to('datafrozen.php'); } $error='Gagal memperbarui data: '.$st->error; $st->close(); } else $error='Query update gagal.';
}
$pageTitle='Frozen'; require __DIR__.'/../../includes/header.php';
?>
<div class="page-head"><div><h2>Edit Frozen</h2></div><div class="page-actions"><a class="btn-action back" href="datafrozen.php">← Kembali</a></div></div>
<?php if($error): ?><div class="alert alert-error"><?=e($error)?></div><?php endif; ?>
<form method="post" class="panel form-grid"><input type="hidden" name="id" value="<?=e((string)$id)?>">
<label>Tanggal<input type="date" name="tanggal" value="<?=e($row['tanggal'] ?? '')?>" required></label>
<label>Nama Barang<input type="text" name="nama_barang" value="<?=e($row['nama_barang'] ?? '')?>" required></label>
<label>Kode Lot<input type="text" name="kode_lot" value="<?=e($row['kode_lot'] ?? '')?>"></label>
<label>Expired<input type="date" name="expired" value="<?=e($row['expired'] ?? '')?>"></label>
<label>Jumlah<input type="text" name="jumlah" value="<?=e($row['jumlah'] ?? '')?>"></label>
<label>Suhu<input type="text" name="suhu" value="<?=e($row['suhu'] ?? '')?>"></label>
<label>Status<select name="status">
<option value="Baik" <?=((($row['status'] ?? "")==="Baik")?"selected":"")?>>Baik</option>
<option value="Perlu Perhatian" <?=((($row['status'] ?? "")==="Perlu Perhatian")?"selected":"")?>>Perlu Perhatian</option>
<option value="Tidak Sesuai" <?=((($row['status'] ?? "")==="Tidak Sesuai")?"selected":"")?>>Tidak Sesuai</option>
</select></label>
<label style="grid-column:1/-1">Catatan<textarea name="catatan"><?=e($row['catatan'] ?? '')?></textarea></label>
<div style="grid-column:1/-1;display:flex;gap:10px;justify-content:flex-end;margin-top:12px"><a class="btn-action back" href="datafrozen.php">Batal</a><button class="btn-action primary" type="submit">Update Data</button></div>
</form>
<?php require __DIR__.'/../../includes/footer.php'; ?>