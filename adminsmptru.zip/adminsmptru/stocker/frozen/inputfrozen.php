<?php
require_once __DIR__.'/../../config/config.php';require_once __DIR__.'/../../config/database.php';require_once __DIR__.'/../../config/helpers.php';$message='';$error='';
if($_SERVER['REQUEST_METHOD']==='POST'&&db_ready()){$tanggal=$_POST['tanggal']??$_GET['tanggal']??date('Y-m-d');$barang=trim($_POST['nama_barang']??'');$lot=trim($_POST['kode_lot']??'');$expired=$_POST['expired']??'';$qty=trim($_POST['jumlah']??'');$suhu=trim($_POST['suhu']??'');$status=trim($_POST['status']??'');$catatan=trim($_POST['catatan']??'');$stmt=$conn->prepare("INSERT INTO frozen_stock (tanggal,nama_barang,kode_lot,expired,jumlah,suhu,status,catatan) VALUES (?,?,?,?,?,?,?,?)");if($stmt){$stmt->bind_param('ssssssss',$tanggal,$barang,$lot,$expired,$qty,$suhu,$status,$catatan);if($stmt->execute())$message='Data berhasil disimpan.';else$error=$stmt->error;$stmt->close();}else$error='Query tidak dapat disiapkan.';}elseif($_SERVER['REQUEST_METHOD']==='POST')$error='Database belum siap.';
$pageTitle='Input Frozen';require __DIR__.'/../../includes/header.php';?>
<div class="page-head"><div><h2>Input Frozen</h2></div><div class="page-actions"><a class="btn-action back" href="datafrozen.php">← Kembali</a></div></div>
<?php if($message):?><div class="alert alert-success"><?=e($message)?></div><?php endif;?><?php if($error):?><div class="alert alert-error"><?=e($error)?></div><?php endif;?>
<form method="post" class="panel form-grid">
<label>Tanggal<input type="date" name="tanggal" value="<?=e($_POST['tanggal']??date('Y-m-d'))?>" required></label>
<label>Nama Barang<input name="nama_barang" value="<?=e($_POST['nama_barang']??'')?>" required></label>
<label>Kode Lot<input name="kode_lot" value="<?=e($_POST['kode_lot']??'')?>"></label>
<label>Expired<input type="date" name="expired" value="<?=e($_POST['expired']??'')?>"></label>
<label>Jumlah<input name="jumlah" value="<?=e($_POST['jumlah']??'')?>"></label>
<label>Suhu<input name="suhu" value="<?=e($_POST['suhu']??'')?>" placeholder="Contoh: -18°C"></label>
<label>Status<select name="status"><option value="Baik">Baik</option><option value="Perlu Perhatian">Perlu Perhatian</option><option value="Tidak Sesuai">Tidak Sesuai</option></select></label>
<label style="grid-column:1/-1">Catatan<textarea name="catatan" placeholder="Tulis kondisi barang..."><?=e($_POST['catatan']??'')?></textarea></label>
<button class="btn-primary" type="submit">Simpan Data</button></form>
<?php require __DIR__.'/../../includes/footer.php';?>