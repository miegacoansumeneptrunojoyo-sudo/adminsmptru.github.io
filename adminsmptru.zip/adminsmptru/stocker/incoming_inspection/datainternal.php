<?php
require_once __DIR__ . '/../../config/config.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../config/helpers.php';
function ensure_incoming_schema_data(mysqli $conn, string $table): void
{
    $q = $conn->query("SHOW COLUMNS FROM `" . $conn->real_escape_string($table) . "`");
    $c = [];
    if ($q) {
        while ($r = $q->fetch_assoc()) $c[$r['Field']] = 1;
        $q->free();
    }
    $defs = ['nama_resto' => "VARCHAR(180) DEFAULT 'Sumenep Trunojoyo'", 'nama_sm' => "VARCHAR(180) DEFAULT 'Alvin Zakaria'", 'alamat_produsen' => "VARCHAR(255) DEFAULT NULL", 'negara_produsen' => "VARCHAR(100) DEFAULT 'Indonesia'", 'prod_exp_date' => "VARCHAR(120) DEFAULT NULL", 'kode_halal' => "VARCHAR(10) DEFAULT NULL", 'kondisi_truk' => "VARCHAR(20) DEFAULT NULL", 'nama_penerima' => "VARCHAR(120) DEFAULT NULL", 'group_token' => "VARCHAR(64) DEFAULT NULL", 'jumlah_satuan' => "VARCHAR(120) DEFAULT NULL"];
    foreach ($defs as $n => $d) if (!isset($c[$n])) @$conn->query("ALTER TABLE `" . $conn->real_escape_string($table) . "` ADD COLUMN `" . $n . "` " . $d);
}
ensure_incoming_schema_data($conn, 'incoming_inspection_internal');
$today = date('Y-m-d');
$selectedDate = trim((string)($_GET['tanggal'] ?? $today));
if (!preg_match('/^\\d{{4}}-\\d{{2}}-\\d{{2}}$/', $selectedDate)) $selectedDate = $today;
$groups = [];
if (db_ready()) {
    $st = $conn->prepare("SELECT * FROM `incoming_inspection_internal` WHERE tanggal=? ORDER BY COALESCE(NULLIF(group_token,''),CONCAT('legacy-',id)) DESC,id ASC");
    if ($st) {
        $st->bind_param('s', $selectedDate);
        $st->execute();
        $res = $st->get_result();
        while ($r = $res->fetch_assoc()) {
            $g = $r['group_token'] ?? '';
            if ($g === '') $g = 'legacy-' . $r['id'];
            $groups[$g][] = $r;
        }
        $st->close();
    }
}
$pageTitle = 'Data Incoming Inspection Internal';
require __DIR__ . '/../../includes/header.php';
?>
<style>
    .incoming-top {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
        margin-bottom: 18px
    }

    .incoming-top h2 {
        margin: 0;
        color: #173a7a;
        font-size: 28px
    }

    .incoming-filter {
        margin-left: auto;
        display: flex;
        align-items: center;
        gap: 8px;
        flex-wrap: wrap
    }

    .incoming-filter label {
        font-size: 12px;
        font-weight: 800;
        color: #173a7a
    }

    .incoming-filter input {
        height: 42px;
        border: 1px solid #d7e1f2;
        border-radius: 11px;
        padding: 0 12px;
        color: #173a7a;
        font-weight: 700
    }

    .incoming-record {
        background: #fff;
        border: 1px solid #dfe7f2;
        border-radius: 18px;
        overflow: hidden;
        margin-bottom: 18px;
        box-shadow: 0 8px 24px rgba(30, 64, 175, .06)
    }

    .incoming-record-head {
        display: flex;
        justify-content: space-between;
        gap: 16px;
        padding: 18px 20px;
        background: linear-gradient(90deg, #f4f8ff, #fff7fb);
        border-bottom: 1px solid #e6edf7
    }

    .incoming-title {
        display: flex;
        gap: 12px;
        align-items: center
    }

    .incoming-icon {
        width: 42px;
        height: 42px;
        border-radius: 12px;
        background: linear-gradient(135deg, #eaf2ff, #fde8f3);
        display: grid;
        place-items: center
    }

    .incoming-title h3 {
        margin: 0;
        color: #173a7a;
        font-size: 18px
    }

    .incoming-meta {
        font-size: 13px;
        color: #64748b;
        margin-top: 4px
    }

    .incoming-body {
        padding: 18px 20px;
        overflow: auto
    }

    .incoming-table {
        width: 100%;
        min-width: 1500px;
        border-collapse: collapse
    }

    .incoming-table th {
        background: #f1f6ff;
        color: #173a7a;
        font-size: 12px;
        font-weight: 800;
        padding: 10px 8px;
        text-align: left;
        white-space: nowrap
    }

    .incoming-table td {
        padding: 9px 8px;
        border-bottom: 1px solid #edf1f7;
        font-size: 13px;
        color: #173a7a;
        font-weight: 600;
        vertical-align: top
    }

    .top-meta {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 10px;
        margin-bottom: 14px
    }

    .top-meta .box {
        border: 1px solid #e5ebf4;
        border-radius: 12px;
        padding: 10px 12px;
        background: #fbfdff
    }

    .top-meta .lab {
        font-size: 10px;
        color: #64748b;
        font-weight: 800;
        text-transform: uppercase;
        margin-bottom: 3px
    }

    .top-meta .val {
        color: #173a7a;
        font-weight: 800
    }

    .empty {
        padding: 48px;
        text-align: center;
        color: #64748b;
        background: #fff;
        border: 1px solid #dfe7f2;
        border-radius: 18px
    }

    .empty strong {
        display: block;
        color: #173a7a;
        font-size: 18px;
        margin-bottom: 6px
    }

    @media(max-width:900px) {
        .incoming-top {
            display: grid;
            grid-template-columns: 1fr
        }

        .incoming-filter {
            margin-left: 0
        }

        .top-meta {
            grid-template-columns: 1fr
        }

        .incoming-record-head {
            flex-direction: column;
            align-items: flex-start
        }
    }
</style>
<div class="page-head incoming-top">
    <div>
        <h2>Data Incoming Inspection Internal</h2>
    </div>
    <form method="get" class="incoming-filter"><a class="btn-action back" href="../../stocker.php">← Kembali</a><label for="tanggal"></label><input id="tanggal" type="date" name="tanggal" value="<?= e($selectedDate) ?>"><button class="btn-action primary" type="submit">Tampilkan</button><a class="btn-action primary" href="inputinternal.php?tanggal=<?= urlencode($selectedDate) ?>">＋ Input Data</a></form>
</div>
<?php if (!$groups): ?><div class="empty"><strong>Belum ada data</strong></div><?php else: foreach ($groups as $grows): $first = $grows[0]; ?>
        <section class="incoming-record">
            <div class="incoming-record-head">
                <div class="incoming-title">
                    <div class="incoming-icon">📋</div>
                    <div>
                        <h3>Data Incoming Inspection Internal — <?= e(date('d/m/Y', strtotime($first['tanggal']))) ?></h3>
                        <div class="incoming-meta">Nama Resto: <strong><?= e($first['nama_resto'] ?? 'Sumenep Trunojoyo') ?></strong> · Nama SM: <strong><?= e($first['nama_sm'] ?? 'Alvin Zakaria') ?></strong></div>
                    </div>
                </div>
                <div><a class="btn-action" href="editinternal.php?id=<?= e((string)$first['id']) ?>">✏️ Edit</a></div>
            </div>
            <div class="incoming-body">
                <div class="top-meta">
                    <div class="box">
                        <div class="lab">Tanggal</div>
                        <div class="val"><?= e(date('d/m/Y', strtotime($first['tanggal']))) ?></div>
                    </div>
                    <div class="box">
                        <div class="lab">Nama Resto</div>
                        <div class="val"><?= e($first['nama_resto'] ?? 'Sumenep Trunojoyo') ?></div>
                    </div>
                    <div class="box">
                        <div class="lab">Nama SM</div>
                        <div class="val"><?= e($first['nama_sm'] ?? 'Alvin Zakaria') ?></div>
                    </div>
                </div>
                <table class="incoming-table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Barang</th>
                            <th>Kode Lot</th>
                            <th>Nama Supp</th>
                            <th>Alamat Produsen</th>
                            <th>Negara Produsen</th>
                            <th>Jumlah &amp; Satuan</th>
                            <th>Prod/Exp Date</th>
                            <th>Kode Halal</th>
                            <th>Kondisi Truk</th>
                            <th>Nama Penerima</th>
                        </tr>
                    </thead>
                    <tbody><?php foreach ($grows as $ix => $r): ?><tr>
                                <td><?= e((string)($ix + 1)) ?></td>
                                <td><?= e($r['nama_barang']) ?></td>
                                <td><?= e($r['kode_lot'] ?: '-') ?></td>
                                <td><?= e($r['supplier'] ?: '-') ?></td>
                                <td><?= e($r['alamat_produsen'] ?: '-') ?></td>
                                <td><?= e($r['negara_produsen'] ?: 'Indonesia') ?></td>
                                <td><?= e($r['jumlah_satuan'] ?: $r['jumlah'] ?: '-') ?></td>
                                <td><?= e($r['prod_exp_date'] ?: '-') ?></td>
                                <td><?= e($r['kode_halal'] ?: '-') ?></td>
                                <td><?= e($r['kondisi_truk'] ?: $r['kondisi'] ?: '-') ?></td>
                                <td><?= e($r['nama_penerima'] ?: $r['pic'] ?: '-') ?></td>
                            </tr><?php endforeach; ?></tbody>
                </table>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:14px">
                    <div class="box" style="border:1px solid #e5ebf4;border-radius:12px;padding:12px;text-align:center">
                        <div class="lab" style="font-size:10px;color:#64748b;font-weight:800">DILAPORKAN OLEH</div>
                        <div class="val" style="color:#173a7a;font-weight:800"><?= e($first['nama_penerima'] ?? $first['pic'] ?? '—') ?></div>
                    </div>
                    <div class="box" style="border:1px solid #e5ebf4;border-radius:12px;padding:12px;text-align:center">
                        <div class="lab" style="font-size:10px;color:#64748b;font-weight:800">DISETUJUI OLEH</div>
                        <div class="val" style="color:#173a7a;font-weight:800">Alvin Zakaria</div>
                    </div>
                </div>
            </div>
        </section>
<?php endforeach;
                                                                                                                                                            endif; ?>
<?php require __DIR__ . '/../../includes/footer.php'; ?>