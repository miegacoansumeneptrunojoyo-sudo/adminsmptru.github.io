<?php
require_once __DIR__.'/../../config/config.php';
require_once __DIR__.'/../../config/database.php';
require_once __DIR__.'/../../config/helpers.php';
$id=(int)($_GET['id'] ?? $_POST['id'] ?? 0); $message=''; $error=''; $row=null;
if($id<=0){ http_response_code(400); exit('ID tidak valid.'); }
if(!db_ready()){ $error='Database belum terhubung: '.db_error_message(); } else {
  $st=$conn->prepare('SELECT * FROM `incoming_inspection_internal` WHERE id=?'); $st->bind_param('i',$id); $st->execute(); $res=$st->get_result(); $row=$res->fetch_assoc(); $st->close();
  if(!$row){ http_response_code(404); exit('Data tidak ditemukan.'); }
}
if($_SERVER['REQUEST_METHOD']==='POST' && !$error && db_ready()){
  $tanggal=(string)($_POST['tanggal'] ?? $row['tanggal'] ?? '');
  $pic=trim((string)($_POST['pic'] ?? $row['pic'] ?? ''));
  $supplier=trim((string)($_POST['supplier'] ?? $row['supplier'] ?? ''));
  $nama_barang=trim((string)($_POST['nama_barang'] ?? $row['nama_barang'] ?? ''));
  $kode_lot=trim((string)($_POST['kode_lot'] ?? $row['kode_lot'] ?? ''));
  $jumlah=trim((string)($_POST['jumlah'] ?? $row['jumlah'] ?? ''));
  $kondisi=trim((string)($_POST['kondisi'] ?? $row['kondisi'] ?? ''));
  $status=trim((string)($_POST['status'] ?? $row['status'] ?? ''));
  $catatan=trim((string)($_POST['catatan'] ?? $row['catatan'] ?? ''));
  $st=$conn->prepare('UPDATE `incoming_inspection_internal` SET `tanggal`=?, `pic`=?, `supplier`=?, `nama_barang`=?, `kode_lot`=?, `jumlah`=?, `kondisi`=?, `status`=?, `catatan`=? WHERE id=?');
  if($st){ $st->bind_param('sssssssssi', $tanggal, $pic, $supplier, $nama_barang, $kode_lot, $jumlah, $kondisi, $status, $catatan, $id); if($st->execute()){ $st->close(); redirect_to('datainternal.php'); } $error='Gagal memperbarui data: '.$st->error; $st->close(); } else $error='Query update gagal.';
}
$pageTitle='Incoming Inspection Internal'; require __DIR__.'/../../includes/header.php';
?>
<div class="page-head"><div><h2>Edit Incoming Inspection Internal</h2></div><div class="page-actions"><a class="btn-action back" href="datainternal.php">← Kembali</a></div></div>
<?php if($error): ?><div class="alert alert-error"><?=e($error)?></div><?php endif; ?>
<form method="post" class="panel form-grid"><input type="hidden" name="id" value="<?=e((string)$id)?>">
<label>Tanggal<input type="date" name="tanggal" value="<?=e($row['tanggal'] ?? '')?>" required></label>
<label>Nama PIC<input type="text" name="pic" value="<?=e($row['pic'] ?? '')?>" required></label>
<label>Supplier / Sumber<input type="text" name="supplier" value="<?=e($row['supplier'] ?? '')?>"></label>
<label>Nama Barang<input type="text" name="nama_barang" value="<?=e($row['nama_barang'] ?? '')?>" required></label>
<label>Kode Lot<input type="text" name="kode_lot" value="<?=e($row['kode_lot'] ?? '')?>"></label>
<label>Jumlah<input type="text" name="jumlah" value="<?=e($row['jumlah'] ?? '')?>"></label>
<label>Kondisi<input type="text" name="kondisi" value="<?=e($row['kondisi'] ?? '')?>"></label>
<label>Status<select name="status">
<option value="Sesuai" <?=((($row['status'] ?? "")==="Sesuai")?"selected":"")?>>Sesuai</option>
<option value="Tidak Sesuai" <?=((($row['status'] ?? "")==="Tidak Sesuai")?"selected":"")?>>Tidak Sesuai</option>
<option value="Perlu Tindak Lanjut" <?=((($row['status'] ?? "")==="Perlu Tindak Lanjut")?"selected":"")?>>Perlu Tindak Lanjut</option>
</select></label>
<label style="grid-column:1/-1">Catatan<textarea name="catatan"><?=e($row['catatan'] ?? '')?></textarea></label>
<div style="grid-column:1/-1;display:flex;gap:10px;justify-content:flex-end;margin-top:12px"><a class="btn-action back" href="datainternal.php">Batal</a><button class="btn-action primary" type="submit">Update Data</button></div>
</form>
<?php require __DIR__.'/../../includes/footer.php'; ?>