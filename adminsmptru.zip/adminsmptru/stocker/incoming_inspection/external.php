<?php $pageTitle='Incoming Inspection Eksternal'; require __DIR__.'/../../includes/header.php'; ?>
<div class="page-head"><div><h2>Incoming Inspection Eksternal</h2></div><div class="page-actions"><a class="btn-action back" href="../../stocker.php">← Kembali</a></div></div>
<section class="cards three">
  <a class="tile" href="dataexternal.php"><span class="tile-icon">📋</span><h3>Data Eksternal</h3><p>Lihat data incoming inspection eksternal.</p><span class="mini-arrow">›</span></a>
  <a class="tile" href="inputexternal.php"><span class="tile-icon">＋</span><h3>Input Eksternal</h3><p>Masukkan hasil pemeriksaan barang eksternal.</p><span class="mini-arrow">›</span></a>
</section>
<?php require __DIR__.'/../../includes/footer.php'; ?>
