<?php
require_once __DIR__.'/../../config/config.php';
require_once __DIR__.'/../../config/database.php';
require_once __DIR__.'/../../config/helpers.php';

function ensure_incoming_schema(mysqli $conn, string $table): void {
    $columns=[];
    $q=$conn->query("SHOW COLUMNS FROM `".$conn->real_escape_string($table)."`");
    if($q){while($c=$q->fetch_assoc())$columns[$c['Field']]=true;$q->free();}
    $defs=[
      'nama_resto'=>"VARCHAR(180) DEFAULT 'Sumenep Trunojoyo'",
      'nama_sm'=>"VARCHAR(180) DEFAULT 'Alvin Zakaria'",
      'alamat_produsen'=>"VARCHAR(255) DEFAULT NULL",
      'negara_produsen'=>"VARCHAR(100) DEFAULT 'Indonesia'",
      'prod_exp_date'=>"VARCHAR(120) DEFAULT NULL",
      'kode_halal'=>"VARCHAR(10) DEFAULT NULL",
      'kondisi_truk'=>"VARCHAR(20) DEFAULT NULL",
      'nama_penerima'=>"VARCHAR(120) DEFAULT NULL",
      'group_token'=>"VARCHAR(64) DEFAULT NULL",
      'jumlah_satuan'=>"VARCHAR(120) DEFAULT NULL"
    ];
    foreach($defs as $name=>$def){
      if(!isset($columns[$name])) @ $conn->query("ALTER TABLE `".$conn->real_escape_string($table)."` ADD COLUMN `".$name."` ".$def);
    }
}
ensure_incoming_schema($conn,'incoming_inspection_internal');
$message=''; $error='';
$tanggal=date('Y-m-d');
$nama_resto='Sumenep Trunojoyo';
$nama_sm='Alvin Zakaria';
if($_SERVER['REQUEST_METHOD']==='POST'){
  if(!db_ready()) $error='Database belum terhubung: '.db_error_message();
  else{
    $names=$_POST['nama_barang']??[]; $lots=$_POST['kode_lot']??[]; $supp=$_POST['nama_supp']??[]; $alamat=$_POST['alamat_produsen']??[]; $jumlah=$_POST['jumlah_satuan']??[]; $prodexp=$_POST['prod_exp_date']??[]; $halal=$_POST['kode_halal']??[]; $kondisi=$_POST['kondisi_truk']??[]; $penerima=$_POST['nama_penerima']??[];
    $token=bin2hex(random_bytes(16));
    $st=$conn->prepare("INSERT INTO `incoming_inspection_internal` (tanggal,nama_resto,nama_sm,pic,supplier,nama_barang,kode_lot,jumlah,kondisi,status,catatan,alamat_produsen,negara_produsen,prod_exp_date,kode_halal,kondisi_truk,nama_penerima,group_token,jumlah_satuan) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
    if(!$st) $error='Query simpan gagal: '.$conn->error;
    else{
      $conn->begin_transaction(); $count=0;
      try{
        for($i=1;$i<=31;$i++){
          $barang=trim((string)($names[$i]??'')); $lot=trim((string)($lots[$i]??'')); $sp=trim((string)($supp[$i]??'')); $al=trim((string)($alamat[$i]??'')); $j=trim((string)($jumlah[$i]??'')); $pe=trim((string)($prodexp[$i]??'')); $kh=trim((string)($halal[$i]??'')); $kt=trim((string)($kondisi[$i]??'')); $np=trim((string)($penerima[$i]??''));
          if($barang==='' && $lot==='' && $sp==='' && $al==='' && $j==='' && $pe==='' && $kh==='' && $kt==='' && $np==='') continue;
          $pic=$np; $supplier=$sp; $kond=$kt; $status=$kh; $cat=''; $neg='Indonesia';
          $st->bind_param('sssssssssssssssssss',$tanggal,$nama_resto,$nama_sm,$pic,$supplier,$barang,$lot,$j,$kond,$status,$cat,$al,$neg,$pe,$kh,$kt,$np,$token,$j);
          if(!$st->execute()) throw new Exception($st->error); $count++;
        }
        $conn->commit(); $st->close();
        $message=$count>0?'Data berhasil disimpan.':'Isi minimal satu baris data barang.';
      }catch(Throwable $ex){$conn->rollback();$st->close();$error='Data gagal disimpan: '.$ex->getMessage();}
    }
  }
}
$pageTitle='Input Incoming Inspection Internal'; require __DIR__.'/../../includes/header.php';
?>

<style>
.incoming-form-page .panel{padding:20px}
.incoming-head{display:flex;justify-content:space-between;align-items:center;gap:14px;margin-bottom:18px;flex-wrap:wrap}
.incoming-head h2{margin:0;color:#173a7a;font-size:28px}
.incoming-meta{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-bottom:18px}
.incoming-meta .meta-box{background:#fff;border:1px solid #dfe7f2;border-radius:14px;padding:13px 14px}
.incoming-meta label,.field-label{display:block;font-size:12px;font-weight:800;color:#64748b;margin-bottom:6px}
.incoming-meta input{width:100%;height:44px;border:1px solid #d7e1f2;border-radius:11px;padding:0 12px;box-sizing:border-box;color:#173a7a;font-weight:700;background:#f8fbff}
.incoming-meta input[readonly]{cursor:not-allowed}
.incoming-table-wrap{overflow-x:auto;border:1px solid #dfe7f2;border-radius:16px;background:#fff}
.incoming-table{width:100%;min-width:1550px;border-collapse:collapse}
.incoming-table th{background:#f1f6ff;color:#173a7a;font-size:12px;font-weight:800;padding:11px 9px;border-bottom:1px solid #dfe7f2;text-align:left;white-space:nowrap}
.incoming-table td{padding:8px 8px;border-bottom:1px solid #edf1f7;vertical-align:top}
.incoming-table td.no{width:45px;text-align:center;color:#173a7a;font-weight:700}
.incoming-table .nama-barang-input{background:#fff!important;color:#173a7a!important;cursor:text!important;pointer-events:auto!important;user-select:text!important}.incoming-table .nama-barang-input:focus{outline:none;border-color:#5c84ff;box-shadow:0 0 0 3px rgba(59,130,246,.1)}
.incoming-table input,.incoming-table select{width:100%;height:40px;border:1px solid #d7e1f2;border-radius:9px;padding:0 9px;box-sizing:border-box;font:600 13px inherit;color:#173a7a;background:#fff;min-width:100px}
.incoming-table input[readonly]{background:#f6f9fd;color:#64748b}
.incoming-table select{cursor:pointer}
.incoming-sign{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:18px}
.signature-box{border:1px solid #dfe7f2;border-radius:14px;overflow:hidden;background:#fff}
.signature-box .sig-head{padding:10px;background:#f1f6ff;font-size:12px;font-weight:800;color:#173a7a;text-align:center}
.signature-box .sig-body{min-height:90px;display:flex;align-items:flex-end;justify-content:center;padding:12px;font-weight:800;color:#173a7a}
.incoming-actions{display:flex;gap:10px;justify-content:flex-end;margin-top:20px;padding-top:18px;border-top:1px solid #edf1f7}
.notice{margin-bottom:14px;padding:12px 14px;border-radius:12px;background:#eef5ff;color:#1d4ed8;border:1px solid #d5e6ff;font-size:13px}
@media(max-width:900px){.incoming-meta{grid-template-columns:1fr}.incoming-head h2{font-size:24px}.incoming-actions{justify-content:stretch;display:grid;grid-template-columns:1fr 1fr}.incoming-actions a,.incoming-actions button{width:100%}.incoming-sign{grid-template-columns:1fr}}
</style>

<div class="page-head incoming-head"><div><h2>Input Incoming Inspection Internal</h2></div><div class="page-actions"><a class="btn-action back" href="../../stocker/incoming_inspection/datainternal.php">← Kembali</a></div></div>
<?php if($message): ?><div class="alert alert-success"><?=e($message)?></div><?php endif; ?>
<?php if($error): ?><div class="alert alert-error"><?=e($error)?></div><?php endif; ?>
<form method="post" class="panel incoming-form-page">
  <div class="notice">Tanggal otomatis hari ini. Nama Resto, Nama SM, dan Negara Produsen tidak dapat diubah.</div>
  <div class="incoming-meta">
    <div class="meta-box"><label>Tanggal</label><input type="date" value="<?=e($tanggal)?>" readonly></div>
    <div class="meta-box"><label>Nama Resto</label><input type="text" value="Sumenep Trunojoyo" readonly></div>
    <div class="meta-box"><label>Nama SM</label><input type="text" value="Alvin Zakaria" readonly></div>
  </div>
  <div class="incoming-table-wrap">
    <table class="incoming-table"><thead><tr><th>No</th><th>Nama Barang</th><th>Kode Lot</th><th>Nama Supp</th><th>Alamat Produsen</th><th>Negara Produsen</th><th>Jumlah &amp; Satuan Barang</th><th>Prod/Exp Date</th><th>Kode Halal<br>(AC/UN)</th><th>Kondisi Truk</th><th>Nama Penerima</th></tr></thead>
    <tbody><tr>
<td class="no">1</td>
<td><input class="nama-barang-input" name="nama_barang[1]" value="<?=e($_POST['nama_barang'][1]??'')?>"></td>
<td><input name="kode_lot[1]" value="<?=e($_POST['kode_lot'][1]??'')?>"></td>
<td><input name="nama_supp[1]" value="<?=e($_POST['nama_supp'][1]??'')?>"></td>
<td><input name="alamat_produsen[1]" value="<?=e($_POST['alamat_produsen'][1]??'')?>"></td>
<td><input name="negara_produsen[1]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[1]" value="<?=e($_POST['jumlah_satuan'][1]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[1]" value="<?=e($_POST['prod_exp_date'][1]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[1]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][1]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][1]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[1]" value="<?=e($_POST['kondisi_truk'][1]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[1]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][1]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][1]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">2</td>
<td><input class="nama-barang-input" name="nama_barang[2]" value="<?=e($_POST['nama_barang'][2]??'')?>"></td>
<td><input name="kode_lot[2]" value="<?=e($_POST['kode_lot'][2]??'')?>"></td>
<td><input name="nama_supp[2]" value="<?=e($_POST['nama_supp'][2]??'')?>"></td>
<td><input name="alamat_produsen[2]" value="<?=e($_POST['alamat_produsen'][2]??'')?>"></td>
<td><input name="negara_produsen[2]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[2]" value="<?=e($_POST['jumlah_satuan'][2]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[2]" value="<?=e($_POST['prod_exp_date'][2]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[2]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][2]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][2]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[2]" value="<?=e($_POST['kondisi_truk'][2]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[2]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][2]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][2]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">3</td>
<td><input class="nama-barang-input" name="nama_barang[3]" value="<?=e($_POST['nama_barang'][3]??'')?>"></td>
<td><input name="kode_lot[3]" value="<?=e($_POST['kode_lot'][3]??'')?>"></td>
<td><input name="nama_supp[3]" value="<?=e($_POST['nama_supp'][3]??'')?>"></td>
<td><input name="alamat_produsen[3]" value="<?=e($_POST['alamat_produsen'][3]??'')?>"></td>
<td><input name="negara_produsen[3]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[3]" value="<?=e($_POST['jumlah_satuan'][3]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[3]" value="<?=e($_POST['prod_exp_date'][3]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[3]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][3]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][3]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[3]" value="<?=e($_POST['kondisi_truk'][3]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[3]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][3]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][3]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">4</td>
<td><input class="nama-barang-input" name="nama_barang[4]" value="<?=e($_POST['nama_barang'][4]??'')?>"></td>
<td><input name="kode_lot[4]" value="<?=e($_POST['kode_lot'][4]??'')?>"></td>
<td><input name="nama_supp[4]" value="<?=e($_POST['nama_supp'][4]??'')?>"></td>
<td><input name="alamat_produsen[4]" value="<?=e($_POST['alamat_produsen'][4]??'')?>"></td>
<td><input name="negara_produsen[4]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[4]" value="<?=e($_POST['jumlah_satuan'][4]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[4]" value="<?=e($_POST['prod_exp_date'][4]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[4]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][4]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][4]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[4]" value="<?=e($_POST['kondisi_truk'][4]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[4]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][4]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][4]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">5</td>
<td><input class="nama-barang-input" name="nama_barang[5]" value="<?=e($_POST['nama_barang'][5]??'')?>"></td>
<td><input name="kode_lot[5]" value="<?=e($_POST['kode_lot'][5]??'')?>"></td>
<td><input name="nama_supp[5]" value="<?=e($_POST['nama_supp'][5]??'')?>"></td>
<td><input name="alamat_produsen[5]" value="<?=e($_POST['alamat_produsen'][5]??'')?>"></td>
<td><input name="negara_produsen[5]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[5]" value="<?=e($_POST['jumlah_satuan'][5]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[5]" value="<?=e($_POST['prod_exp_date'][5]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[5]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][5]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][5]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[5]" value="<?=e($_POST['kondisi_truk'][5]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[5]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][5]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][5]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">6</td>
<td><input class="nama-barang-input" name="nama_barang[6]" value="<?=e($_POST['nama_barang'][6]??'')?>"></td>
<td><input name="kode_lot[6]" value="<?=e($_POST['kode_lot'][6]??'')?>"></td>
<td><input name="nama_supp[6]" value="<?=e($_POST['nama_supp'][6]??'')?>"></td>
<td><input name="alamat_produsen[6]" value="<?=e($_POST['alamat_produsen'][6]??'')?>"></td>
<td><input name="negara_produsen[6]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[6]" value="<?=e($_POST['jumlah_satuan'][6]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[6]" value="<?=e($_POST['prod_exp_date'][6]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[6]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][6]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][6]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[6]" value="<?=e($_POST['kondisi_truk'][6]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[6]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][6]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][6]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">7</td>
<td><input class="nama-barang-input" name="nama_barang[7]" value="<?=e($_POST['nama_barang'][7]??'')?>"></td>
<td><input name="kode_lot[7]" value="<?=e($_POST['kode_lot'][7]??'')?>"></td>
<td><input name="nama_supp[7]" value="<?=e($_POST['nama_supp'][7]??'')?>"></td>
<td><input name="alamat_produsen[7]" value="<?=e($_POST['alamat_produsen'][7]??'')?>"></td>
<td><input name="negara_produsen[7]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[7]" value="<?=e($_POST['jumlah_satuan'][7]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[7]" value="<?=e($_POST['prod_exp_date'][7]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[7]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][7]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][7]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[7]" value="<?=e($_POST['kondisi_truk'][7]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[7]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][7]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][7]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">8</td>
<td><input class="nama-barang-input" name="nama_barang[8]" value="<?=e($_POST['nama_barang'][8]??'')?>"></td>
<td><input name="kode_lot[8]" value="<?=e($_POST['kode_lot'][8]??'')?>"></td>
<td><input name="nama_supp[8]" value="<?=e($_POST['nama_supp'][8]??'')?>"></td>
<td><input name="alamat_produsen[8]" value="<?=e($_POST['alamat_produsen'][8]??'')?>"></td>
<td><input name="negara_produsen[8]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[8]" value="<?=e($_POST['jumlah_satuan'][8]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[8]" value="<?=e($_POST['prod_exp_date'][8]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[8]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][8]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][8]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[8]" value="<?=e($_POST['kondisi_truk'][8]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[8]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][8]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][8]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">9</td>
<td><input class="nama-barang-input" name="nama_barang[9]" value="<?=e($_POST['nama_barang'][9]??'')?>"></td>
<td><input name="kode_lot[9]" value="<?=e($_POST['kode_lot'][9]??'')?>"></td>
<td><input name="nama_supp[9]" value="<?=e($_POST['nama_supp'][9]??'')?>"></td>
<td><input name="alamat_produsen[9]" value="<?=e($_POST['alamat_produsen'][9]??'')?>"></td>
<td><input name="negara_produsen[9]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[9]" value="<?=e($_POST['jumlah_satuan'][9]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[9]" value="<?=e($_POST['prod_exp_date'][9]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[9]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][9]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][9]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[9]" value="<?=e($_POST['kondisi_truk'][9]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[9]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][9]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][9]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">10</td>
<td><input class="nama-barang-input" name="nama_barang[10]" value="<?=e($_POST['nama_barang'][10]??'')?>"></td>
<td><input name="kode_lot[10]" value="<?=e($_POST['kode_lot'][10]??'')?>"></td>
<td><input name="nama_supp[10]" value="<?=e($_POST['nama_supp'][10]??'')?>"></td>
<td><input name="alamat_produsen[10]" value="<?=e($_POST['alamat_produsen'][10]??'')?>"></td>
<td><input name="negara_produsen[10]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[10]" value="<?=e($_POST['jumlah_satuan'][10]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[10]" value="<?=e($_POST['prod_exp_date'][10]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[10]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][10]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][10]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[10]" value="<?=e($_POST['kondisi_truk'][10]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[10]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][10]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][10]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">11</td>
<td><input class="nama-barang-input" name="nama_barang[11]" value="<?=e($_POST['nama_barang'][11]??'')?>"></td>
<td><input name="kode_lot[11]" value="<?=e($_POST['kode_lot'][11]??'')?>"></td>
<td><input name="nama_supp[11]" value="<?=e($_POST['nama_supp'][11]??'')?>"></td>
<td><input name="alamat_produsen[11]" value="<?=e($_POST['alamat_produsen'][11]??'')?>"></td>
<td><input name="negara_produsen[11]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[11]" value="<?=e($_POST['jumlah_satuan'][11]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[11]" value="<?=e($_POST['prod_exp_date'][11]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[11]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][11]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][11]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[11]" value="<?=e($_POST['kondisi_truk'][11]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[11]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][11]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][11]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">12</td>
<td><input class="nama-barang-input" name="nama_barang[12]" value="<?=e($_POST['nama_barang'][12]??'')?>"></td>
<td><input name="kode_lot[12]" value="<?=e($_POST['kode_lot'][12]??'')?>"></td>
<td><input name="nama_supp[12]" value="<?=e($_POST['nama_supp'][12]??'')?>"></td>
<td><input name="alamat_produsen[12]" value="<?=e($_POST['alamat_produsen'][12]??'')?>"></td>
<td><input name="negara_produsen[12]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[12]" value="<?=e($_POST['jumlah_satuan'][12]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[12]" value="<?=e($_POST['prod_exp_date'][12]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[12]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][12]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][12]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[12]" value="<?=e($_POST['kondisi_truk'][12]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[12]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][12]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][12]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">13</td>
<td><input class="nama-barang-input" name="nama_barang[13]" value="<?=e($_POST['nama_barang'][13]??'')?>"></td>
<td><input name="kode_lot[13]" value="<?=e($_POST['kode_lot'][13]??'')?>"></td>
<td><input name="nama_supp[13]" value="<?=e($_POST['nama_supp'][13]??'')?>"></td>
<td><input name="alamat_produsen[13]" value="<?=e($_POST['alamat_produsen'][13]??'')?>"></td>
<td><input name="negara_produsen[13]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[13]" value="<?=e($_POST['jumlah_satuan'][13]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[13]" value="<?=e($_POST['prod_exp_date'][13]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[13]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][13]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][13]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[13]" value="<?=e($_POST['kondisi_truk'][13]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[13]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][13]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][13]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">14</td>
<td><input class="nama-barang-input" name="nama_barang[14]" value="<?=e($_POST['nama_barang'][14]??'')?>"></td>
<td><input name="kode_lot[14]" value="<?=e($_POST['kode_lot'][14]??'')?>"></td>
<td><input name="nama_supp[14]" value="<?=e($_POST['nama_supp'][14]??'')?>"></td>
<td><input name="alamat_produsen[14]" value="<?=e($_POST['alamat_produsen'][14]??'')?>"></td>
<td><input name="negara_produsen[14]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[14]" value="<?=e($_POST['jumlah_satuan'][14]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[14]" value="<?=e($_POST['prod_exp_date'][14]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[14]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][14]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][14]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[14]" value="<?=e($_POST['kondisi_truk'][14]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[14]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][14]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][14]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">15</td>
<td><input class="nama-barang-input" name="nama_barang[15]" value="<?=e($_POST['nama_barang'][15]??'')?>"></td>
<td><input name="kode_lot[15]" value="<?=e($_POST['kode_lot'][15]??'')?>"></td>
<td><input name="nama_supp[15]" value="<?=e($_POST['nama_supp'][15]??'')?>"></td>
<td><input name="alamat_produsen[15]" value="<?=e($_POST['alamat_produsen'][15]??'')?>"></td>
<td><input name="negara_produsen[15]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[15]" value="<?=e($_POST['jumlah_satuan'][15]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[15]" value="<?=e($_POST['prod_exp_date'][15]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[15]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][15]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][15]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[15]" value="<?=e($_POST['kondisi_truk'][15]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[15]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][15]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][15]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">16</td>
<td><input class="nama-barang-input" name="nama_barang[16]" value="<?=e($_POST['nama_barang'][16]??'')?>"></td>
<td><input name="kode_lot[16]" value="<?=e($_POST['kode_lot'][16]??'')?>"></td>
<td><input name="nama_supp[16]" value="<?=e($_POST['nama_supp'][16]??'')?>"></td>
<td><input name="alamat_produsen[16]" value="<?=e($_POST['alamat_produsen'][16]??'')?>"></td>
<td><input name="negara_produsen[16]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[16]" value="<?=e($_POST['jumlah_satuan'][16]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[16]" value="<?=e($_POST['prod_exp_date'][16]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[16]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][16]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][16]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[16]" value="<?=e($_POST['kondisi_truk'][16]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[16]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][16]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][16]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">17</td>
<td><input class="nama-barang-input" name="nama_barang[17]" value="<?=e($_POST['nama_barang'][17]??'')?>"></td>
<td><input name="kode_lot[17]" value="<?=e($_POST['kode_lot'][17]??'')?>"></td>
<td><input name="nama_supp[17]" value="<?=e($_POST['nama_supp'][17]??'')?>"></td>
<td><input name="alamat_produsen[17]" value="<?=e($_POST['alamat_produsen'][17]??'')?>"></td>
<td><input name="negara_produsen[17]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[17]" value="<?=e($_POST['jumlah_satuan'][17]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[17]" value="<?=e($_POST['prod_exp_date'][17]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[17]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][17]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][17]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[17]" value="<?=e($_POST['kondisi_truk'][17]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[17]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][17]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][17]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">18</td>
<td><input class="nama-barang-input" name="nama_barang[18]" value="<?=e($_POST['nama_barang'][18]??'')?>"></td>
<td><input name="kode_lot[18]" value="<?=e($_POST['kode_lot'][18]??'')?>"></td>
<td><input name="nama_supp[18]" value="<?=e($_POST['nama_supp'][18]??'')?>"></td>
<td><input name="alamat_produsen[18]" value="<?=e($_POST['alamat_produsen'][18]??'')?>"></td>
<td><input name="negara_produsen[18]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[18]" value="<?=e($_POST['jumlah_satuan'][18]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[18]" value="<?=e($_POST['prod_exp_date'][18]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[18]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][18]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][18]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[18]" value="<?=e($_POST['kondisi_truk'][18]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[18]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][18]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][18]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">19</td>
<td><input class="nama-barang-input" name="nama_barang[19]" value="<?=e($_POST['nama_barang'][19]??'')?>"></td>
<td><input name="kode_lot[19]" value="<?=e($_POST['kode_lot'][19]??'')?>"></td>
<td><input name="nama_supp[19]" value="<?=e($_POST['nama_supp'][19]??'')?>"></td>
<td><input name="alamat_produsen[19]" value="<?=e($_POST['alamat_produsen'][19]??'')?>"></td>
<td><input name="negara_produsen[19]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[19]" value="<?=e($_POST['jumlah_satuan'][19]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[19]" value="<?=e($_POST['prod_exp_date'][19]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[19]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][19]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][19]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[19]" value="<?=e($_POST['kondisi_truk'][19]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[19]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][19]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][19]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">20</td>
<td><input class="nama-barang-input" name="nama_barang[20]" value="<?=e($_POST['nama_barang'][20]??'')?>"></td>
<td><input name="kode_lot[20]" value="<?=e($_POST['kode_lot'][20]??'')?>"></td>
<td><input name="nama_supp[20]" value="<?=e($_POST['nama_supp'][20]??'')?>"></td>
<td><input name="alamat_produsen[20]" value="<?=e($_POST['alamat_produsen'][20]??'')?>"></td>
<td><input name="negara_produsen[20]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[20]" value="<?=e($_POST['jumlah_satuan'][20]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[20]" value="<?=e($_POST['prod_exp_date'][20]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[20]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][20]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][20]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[20]" value="<?=e($_POST['kondisi_truk'][20]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[20]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][20]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][20]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">21</td>
<td><input class="nama-barang-input" name="nama_barang[21]" value="<?=e($_POST['nama_barang'][21]??'')?>"></td>
<td><input name="kode_lot[21]" value="<?=e($_POST['kode_lot'][21]??'')?>"></td>
<td><input name="nama_supp[21]" value="<?=e($_POST['nama_supp'][21]??'')?>"></td>
<td><input name="alamat_produsen[21]" value="<?=e($_POST['alamat_produsen'][21]??'')?>"></td>
<td><input name="negara_produsen[21]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[21]" value="<?=e($_POST['jumlah_satuan'][21]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[21]" value="<?=e($_POST['prod_exp_date'][21]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[21]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][21]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][21]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[21]" value="<?=e($_POST['kondisi_truk'][21]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[21]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][21]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][21]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">22</td>
<td><input class="nama-barang-input" name="nama_barang[22]" value="<?=e($_POST['nama_barang'][22]??'')?>"></td>
<td><input name="kode_lot[22]" value="<?=e($_POST['kode_lot'][22]??'')?>"></td>
<td><input name="nama_supp[22]" value="<?=e($_POST['nama_supp'][22]??'')?>"></td>
<td><input name="alamat_produsen[22]" value="<?=e($_POST['alamat_produsen'][22]??'')?>"></td>
<td><input name="negara_produsen[22]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[22]" value="<?=e($_POST['jumlah_satuan'][22]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[22]" value="<?=e($_POST['prod_exp_date'][22]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[22]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][22]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][22]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[22]" value="<?=e($_POST['kondisi_truk'][22]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[22]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][22]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][22]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">23</td>
<td><input class="nama-barang-input" name="nama_barang[23]" value="<?=e($_POST['nama_barang'][23]??'')?>"></td>
<td><input name="kode_lot[23]" value="<?=e($_POST['kode_lot'][23]??'')?>"></td>
<td><input name="nama_supp[23]" value="<?=e($_POST['nama_supp'][23]??'')?>"></td>
<td><input name="alamat_produsen[23]" value="<?=e($_POST['alamat_produsen'][23]??'')?>"></td>
<td><input name="negara_produsen[23]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[23]" value="<?=e($_POST['jumlah_satuan'][23]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[23]" value="<?=e($_POST['prod_exp_date'][23]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[23]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][23]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][23]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[23]" value="<?=e($_POST['kondisi_truk'][23]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[23]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][23]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][23]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">24</td>
<td><input class="nama-barang-input" name="nama_barang[24]" value="<?=e($_POST['nama_barang'][24]??'')?>"></td>
<td><input name="kode_lot[24]" value="<?=e($_POST['kode_lot'][24]??'')?>"></td>
<td><input name="nama_supp[24]" value="<?=e($_POST['nama_supp'][24]??'')?>"></td>
<td><input name="alamat_produsen[24]" value="<?=e($_POST['alamat_produsen'][24]??'')?>"></td>
<td><input name="negara_produsen[24]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[24]" value="<?=e($_POST['jumlah_satuan'][24]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[24]" value="<?=e($_POST['prod_exp_date'][24]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[24]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][24]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][24]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[24]" value="<?=e($_POST['kondisi_truk'][24]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[24]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][24]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][24]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">25</td>
<td><input class="nama-barang-input" name="nama_barang[25]" value="<?=e($_POST['nama_barang'][25]??'')?>"></td>
<td><input name="kode_lot[25]" value="<?=e($_POST['kode_lot'][25]??'')?>"></td>
<td><input name="nama_supp[25]" value="<?=e($_POST['nama_supp'][25]??'')?>"></td>
<td><input name="alamat_produsen[25]" value="<?=e($_POST['alamat_produsen'][25]??'')?>"></td>
<td><input name="negara_produsen[25]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[25]" value="<?=e($_POST['jumlah_satuan'][25]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[25]" value="<?=e($_POST['prod_exp_date'][25]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[25]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][25]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][25]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[25]" value="<?=e($_POST['kondisi_truk'][25]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[25]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][25]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][25]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">26</td>
<td><input class="nama-barang-input" name="nama_barang[26]" value="<?=e($_POST['nama_barang'][26]??'')?>"></td>
<td><input name="kode_lot[26]" value="<?=e($_POST['kode_lot'][26]??'')?>"></td>
<td><input name="nama_supp[26]" value="<?=e($_POST['nama_supp'][26]??'')?>"></td>
<td><input name="alamat_produsen[26]" value="<?=e($_POST['alamat_produsen'][26]??'')?>"></td>
<td><input name="negara_produsen[26]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[26]" value="<?=e($_POST['jumlah_satuan'][26]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[26]" value="<?=e($_POST['prod_exp_date'][26]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[26]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][26]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][26]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[26]" value="<?=e($_POST['kondisi_truk'][26]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[26]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][26]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][26]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">27</td>
<td><input class="nama-barang-input" name="nama_barang[27]" value="<?=e($_POST['nama_barang'][27]??'')?>"></td>
<td><input name="kode_lot[27]" value="<?=e($_POST['kode_lot'][27]??'')?>"></td>
<td><input name="nama_supp[27]" value="<?=e($_POST['nama_supp'][27]??'')?>"></td>
<td><input name="alamat_produsen[27]" value="<?=e($_POST['alamat_produsen'][27]??'')?>"></td>
<td><input name="negara_produsen[27]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[27]" value="<?=e($_POST['jumlah_satuan'][27]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[27]" value="<?=e($_POST['prod_exp_date'][27]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[27]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][27]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][27]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[27]" value="<?=e($_POST['kondisi_truk'][27]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[27]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][27]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][27]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">28</td>
<td><input class="nama-barang-input" name="nama_barang[28]" value="<?=e($_POST['nama_barang'][28]??'')?>"></td>
<td><input name="kode_lot[28]" value="<?=e($_POST['kode_lot'][28]??'')?>"></td>
<td><input name="nama_supp[28]" value="<?=e($_POST['nama_supp'][28]??'')?>"></td>
<td><input name="alamat_produsen[28]" value="<?=e($_POST['alamat_produsen'][28]??'')?>"></td>
<td><input name="negara_produsen[28]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[28]" value="<?=e($_POST['jumlah_satuan'][28]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[28]" value="<?=e($_POST['prod_exp_date'][28]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[28]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][28]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][28]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[28]" value="<?=e($_POST['kondisi_truk'][28]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[28]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][28]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][28]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">29</td>
<td><input class="nama-barang-input" name="nama_barang[29]" value="<?=e($_POST['nama_barang'][29]??'')?>"></td>
<td><input name="kode_lot[29]" value="<?=e($_POST['kode_lot'][29]??'')?>"></td>
<td><input name="nama_supp[29]" value="<?=e($_POST['nama_supp'][29]??'')?>"></td>
<td><input name="alamat_produsen[29]" value="<?=e($_POST['alamat_produsen'][29]??'')?>"></td>
<td><input name="negara_produsen[29]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[29]" value="<?=e($_POST['jumlah_satuan'][29]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[29]" value="<?=e($_POST['prod_exp_date'][29]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[29]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][29]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][29]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[29]" value="<?=e($_POST['kondisi_truk'][29]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[29]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][29]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][29]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">30</td>
<td><input class="nama-barang-input" name="nama_barang[30]" value="<?=e($_POST['nama_barang'][30]??'')?>"></td>
<td><input name="kode_lot[30]" value="<?=e($_POST['kode_lot'][30]??'')?>"></td>
<td><input name="nama_supp[30]" value="<?=e($_POST['nama_supp'][30]??'')?>"></td>
<td><input name="alamat_produsen[30]" value="<?=e($_POST['alamat_produsen'][30]??'')?>"></td>
<td><input name="negara_produsen[30]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[30]" value="<?=e($_POST['jumlah_satuan'][30]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[30]" value="<?=e($_POST['prod_exp_date'][30]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[30]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][30]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][30]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[30]" value="<?=e($_POST['kondisi_truk'][30]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[30]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][30]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][30]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr>
<tr>
<td class="no">31</td>
<td><input class="nama-barang-input" name="nama_barang[31]" value="<?=e($_POST['nama_barang'][31]??'')?>"></td>
<td><input name="kode_lot[31]" value="<?=e($_POST['kode_lot'][31]??'')?>"></td>
<td><input name="nama_supp[31]" value="<?=e($_POST['nama_supp'][31]??'')?>"></td>
<td><input name="alamat_produsen[31]" value="<?=e($_POST['alamat_produsen'][31]??'')?>"></td>
<td><input name="negara_produsen[31]" value="Indonesia" readonly></td>
<td><input name="jumlah_satuan[31]" value="<?=e($_POST['jumlah_satuan'][31]??'')?>" placeholder="Contoh: 1 pack"></td>
<td><input name="prod_exp_date[31]" value="<?=e($_POST['prod_exp_date'][31]??'')?>" placeholder="Prod / Exp"></td>
<td><select name="kode_halal[31]"><option value="">Pilih</option><option value="AC" <?=((($_POST['kode_halal'][31]??'')==='AC')?'selected':'')?>>AC</option><option value="UN" <?=((($_POST['kode_halal'][31]??'')==='UN')?'selected':'')?>>UN</option></select></td>
<td><input name="kondisi_truk[31]" value="<?=e($_POST['kondisi_truk'][31]??'')?>" placeholder="AC / UN"></td>
<td><select name="nama_penerima[31]"><option value="">Pilih</option><option value="Arjuna" <?=((($_POST['nama_penerima'][31]??'')==='Arjuna')?'selected':'')?>>Arjuna</option><option value="Kafi" <?=((($_POST['nama_penerima'][31]??'')==='Kafi')?'selected':'')?>>Kafi</option></select></td>
</tr></tbody></table>
  </div>
  <div class="incoming-sign"><div class="signature-box"><div class="sig-head">DILAPORKAN OLEH</div><div class="sig-body">Nama Penerima</div></div><div class="signature-box"><div class="sig-head">DISETUJUI OLEH</div><div class="sig-body">Alvin Zakaria</div></div></div>
  <div class="incoming-actions"><a class="btn-action back" href="internal.php">Kembali</a><button class="btn-action primary" type="submit">Simpan Data</button></div>
</form>
<?php require __DIR__.'/../../includes/footer.php'; ?>