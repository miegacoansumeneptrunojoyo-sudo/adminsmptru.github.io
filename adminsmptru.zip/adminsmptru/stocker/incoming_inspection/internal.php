<?php $pageTitle='Incoming Inspection Internal'; require __DIR__.'/../../includes/header.php'; ?>
<div class="page-head"><div><h2>Incoming Inspection Internal</h2></div><div class="page-actions"><a class="btn-action back" href="../../stocker.php">← Kembali</a></div></div>
<section class="cards three">
  <a class="tile" href="datainternal.php"><span class="tile-icon">📋</span><h3>Data Internal</h3><p>Lihat data incoming inspection internal.</p><span class="mini-arrow">›</span></a>
  <a class="tile" href="inputinternal.php"><span class="tile-icon">📋</span><h3>Input Internal</h3><p>Masukkan hasil pemeriksaan barang internal.</p><span class="mini-arrow">›</span></a>
</section>
<?php require __DIR__.'/../../includes/footer.php'; ?>
