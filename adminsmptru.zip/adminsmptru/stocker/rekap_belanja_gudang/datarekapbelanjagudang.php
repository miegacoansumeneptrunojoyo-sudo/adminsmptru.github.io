<?php
$pageTitle = 'Rekap Belanja Gudang';
require __DIR__ . '/../../config/database.php';
require __DIR__ . '/../../config/helpers.php';

$rows = [];
$notice = isset($_GET['saved']) && $_GET['saved'] === '1';

// Filter data berdasarkan tanggal dan jenis belanja.
$filterTanggal = trim((string)($_GET['tanggal'] ?? ''));
$filterJenis = trim((string)($_GET['jenis_belanja'] ?? ''));
if (!in_array($filterJenis, ['', 'Dry', 'Frozen'], true)) {
    $filterJenis = '';
}

if (db_ready()) {
    $where = [];
    $params = [];
    $types = '';

    if ($filterTanggal !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $filterTanggal)) {
        $where[] = 'tanggal = ?';
        $params[] = $filterTanggal;
        $types .= 's';
    } else {
        $filterTanggal = '';
    }

    if ($filterJenis !== '') {
        $where[] = 'jenis_belanja = ?';
        $params[] = $filterJenis;
        $types .= 's';
    }

    $sql = 'SELECT id, tanggal, jenis_belanja, nama_bahan, kode_lot, jam_keluar, jumlah, nama_pic, keterangan
            FROM rekap_belanja_gudang';
    if ($where) {
        $sql .= ' WHERE ' . implode(' AND ', $where);
    }
    $sql .= ' ORDER BY tanggal DESC, jam_keluar DESC, id DESC';

    $stmt = $conn->prepare($sql);
    if ($stmt) {
        if ($params) {
            $stmt->bind_param($types, ...$params);
        }
        $stmt->execute();
        $result = $stmt->get_result();
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
        $stmt->close();
    }
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $rows[] = $row;
        }
        $result->free();
    }
}

require __DIR__ . '/../../includes/header.php';
?>

<div class="page-head">
  <div>
    <h2>Data Rekap Belanja Gudang</h2>
  </div>
  <div class="page-actions">
    <a class="btn-action back" href="../../stocker.php">← Kembali</a>
    <a class="btn-action primary" href="inputrekapbelanjagudang.php">＋ Input Data</a>
  </div>
</div>

<?php if ($notice): ?>
<div class="alert alert-success">Data Rekap Belanja Gudang berhasil disimpan.</div>
<?php endif; ?>

<div class="panel">
  <form class="rbg-filter" method="get" action="">
    <div class="filter-field">
      <label for="filterTanggal">Tanggal</label>
      <input type="date" id="filterTanggal" name="tanggal" value="<?= e($filterTanggal) ?>">
    </div>
    <div class="filter-field">
      <label for="filterJenis">Tampilkan Data</label>
      <select id="filterJenis" name="jenis_belanja">
        <option value="" <?= $filterJenis === '' ? 'selected' : '' ?>>Semua Jenis</option>
        <option value="Dry" <?= $filterJenis === 'Dry' ? 'selected' : '' ?>>Dry</option>
        <option value="Frozen" <?= $filterJenis === 'Frozen' ? 'selected' : '' ?>>Frozen</option>
      </select>
    </div>
    <div class="filter-actions">
      <button class="btn-action primary" type="submit">Tampilkan</button>
      <a class="btn-action back" href="datarekapbelanjagudang.php">Reset</a>
    </div>
  </form>

  <div class="active-filter">
    <?php if ($filterTanggal !== ''): ?>
      <span class="filter-chip">Tanggal: <?= e(date('d/m/Y', strtotime($filterTanggal))) ?></span>
    <?php endif; ?>
    <?php if ($filterJenis !== ''): ?>
      <span class="filter-chip <?= $filterJenis === 'Frozen' ? 'chip-frozen' : 'chip-dry' ?>">Jenis: <?= e($filterJenis) ?></span>
    <?php endif; ?>
    <?php if ($filterTanggal === '' && $filterJenis === ''): ?>
      <span class="filter-muted">Menampilkan semua data</span>
    <?php endif; ?>
  </div>

  <div class="table-wrap">
    <table class="rekap-belanja-table">
      <thead>
        <tr>
          <th>No</th>
          <th>Tanggal</th>
          <th>Jenis Belanja</th>
          <th>Nama Bahan</th>
          <th>Kode Lot</th>
          <th>Jam Keluar</th>
          <th>Jumlah</th>
          <th>Nama PIC</th>
          <th>Keterangan</th><th>Aksi</th>
        </tr>
      </thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr>
          <td data-label="No">1</td>
          <td data-label="Data" colspan="8">Belum ada data belanja gudang.</td>
        </tr>
      <?php else: ?>
        <?php foreach ($rows as $index => $row): ?>
          <tr>
            <td data-label="No"><?= $index + 1 ?></td>
            <td data-label="Tanggal"><?= e(date('d/m/Y', strtotime($row['tanggal']))) ?></td>
            <td data-label="Jenis Belanja"><span class="badge <?= $row['jenis_belanja'] === 'Frozen' ? 'pink' : 'success' ?>"><?= e($row['jenis_belanja']) ?></span></td>
            <td data-label="Nama Bahan"><?= e($row['nama_bahan']) ?></td>
            <td data-label="Kode Lot"><?= e($row['kode_lot']) ?></td>
            <td data-label="Jam Keluar"><?= e(substr($row['jam_keluar'], 0, 5)) ?></td>
            <td data-label="Jumlah"><?= e($row['jumlah']) ?></td>
            <td data-label="Nama PIC"><?= e($row['nama_pic']) ?></td>
            <td data-label="Keterangan"><?= e($row['keterangan']) ?></td><td data-label="Aksi"><a class="btn-action" href="editrekapbelanjagudang.php?id=<?=e((string)$row['id'])?>">✏️ Edit</a></td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<style>
.rekap-form-panel .field-note{display:block;margin-top:6px;color:#7b8da5;font-size:11px;font-weight:600}
.rbg-filter{display:grid;grid-template-columns:minmax(180px,1fr) minmax(180px,1fr) auto;gap:12px;align-items:end;padding:14px;margin-bottom:16px;border:1px solid #e4ebf5;border-radius:16px;background:linear-gradient(180deg,#f9fbff,#fff);}
.filter-field{min-width:0}.filter-field label{display:block;margin-bottom:6px;color:#1e3a5f;font-size:12px;font-weight:800}.filter-field input,.filter-field select{width:100%;box-sizing:border-box;height:44px;padding:0 13px;border:1px solid #d7e1ee;border-radius:12px;background:#fff;color:var(--text);font:inherit;outline:none}.filter-field input:focus,.filter-field select:focus{border-color:#4b7cff;box-shadow:0 0 0 3px rgba(75,124,255,.10)}.filter-actions{display:flex;gap:8px;justify-content:flex-end}.filter-actions .btn-action{min-height:44px;box-sizing:border-box}.active-filter{display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin:-4px 0 14px}.filter-chip{display:inline-flex;align-items:center;padding:7px 11px;border-radius:999px;background:#eef5ff;color:#2d5fb0;font-size:11px;font-weight:800}.chip-frozen{background:#fce7f3;color:#be185d}.chip-dry{background:#ecfdf5;color:#047857}.filter-muted{color:#7b8da5;font-size:11px;font-weight:700}
.rekap-form-panel select,.rekap-form-panel input[type="date"]{display:block;width:100%;margin-top:7px;border:1px solid #dce4ef;border-radius:12px;padding:12px;font:inherit;outline:none;background:#fff;color:var(--text)}
.rekap-form-panel input[readonly]{background:#f8fbff;color:#476487;cursor:not-allowed}
.form-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:20px;flex-wrap:wrap}
.rekap-belanja-table{min-width:1080px!important}
.badge.pink{background:#fce7f3;color:#be185d}
.alert{margin-bottom:16px;padding:13px 15px;border-radius:12px;font-size:13px;font-weight:700}
.alert-success{background:#ecfdf5;border:1px solid #a7f3d0;color:#065f46}
.alert-error{background:#fff1f2;border:1px solid #fecdd3;color:#9f1239}
@media(max-width:760px){
  .rbg-filter{grid-template-columns:1fr;gap:10px}
  .filter-actions{display:grid;grid-template-columns:1fr 1fr}
  .filter-actions .btn-action{width:100%;justify-content:center}

  .rekap-form-panel .form-grid{grid-template-columns:1fr!important}
  .form-actions{display:grid;grid-template-columns:1fr 1fr}
  .form-actions .btn-action{width:100%}
  .rekap-belanja-table{min-width:0!important}
  .rekap-belanja-table thead{display:none!important}
  .rekap-belanja-table tbody tr{display:block;margin:0 0 12px;padding:12px;background:#fff;border:1px solid #e2eaf4;border-radius:16px;box-shadow:0 7px 18px rgba(38,66,116,.06)}
  .rekap-belanja-table td{display:grid!important;grid-template-columns:38% minmax(0,1fr);gap:10px;padding:8px 0!important;border:0!important;border-bottom:1px dashed #edf1f6!important;font-size:12px!important}
  .rekap-belanja-table td:last-child{border-bottom:0!important}
  .rekap-belanja-table td::before{content:attr(data-label);color:#69809d;font-size:10px;font-weight:900;text-transform:uppercase}
  .rekap-belanja-table td[colspan]{display:block!important;padding:8px 0!important}
}
@media(max-width:420px){.form-actions{grid-template-columns:1fr}.rekap-belanja-table td{grid-template-columns:92px minmax(0,1fr)!important}}
</style>

<?php require __DIR__ . '/../../includes/footer.php'; ?>
