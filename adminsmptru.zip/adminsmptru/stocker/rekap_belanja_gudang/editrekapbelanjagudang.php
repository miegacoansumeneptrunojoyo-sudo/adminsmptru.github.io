<?php
require_once __DIR__.'/../../config/config.php';
require_once __DIR__.'/../../config/database.php';
require_once __DIR__.'/../../config/helpers.php';
$id=(int)($_GET['id'] ?? $_POST['id'] ?? 0); $message=''; $error=''; $row=null;
if($id<=0){ http_response_code(400); exit('ID tidak valid.'); }
if(!db_ready()){ $error='Database belum terhubung: '.db_error_message(); } else {
  $st=$conn->prepare('SELECT * FROM `rekap_belanja_gudang` WHERE id=?'); $st->bind_param('i',$id); $st->execute(); $res=$st->get_result(); $row=$res->fetch_assoc(); $st->close();
  if(!$row){ http_response_code(404); exit('Data tidak ditemukan.'); }
}
if($_SERVER['REQUEST_METHOD']==='POST' && !$error && db_ready()){
  $tanggal=(string)($_POST['tanggal'] ?? $row['tanggal'] ?? '');
  $jenis_belanja=trim((string)($_POST['jenis_belanja'] ?? $row['jenis_belanja'] ?? ''));
  $nama_bahan=trim((string)($_POST['nama_bahan'] ?? $row['nama_bahan'] ?? ''));
  $kode_lot=trim((string)($_POST['kode_lot'] ?? $row['kode_lot'] ?? ''));
  $jam_keluar=trim((string)($_POST['jam_keluar'] ?? $row['jam_keluar'] ?? ''));
  $jumlah=trim((string)($_POST['jumlah'] ?? $row['jumlah'] ?? ''));
  $nama_pic=trim((string)($_POST['nama_pic'] ?? $row['nama_pic'] ?? ''));
  $keterangan=trim((string)($_POST['keterangan'] ?? $row['keterangan'] ?? ''));
  $st=$conn->prepare('UPDATE `rekap_belanja_gudang` SET `tanggal`=?, `jenis_belanja`=?, `nama_bahan`=?, `kode_lot`=?, `jam_keluar`=?, `jumlah`=?, `nama_pic`=?, `keterangan`=? WHERE id=?');
  if($st){ $st->bind_param('ssssssssi', $tanggal, $jenis_belanja, $nama_bahan, $kode_lot, $jam_keluar, $jumlah, $nama_pic, $keterangan, $id); if($st->execute()){ $st->close(); redirect_to('datarekapbelanjagudang.php'); } $error='Gagal memperbarui data: '.$st->error; $st->close(); } else $error='Query update gagal.';
}
$pageTitle='Rekap Belanja Gudang'; require __DIR__.'/../../includes/header.php';
?>
<div class="page-head"><div><h2>Edit Rekap Belanja Gudang</h2></div><div class="page-actions"><a class="btn-action back" href="datarekapbelanjagudang.php">← Kembali</a></div></div>
<?php if($error): ?><div class="alert alert-error"><?=e($error)?></div><?php endif; ?>
<form method="post" class="panel form-grid"><input type="hidden" name="id" value="<?=e((string)$id)?>">
<label>Tanggal<input type="date" name="tanggal" value="<?=e($row['tanggal'] ?? '')?>" required></label>
<label>Jenis Belanja<select name="jenis_belanja" required>
<option value="Dry" <?=((($row['jenis_belanja'] ?? "")==="Dry")?"selected":"")?>>Dry</option>
<option value="Frozen" <?=((($row['jenis_belanja'] ?? "")==="Frozen")?"selected":"")?>>Frozen</option>
</select></label>
<label>Nama Bahan<input type="text" name="nama_bahan" value="<?=e($row['nama_bahan'] ?? '')?>" required></label>
<label>Kode Lot<input type="text" name="kode_lot" value="<?=e($row['kode_lot'] ?? '')?>" required></label>
<label>Jam Keluar<input type="text" name="jam_keluar" value="<?=e($row['jam_keluar'] ?? '')?>" required></label>
<label>Jumlah<input type="text" name="jumlah" value="<?=e($row['jumlah'] ?? '')?>" required></label>
<label>Nama PIC<select name="nama_pic" required>
<option value="Arjuna" <?=((($row['nama_pic'] ?? "")==="Arjuna")?"selected":"")?>>Arjuna</option>
<option value="Kafi" <?=((($row['nama_pic'] ?? "")==="Kafi")?"selected":"")?>>Kafi</option>
<option value="Luluk" <?=((($row['nama_pic'] ?? "")==="Luluk")?"selected":"")?>>Luluk</option>
<option value="Ega" <?=((($row['nama_pic'] ?? "")==="Ega")?"selected":"")?>>Ega</option>
<option value="Atika" <?=((($row['nama_pic'] ?? "")==="Atika")?"selected":"")?>>Atika</option>
</select></label>
<label>Keterangan<select name="keterangan" required>
<option value="Kasir" <?=((($row['keterangan'] ?? "")==="Kasir")?"selected":"")?>>Kasir</option>
<option value="Noodle" <?=((($row['keterangan'] ?? "")==="Noodle")?"selected":"")?>>Noodle</option>
<option value="Presenter" <?=((($row['keterangan'] ?? "")==="Presenter")?"selected":"")?>>Presenter</option>
<option value="Dimsum" <?=((($row['keterangan'] ?? "")==="Dimsum")?"selected":"")?>>Dimsum</option>
<option value="Bar" <?=((($row['keterangan'] ?? "")==="Bar")?"selected":"")?>>Bar</option>
<option value="Produksi" <?=((($row['keterangan'] ?? "")==="Produksi")?"selected":"")?>>Produksi</option>
</select></label>
<div style="grid-column:1/-1;display:flex;gap:10px;justify-content:flex-end;margin-top:12px"><a class="btn-action back" href="datarekapbelanjagudang.php">Batal</a><button class="btn-action primary" type="submit">Update Data</button></div>
</form>
<?php require __DIR__.'/../../includes/footer.php'; ?>