<?php
$pageTitle = 'Rekap Belanja Gudang';
require __DIR__ . '/../../config/database.php';
require __DIR__ . '/../../config/helpers.php';

$today = date('Y-m-d');
$jenisBelanja = ['Dry', 'Frozen'];
$picList = ['Arjuna', 'Kafi', 'Luluk', 'Ega', 'Atika'];
$keteranganList = ['Kasir', 'Noodle', 'Presenter', 'Dimsum', 'Bar', 'Produksi'];
$errors = [];
$success = null;

$old = [
    'jenis_belanja' => '',
    'nama_bahan' => '',
    'kode_lot' => '',
    'jam_keluar' => '',
    'jumlah' => '',
    'nama_pic' => '',
    'keterangan' => '',
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal = $today; // selalu tanggal hari ini
    foreach ($old as $key => $value) {
        $old[$key] = trim((string)($_POST[$key] ?? ''));
    }

    if (!in_array($old['jenis_belanja'], $jenisBelanja, true)) {
        $errors[] = 'Jenis Belanja tidak valid.';
    }
    if ($old['nama_bahan'] === '') {
        $errors[] = 'Nama Bahan wajib diisi.';
    }
    if ($old['kode_lot'] === '') {
        $errors[] = 'Kode Lot wajib diisi.';
    }
    if (!preg_match('/^([01]\d|2[0-3]):[0-5]\d$/', $old['jam_keluar'])) {
        $errors[] = 'Jam Keluar harus menggunakan format HH:MM.';
    }
    if ($old['jumlah'] === '') {
        $errors[] = 'Jumlah wajib diisi.';
    }
    if (!in_array($old['nama_pic'], $picList, true)) {
        $errors[] = 'Nama PIC tidak valid.';
    }
    if (!in_array($old['keterangan'], $keteranganList, true)) {
        $errors[] = 'Keterangan tidak valid.';
    }

    if (!$errors && db_ready()) {
        $stmt = $conn->prepare(
            'INSERT INTO rekap_belanja_gudang
            (tanggal, jenis_belanja, nama_bahan, kode_lot, jam_keluar, jumlah, nama_pic, keterangan)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );

        if ($stmt) {
            $jumlah = $old['jumlah'];
            $stmt->bind_param(
                'ssssssss',
                $tanggal,
                $old['jenis_belanja'],
                $old['nama_bahan'],
                $old['kode_lot'],
                $old['jam_keluar'],
                $jumlah,
                $old['nama_pic'],
                $old['keterangan']
            );

            if ($stmt->execute()) {
                $stmt->close();
                redirect_to('datarekapbelanjagudang.php?saved=1');
            }
            $errors[] = 'Data gagal disimpan: ' . $stmt->error;
            $stmt->close();
        } else {
            $errors[] = 'Query database gagal dibuat.';
        }
    } elseif (!$errors && !db_ready()) {
        $errors[] = 'Database belum terhubung: ' . db_error_message();
    }
}

require __DIR__ . '/../../includes/header.php';
?>

<div class="page-head">
  <div>
    <h2>Input Rekap Belanja Gudang</h2>
  </div>
  <div class="page-actions">
    <a class="btn-action back" href="datarekapbelanjagudang.php">← Kembali</a>
  </div>
</div>

<?php if ($errors): ?>
<div class="alert alert-error">
  <strong>Data belum dapat disimpan.</strong>
  <ul style="margin:8px 0 0 18px;padding:0;">
    <?php foreach ($errors as $error): ?>
      <li><?= e($error) ?></li>
    <?php endforeach; ?>
  </ul>
</div>
<?php endif; ?>

<div class="panel rekap-form-panel">
  <div class="panel-title">Form Input</div>

  <form method="post" autocomplete="off">
    <div class="form-grid">
      <label>
        Tanggal
        <input type="date" value="<?= e($today) ?>" readonly aria-readonly="true">
        <input type="hidden" name="tanggal" value="<?= e($today) ?>">
        <small class="field-note">Otomatis menggunakan tanggal hari ini.</small>
      </label>

      <label>
        Jenis Belanja
        <select name="jenis_belanja" required>
          <option value="">Pilih Jenis Belanja</option>
          <?php foreach ($jenisBelanja as $item): ?>
            <option value="<?= e($item) ?>" <?= $old['jenis_belanja'] === $item ? 'selected' : '' ?>><?= e($item) ?></option>
          <?php endforeach; ?>
        </select>
      </label>

      <label>
        Nama Bahan
        <input type="text" name="nama_bahan" value="<?= e($old['nama_bahan']) ?>" placeholder="Masukkan nama bahan" required>
      </label>

      <label>
        Kode Lot
        <input type="text" name="kode_lot" value="<?= e($old['kode_lot']) ?>" placeholder="Masukkan kode lot" required>
      </label>

      <label>
        Jam Keluar
        <input type="time" name="jam_keluar" value="<?= e($old['jam_keluar']) ?>" step="60" required>
      </label>

      <label>
        Jumlah
        <input type="text" name="jumlah" value="<?= e($old['jumlah']) ?>" inputmode="decimal" placeholder="Masukkan jumlah" required>
      </label>

      <label>
        Nama PIC
        <select name="nama_pic" required>
          <option value="">Pilih Nama PIC</option>
          <?php foreach ($picList as $pic): ?>
            <option value="<?= e($pic) ?>" <?= $old['nama_pic'] === $pic ? 'selected' : '' ?>><?= e($pic) ?></option>
          <?php endforeach; ?>
        </select>
      </label>

      <label>
        Keterangan
        <select name="keterangan" required>
          <option value="">Pilih Station</option>
          <?php foreach ($keteranganList as $station): ?>
            <option value="<?= e($station) ?>" <?= $old['keterangan'] === $station ? 'selected' : '' ?>><?= e($station) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
    </div>

    <div class="form-actions spaced-actions">
      <a class="btn-action back" href="datarekapbelanjagudang.php">Reset</a>
      <button class="btn-action primary" type="submit">Simpan Data</button>
    </div>
  </form>
</div>

<?php require __DIR__ . '/../../includes/footer.php'; ?>
