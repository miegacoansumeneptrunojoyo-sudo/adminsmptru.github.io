<?php
$tanggal = $_GET['tanggal'] ?? date('Y-m-d');
$target = '../sogudang.php?tanggal=' . urlencode($tanggal);
header('Location: ' . $target);
exit;
?>
