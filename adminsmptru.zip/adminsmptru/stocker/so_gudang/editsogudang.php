<?php
require_once __DIR__.'/../../config/config.php';
require_once __DIR__.'/../../config/database.php';
require_once __DIR__.'/../../config/helpers.php';

$tanggal = $_POST['tanggal'] ?? $_GET['tanggal'] ?? date('Y-m-d');
$error=''; $message=''; $items=[]; $values=[];

if (db_ready()) {
    $res=$conn->query("SELECT id,no_urut,nama_barang FROM so_gudang_items WHERE aktif=1 ORDER BY no_urut ASC");
    if($res) while($r=$res->fetch_assoc()) $items[]=$r;
}

if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['update_so'])) {
    if(!db_ready()) {
        $error='Database belum siap.';
    } else {
        $conn->begin_transaction();
        try {
            $stmt=$conn->prepare("INSERT INTO so_gudang_stock (tanggal,item_id,krt_ball,pack_slop,pcs) VALUES (?,?,?,?,?) ON DUPLICATE KEY UPDATE krt_ball=VALUES(krt_ball), pack_slop=VALUES(pack_slop), pcs=VALUES(pcs), updated_at=CURRENT_TIMESTAMP");
            if(!$stmt) throw new Exception('Query tidak dapat disiapkan.');
            $kb=$_POST['krt_ball']??[]; $ps=$_POST['pack_slop']??[]; $pc=$_POST['pcs']??[];
            foreach($items as $item){
                $id=(int)$item['id']; $no=(int)$item['no_urut'];
                $v1=($kb[$no]??'')===''?null:(float)$kb[$no];
                $v2=($ps[$no]??'')===''?null:(float)$ps[$no];
                $v3=($pc[$no]??'')===''?null:(float)$pc[$no];
                $stmt->bind_param('siddd',$tanggal,$id,$v1,$v2,$v3);
            }
            if(!$stmt->execute() && $stmt->errno) throw new Exception($stmt->error);
            $stmt->close();
            $conn->commit();
            redirect_to('../sogudang.php?tanggal='.urlencode($tanggal).'&saved=1');
        } catch(Throwable $e) {
            $conn->rollback(); $error=$e->getMessage();
        }
    }
}

if (db_ready()) {
    $stmt=$conn->prepare("SELECT i.no_urut,s.krt_ball,s.pack_slop,s.pcs FROM so_gudang_items i LEFT JOIN so_gudang_stock s ON s.item_id=i.id AND s.tanggal=? WHERE i.aktif=1 ORDER BY i.no_urut");
    if($stmt){$stmt->bind_param('s',$tanggal);$stmt->execute();$res=$stmt->get_result();while($r=$res->fetch_assoc())$values[(int)$r['no_urut']]=$r;$stmt->close();}
}

$pageTitle='Edit SO Gudang'; require __DIR__.'/../../includes/header.php';
?>
<div class="page-head"><div><h2>Edit SO Gudang</h2></div><div class="page-actions"><a class="btn-action back" href="../sogudang.php?tanggal=<?=urlencode($tanggal)?>">← Kembali</a></div></div>
<?php if($error): ?><?=flash_message('error',$error)?><?php endif; ?>
<form method="post" class="so-entry-form">
<input type="hidden" name="tanggal" value="<?=e($tanggal)?>">
<section class="panel so-form-panel">
  <div class="so-form-head">
    <div><div class="station-icon">✏️</div><div><h3>Edit Stock Opname Gudang</h3><p>Perbaiki data untuk tanggal <?=e($tanggal)?>.</p></div></div>
    <div class="so-date-field inline-date"><label for="edit_tanggal">Tanggal</label><input id="edit_tanggal" type="date" value="<?=e($tanggal)?>" disabled></div>
  </div>
  <div class="table-wrap">
    <table class="so-input-table">
      <thead><tr><th>No</th><th>Nama Barang</th><th>KRT/BALL</th><th>PACK/SLOP</th><th>PCS</th></tr></thead>
      <tbody>
      <?php foreach($items as $item): $no=(int)$item['no_urut']; ?>
      <tr>
        <td><?=$no?></td><td class="item-name"><?=e($item['nama_barang'])?></td>
        <td><input type="number" step="0.01" min="0" name="krt_ball[<?=$no?>]" value="<?=e($values[$no]['krt_ball']??'')?>" placeholder="0" inputmode="decimal"></td>
        <td><input type="number" step="0.01" min="0" name="pack_slop[<?=$no?>]" value="<?=e($values[$no]['pack_slop']??'')?>" placeholder="0" inputmode="decimal"></td>
        <td><input type="number" step="0.01" min="0" name="pcs[<?=$no?>]" value="<?=e($values[$no]['pcs']??'')?>" placeholder="0" inputmode="decimal"></td>
      </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>
<div class="form-submit-bar"><a class="btn-action back" href="../sogudang.php?tanggal=<?=urlencode($tanggal)?>">Batal</a><button type="submit" name="update_so" value="1" class="btn-action primary">Update Data</button></div>
</form>
<?php require __DIR__.'/../../includes/footer.php'; ?>
