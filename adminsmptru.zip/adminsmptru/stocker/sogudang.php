<?php
require_once __DIR__.'/../config/config.php';
require_once __DIR__.'/../config/database.php';
require_once __DIR__.'/../config/helpers.php';
require_once __DIR__.'/../config/so_kitchen.php';

$pageTitle = 'Data SO Gudang';
$tanggal = $_GET['tanggal'] ?? $_POST['tanggal'] ?? date('Y-m-d');
$search = trim($_GET['search'] ?? '');
$error = '';
$rows = [];
$hasData = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    $tanggal = $_POST['tanggal'] ?? date('Y-m-d');
    if (!db_ready()) {
        $error = 'Database belum terhubung.';
    } else {
        $st = $conn->prepare('DELETE FROM so_gudang_stock WHERE tanggal = ?');
        if ($st) {
            $st->bind_param('s', $tanggal);
            if ($st->execute()) {
                $st->close();
                redirect_to('sogudang.php?tanggal='.urlencode($tanggal).'&deleted=1');
            }
            $error = 'Data gagal dihapus.';
            $st->close();
        } else {
            $error = 'Query hapus tidak dapat disiapkan.';
        }
    }
}

if (db_ready()) {
    $sql = "SELECT i.no_urut, i.nama_barang, s.krt_ball, s.pack_slop, s.pcs
            FROM so_gudang_items i
            LEFT JOIN so_gudang_stock s
              ON s.item_id = i.id AND s.tanggal = ?
            WHERE i.aktif = 1";
    if ($search !== '') $sql .= " AND i.nama_barang LIKE ?";
    $sql .= " ORDER BY i.no_urut ASC";
    $st = $conn->prepare($sql);
    if ($st) {
        if ($search !== '') {
            $like = '%'.$search.'%';
            $st->bind_param('ss', $tanggal, $like);
        } else {
            $st->bind_param('s', $tanggal);
        }
        $st->execute();
        $res = $st->get_result();
        while ($r = $res->fetch_assoc()) $rows[] = $r;
        $st->close();
    }
}

foreach ($rows as $r) {
    if ($r['krt_ball'] !== null || $r['pack_slop'] !== null || $r['pcs'] !== null) {
        $hasData = true;
        break;
    }
}

if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="SO-Gudang-'.$tanggal.'.csv"');
    $out = fopen('php://output','w');
    fputcsv($out,['Tanggal',$tanggal]);
    fputcsv($out,[]);
    fputcsv($out,['No','Nama Barang','KRT/BALL','PACK/SLOP','PCS']);
    foreach ($rows as $r) fputcsv($out,[$r['no_urut'],$r['nama_barang'],$r['krt_ball'],$r['pack_slop'],$r['pcs']]);
    fclose($out);
    exit;
}

require __DIR__.'/../includes/header.php';
?>
<div class="page-head">
  <div><h2>Data SO Gudang</h2></div>
  <div class="page-actions">
    <a class="btn-action back" href="../stocker.php">← Kembali</a>
    <form class="critical-filter" method="get">
      <input type="date" name="tanggal" value="<?=e($tanggal)?>" aria-label="Tanggal">
      <?php if ($search !== ''): ?><input type="hidden" name="search" value="<?=e($search)?>"><?php endif; ?>
      <button class="critical-show" type="submit">Tampilkan</button>
    </form>
    <a class="btn-action" href="so_gudang/editsogudang.php?tanggal=<?=urlencode($tanggal)?>">✏️ Edit Data</a>
    <a class="btn-action primary" href="so_gudang/inputso_gudang.php?tanggal=<?=urlencode($tanggal)?>">＋ Input Data</a>
  </div>
</div>

<?php if (isset($_GET['saved'])): ?><?=flash_message('success','Data SO Gudang berhasil disimpan untuk '.$tanggal.'.')?><?php endif; ?>
<?php if (isset($_GET['deleted'])): ?><?=flash_message('success','Data SO Gudang berhasil dihapus untuk '.$tanggal.'.')?><?php endif; ?>
<?php if ($error): ?><?=flash_message('error',$error)?><?php endif; ?>

<div class="panel">
  <div class="so-form-head">
    <div><div class="station-icon">📦</div><div><h3>SO Gudang</h3><p>Stock opname — <?=e($tanggal)?></p></div></div>
    <div class="page-actions">
      <form method="get" class="critical-filter">
        <input type="hidden" name="tanggal" value="<?=e($tanggal)?>">
        <input type="search" name="search" value="<?=e($search)?>" placeholder="Cari nama barang..." aria-label="Cari nama barang">
        <button class="critical-show" type="submit">Cari</button>
      </form>
      <a class="btn-action" href="sogudang.php?tanggal=<?=urlencode($tanggal)?>&search=<?=urlencode($search)?>&export=csv">Ekspor</a>
      <?php if ($hasData): ?>
      <form method="post" onsubmit="return confirm('Hapus seluruh data SO Gudang untuk tanggal ini?');">
        <input type="hidden" name="action" value="delete"><input type="hidden" name="tanggal" value="<?=e($tanggal)?>">
        <button class="btn-action danger" type="submit">🗑 Hapus Data</button>
      </form>
      <?php endif; ?>
    </div>
  </div>

<?php if (!$hasData): ?>
  <div class="empty-state" style="border-top:1px solid #dbe5f2;">
    <div class="empty-icon">📦</div><h3>Belum ada data</h3>
    <p>Belum ada SO Gudang untuk tanggal <?=e($tanggal)?>.</p>
    <a class="btn-action primary" href="so_gudang/inputso_gudang.php?tanggal=<?=urlencode($tanggal)?>">＋ Input Data</a>
  </div>
<?php else: ?>
  <div class="table-wrap">
    <table class="so-input-table">
      <thead><tr><th>No</th><th>Nama Barang</th><th>KRT/BALL</th><th>PACK/SLOP</th><th>PCS</th></tr></thead>
      <tbody>
      <?php foreach ($rows as $r): ?>
        <tr><td><?=e($r['no_urut'])?></td><td class="item-name"><?=e($r['nama_barang'])?></td><td><?=so_display_number($r['krt_ball'])?></td><td><?=so_display_number($r['pack_slop'])?></td><td><?=so_display_number($r['pcs'])?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
<?php endif; ?>
</div>
<?php require __DIR__.'/../includes/footer.php'; ?>
