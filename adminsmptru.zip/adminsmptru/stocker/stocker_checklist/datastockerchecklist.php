<?php
$pageTitle = 'Stocker Checklist';
require __DIR__ . '/../../config/database.php';

$items = [
  'BUAH BELIMBING',
  'BUAH APEL',
  'BUAH PEER',
  'BUAH STRAWBERRY',
  'CABE RAWIT',
  'DAUN BAWANG',
  'KULIT PANGSIT',
  'MIE',
];


function status_for_shift(array $row, string $shift): ?string
{
  $fields = [
    $shift . '_warna',
    $shift . '_aroma',
    $shift . '_tekstur',
  ];
  $values = [];
  foreach ($fields as $field) {
    if (!array_key_exists($field, $row) || $row[$field] === null || $row[$field] === '') {
      return null;
    }
    $values[] = (int)$row[$field];
  }
  return in_array(0, $values, true) ? 'Rejected' : 'Accepted';
}

function condition_icon($value): string
{
  if ($value === null || $value === '') return '<span class="check-empty">—</span>';
  return ((int)$value === 1)
    ? '<span class="icon-ok" title="Ya" aria-label="Ya">✓</span>'
    : '<span class="icon-no" title="Tidak" aria-label="Tidak">×</span>';
}

$today = date('Y-m-d');
$selectedDate = trim((string)($_GET['tanggal'] ?? $today));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate)) $selectedDate = $today;

$records = [];
if (db_ready()) {
  $stmtHeader = $conn->prepare("SELECT id, tanggal, dilaporkan_oleh, disetujui_oleh
                                  FROM stocker_checklists
                                  WHERE tanggal=?
                                  ORDER BY tanggal DESC, id DESC");
  if ($stmtHeader) {
    $stmtHeader->bind_param('s', $selectedDate);
    if ($stmtHeader->execute()) {
      $res = $stmtHeader->get_result();
      while ($header = $res->fetch_assoc()) {
        $headerId = (int)$header['id'];
        $rowsByItem = [];
        $st = $conn->prepare("SELECT nama_barang, opening_warna, opening_aroma, opening_tekstur,
                                         closing_warna, closing_aroma, closing_tekstur
                                  FROM stocker_checklist_items
                                  WHERE checklist_id=?");
        if ($st) {
          $st->bind_param('i', $headerId);
          if ($st->execute()) {
            $r = $st->get_result();
            while ($itemRow = $r->fetch_assoc()) {
              $rowsByItem[(string)$itemRow['nama_barang']] = $itemRow;
            }
          }
          $st->close();
        }
        $records[] = [
          'id' => $headerId,
          'tanggal' => $header['tanggal'],
          'dilaporkan_oleh' => $header['dilaporkan_oleh'],
          'disetujui_oleh' => $header['disetujui_oleh'],
          'items' => $rowsByItem,
        ];
      }
      $res->free();
    }
    $stmtHeader->close();
  }
}

require __DIR__ . '/../../includes/header.php';
?>
<style>
  .checklist-record {
    margin-bottom: 24px;
    border: 1px solid #e1e9f6;
    border-radius: 18px;
    overflow: hidden;
    background: #fff;
    box-shadow: 0 8px 28px rgba(30, 64, 175, .05)
  }

  .record-head {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 18px;
    padding: 18px 20px;
    background: linear-gradient(90deg, #f4f8ff 0%, #fff7fb 100%);
    border-bottom: 1px solid #e3eaf6
  }

  .record-title {
    display: flex;
    gap: 12px;
    align-items: flex-start
  }

  .record-icon {
    width: 42px;
    height: 42px;
    border-radius: 12px;
    background: linear-gradient(135deg, #eaf2ff, #fde8f3);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 21px
  }

  .record-title h3 {
    margin: 0;
    color: #173a7a;
    font-size: 18px
  }

  .record-meta {
    margin-top: 4px;
    color: #64748b;
    font-size: 13px
  }

  .record-actions {
    display: flex;
    gap: 8px;
    align-items: center;
    flex-wrap: wrap
  }

  .record-table-wrap {
    overflow: auto
  }

  .record-table {
    width: 100%;
    border-collapse: collapse;
    min-width: 980px;
    table-layout: fixed
  }

  .record-table th,
  .record-table td {
    border-bottom: 1px solid #e6ebf2;
    padding: 11px 8px;
    text-align: center;
    vertical-align: middle
  }

  .record-table th.item-head,
  .record-table td.item-name {
    width: 165px;
    max-width: 165px
  }

  .record-table .metric-col {
    width: 82px
  }

  .record-table .metric-group {
    width: 164px
  }

  .data-date-filter {
    margin: 0
  }

  .data-date-filter label {
    white-space: nowrap
  }

  .record-table th {
    background: #f4f8ff;
    color: #173a7a;
    font-weight: 800;
    font-size: 13px
  }

  .record-table th.item-head,
  .record-table td.item-name {
    text-align: left
  }

  .record-table td.item-name {
    font-weight: 700;
    color: #173a7a;
    white-space: nowrap
  }

  .record-table tr:last-child td {
    border-bottom: 0
  }

  .subhead th {
    background: #fbfcff;
    font-size: 12px
  }

  .icon-ok,
  .icon-no,
  .check-empty {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 30px;
    height: 30px;
    border-radius: 9px;
    font-size: 21px;
    font-weight: 900
  }

  .icon-ok {
    color: #2563eb;
    background: #eff6ff;
    border: 1px solid #bfdbfe
  }

  .icon-no {
    color: #dc2626;
    background: #fff1f2;
    border: 1px solid #fecaca
  }

  .check-empty {
    color: #94a3b8;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    font-size: 16px
  }

  .status-icon {
    width: 36px;
    height: 36px;
    border-radius: 50%;
    font-size: 22px
  }

  .record-footer {
    display: flex;
    justify-content: space-between;
    gap: 16px;
    flex-wrap: wrap;
    padding: 13px 20px;
    border-top: 1px solid #e6ebf2;
    background: #fbfdff;
    color: #64748b;
    font-size: 13px
  }

  .legend {
    display: flex;
    gap: 16px;
    align-items: center;
    flex-wrap: wrap
  }

  .legend span {
    display: inline-flex;
    align-items: center;
    gap: 7px
  }

  .empty-state {
    padding: 34px;
    text-align: center;
    color: #64748b
  }

  .empty-state strong {
    display: block;
    color: #173a7a;
    font-size: 18px;
    margin-bottom: 6px
  }

  @media(max-width:1100px) {
    .top-inline {
      gap: 10px
    }

    .top-inline .data-date-filter input {
      width: 145px
    }

    .top-inline .btn-action {
      padding: 9px 11px
    }
  }

  @media(max-width:900px) {
    .top-inline {
      display: grid !important;
      grid-template-columns: 1fr 1fr;
      align-items: center
    }

    .top-inline .title-wrap {
      grid-column: 1 / -1
    }

    .top-inline .data-date-filter {
      grid-column: 1 / -1;
      justify-content: flex-start;
      width: 100%
    }

    .top-inline .page-actions {
      justify-content: flex-end
    }

    .top-inline .data-date-filter input {
      flex: 1;
      min-width: 0;
      width: auto
    }

    .top-inline .data-date-filter .btn-action {
      white-space: nowrap
    }

    .record-head {
      padding: 14px
    }

    .record-title h3 {
      font-size: 16px
    }

    .record-table {
      min-width: 980px
    }

    .record-footer {
      padding: 12px 14px
    }

    .record-actions .btn-action {
      font-size: 12px;
      padding: 9px 11px
    }
  }
</style>

<div class="page-head top-inline" style="display:flex;align-items:center;gap:18px;flex-wrap:nowrap;">
  <div class="title-wrap" style="flex:1;min-width:220px;">
    <h2 style="margin:0;">Data Stocker Checklist</h2>
  </div>
  <form method="get" class="data-date-filter" style="display:flex;align-items:center;gap:10px;flex:none;">
    <a class="btn-action back" href="../../stocker.php">← Kembali</a>
    <input id="tanggal" type="date" name="tanggal" value="<?= e($selectedDate) ?>" style="height:42px;border:1px solid #d7e1f2;border-radius:11px;padding:0 12px;font:600 14px inherit;color:#173a7a;background:#fff;">
    <button type="submit" class="btn-action primary">Tampilkan</button>
  </form>
  <div class="page-actions" style="display:flex;gap:8px;flex:none;">
    <a class="btn-action primary" href="inputstockerchecklist.php">＋ Input Data</a>
  </div>
</div>

<div class="panel">

  <?php if (!$records): ?>
    <div class="empty-state">
      <strong>Belum ada data Stocker Checklist</strong>
    </div>
  <?php else: ?>
    <?php foreach ($records as $record): ?>
      <section class="checklist-record">
        <div class="record-head">
          <div class="record-title">
            <div class="record-icon">📋</div>
            <div>
              <h3>Stocker Checklist — <?= e(date('d/m/Y', strtotime($record['tanggal']))) ?></h3>
              <div class="record-meta">Dilaporkan: <strong><?= e((string)$record['dilaporkan_oleh']) ?></strong> · Disetujui: <strong><?= e((string)$record['disetujui_oleh']) ?></strong></div>
            </div>
          </div>
          <div class="record-actions">
            <a class="btn-action" href="inputstockerchecklist.php?tanggal=<?= urlencode($record['tanggal']) ?>">✏️ Edit</a>
          </div>
        </div>

        <div class="record-table-wrap">
          <table class="record-table">
            <colgroup>
              <col style="width:52px;">
              <col style="width:165px;">
              <col class="metric-col">
              <col class="metric-col">
              <col class="metric-col">
              <col class="metric-col">
              <col class="metric-col">
              <col class="metric-col">
            </colgroup>
            <thead>
              <tr>
                <th rowspan="2" style="width:52px">No</th>
                <th rowspan="2" class="item-head">Nama</th>
                <th colspan="2" class="metric-group">Warna</th>
                <th colspan="2" class="metric-group">Aroma</th>
                <th colspan="2" class="metric-group">Tekstur</th>
              </tr>
              <tr class="subhead">
                <th>Opening</th>
                <th>Closing</th>
                <th>Opening</th>
                <th>Closing</th>
                <th>Opening</th>
                <th>Closing</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($items as $i => $item):
                $row = $record['items'][$item] ?? [
                  'opening_warna' => null,
                  'opening_aroma' => null,
                  'opening_tekstur' => null,
                  'closing_warna' => null,
                  'closing_aroma' => null,
                  'closing_tekstur' => null,
                ];
              ?>
                <tr>
                  <td><?= ($i + 1) ?></td>
                  <td class="item-name"><?= e($item) ?></td>
                  <td><?= condition_icon($row['opening_warna']) ?></td>
                  <td><?= condition_icon($row['closing_warna']) ?></td>
                  <td><?= condition_icon($row['opening_aroma']) ?></td>
                  <td><?= condition_icon($row['closing_aroma']) ?></td>
                  <td><?= condition_icon($row['opening_tekstur']) ?></td>
                  <td><?= condition_icon($row['closing_tekstur']) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>

        <div class="record-footer">
          <div>Tanggal data: <strong><?= e(date('d/m/Y', strtotime($record['tanggal']))) ?></strong></div>
        </div>
      </section>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/../../includes/footer.php'; ?>