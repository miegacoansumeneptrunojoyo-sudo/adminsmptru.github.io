<?php
$pageTitle='Stocker Checklist';
require __DIR__.'/../../config/database.php';

$items = [
    'BUAH BELIMBING',
    'BUAH APEL',
    'BUAH PEER',
    'BUAH STRAWBERRY',
    'CABE RAWIT',
    'DAUN BAWANG',
    'KULIT PANGSIT',
    'MIE',
];

$today = date('Y-m-d');
$selectedDate = trim((string)($_POST['tanggal'] ?? $_GET['tanggal'] ?? $today));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate)) $selectedDate = $today;

$errors = [];
$success = false;
$existing = [];
$header = ['dilaporkan_oleh'=>'', 'disetujui_oleh'=>''];

function normalize_choice($value): ?int {
    if ($value === '' || $value === null) return null;
    return ((string)$value === '1') ? 1 : 0;
}

// Ambil data tersimpan untuk tanggal yang dipilih agar form bisa diedit/update.
if (db_ready()) {
    $stmt = $conn->prepare("SELECT id, dilaporkan_oleh, disetujui_oleh FROM stocker_checklists WHERE tanggal=? LIMIT 1");
    if ($stmt) {
        $stmt->bind_param('s', $selectedDate);
        if ($stmt->execute()) {
            $res = $stmt->get_result();
            if ($row = $res->fetch_assoc()) {
                $checklistId = (int)$row['id'];
                $header['dilaporkan_oleh'] = (string)$row['dilaporkan_oleh'];
                $header['disetujui_oleh'] = (string)$row['disetujui_oleh'];

                $d = $conn->prepare("SELECT nama_barang, opening_warna, opening_aroma, opening_tekstur, closing_warna, closing_aroma, closing_tekstur FROM stocker_checklist_items WHERE checklist_id=?");
                if ($d) {
                    $d->bind_param('i', $checklistId);
                    if ($d->execute()) {
                        $dr = $d->get_result();
                        while ($itemRow = $dr->fetch_assoc()) {
                            $existing[(string)$itemRow['nama_barang']] = $itemRow;
                        }
                    }
                    $d->close();
                }
            }
        }
        $stmt->close();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal = $selectedDate;
    $dilaporkan = trim((string)($_POST['dilaporkan_oleh'] ?? ''));
    $disetujui = 'Alvin Zakaria';

    $header['dilaporkan_oleh'] = $dilaporkan;
    $header['disetujui_oleh'] = $disetujui;

    if ($dilaporkan === '') $errors[] = 'Dilaporkan oleh wajib diisi.';

    if (!$errors && !db_ready()) {
        $errors[] = 'Database belum terhubung: ' . db_error_message();
    }

    if (!$errors) {
        $conn->begin_transaction();
        try {
            $sql = "INSERT INTO stocker_checklists (tanggal, dilaporkan_oleh, disetujui_oleh)
                    VALUES (?, ?, ?)
                    ON DUPLICATE KEY UPDATE dilaporkan_oleh=VALUES(dilaporkan_oleh), disetujui_oleh=VALUES(disetujui_oleh), updated_at=NOW(), id=LAST_INSERT_ID(id)";
            $stmt = $conn->prepare($sql);
            if (!$stmt) throw new Exception('Gagal menyiapkan data checklist.');
            $stmt->bind_param('sss', $tanggal, $dilaporkan, $disetujui);
            if (!$stmt->execute()) throw new Exception('Gagal menyimpan header checklist.');
            $checklistId = (int)$conn->insert_id;
            $stmt->close();

            // Hapus detail lama untuk tanggal tersebut lalu simpan kondisi terbaru.
            $del = $conn->prepare("DELETE FROM stocker_checklist_items WHERE checklist_id=?");
            if (!$del) throw new Exception('Gagal menyiapkan pembaruan checklist.');
            $del->bind_param('i', $checklistId);
            if (!$del->execute()) throw new Exception('Gagal menghapus detail lama.');
            $del->close();

            $detailSql = "INSERT INTO stocker_checklist_items
                (checklist_id, nama_barang, opening_warna, opening_aroma, opening_tekstur,
                 closing_warna, closing_aroma, closing_tekstur)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $detailStmt = $conn->prepare($detailSql);
            if (!$detailStmt) throw new Exception('Gagal menyiapkan detail checklist.');

            foreach ($items as $item) {
                $key = md5($item);
                $ow = normalize_choice($_POST['opening'][$key]['warna'] ?? null);
                $oa = normalize_choice($_POST['opening'][$key]['aroma'] ?? null);
                $ot = normalize_choice($_POST['opening'][$key]['tekstur'] ?? null);
                $cw = normalize_choice($_POST['closing'][$key]['warna'] ?? null);
                $ca = normalize_choice($_POST['closing'][$key]['aroma'] ?? null);
                $ct = normalize_choice($_POST['closing'][$key]['tekstur'] ?? null);

                $detailStmt->bind_param('isiiiiii', $checklistId, $item, $ow, $oa, $ot, $cw, $ca, $ct);
                if (!$detailStmt->execute()) throw new Exception('Gagal menyimpan item ' . $item . '.');
            }
            $detailStmt->close();

            $conn->commit();
            $success = true;

            // Reload nilai setelah penyimpanan.
            $existing = [];
            $d = $conn->prepare("SELECT nama_barang, opening_warna, opening_aroma, opening_tekstur, closing_warna, closing_aroma, closing_tekstur FROM stocker_checklist_items WHERE checklist_id=?");
            if ($d) {
                $d->bind_param('i', $checklistId);
                if ($d->execute()) {
                    $dr = $d->get_result();
                    while ($itemRow = $dr->fetch_assoc()) $existing[(string)$itemRow['nama_barang']] = $itemRow;
                }
                $d->close();
            }
        } catch (Throwable $e) {
            $conn->rollback();
            $errors[] = $e->getMessage();
        }
    }
}

require __DIR__.'/../../includes/header.php';
?>
<style>
.checklist-info{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:18px}
.checklist-info .info{background:#eff6ff;border:1px solid #dbeafe;padding:10px 14px;border-radius:12px;color:#1e3a8a;font-size:13px}
.checklist-table-wrap{overflow:auto}
.checklist-table{width:100%;border-collapse:separate;border-spacing:0;min-width:980px}
.checklist-table th,.checklist-table td{border-bottom:1px solid #e5e7eb;padding:12px 10px;text-align:center;vertical-align:middle}
.checklist-table th{background:#f4f8ff;color:#173a7a;font-weight:800}
.checklist-table th.item-head,.checklist-table td.item-name{text-align:left}
.checklist-table td.item-name{font-weight:700;color:#1e3a8a;white-space:nowrap}
.yn-select{width:86px;height:38px;border:1px solid #cfdcf0;border-radius:10px;background:#fff;color:#173a7a;font:600 13px inherit;padding:0 10px;outline:none;cursor:pointer}
.yn-select:focus{border-color:#2563eb;box-shadow:0 0 0 3px rgba(37,99,235,.12)}
.status-cell{min-width:100px}
.status-badge{display:inline-flex;align-items:center;justify-content:center;min-width:88px;height:34px;padding:0 12px;border-radius:999px;font-size:12px;font-weight:800;border:1px solid transparent}
.status-badge.empty{background:#f8fafc;color:#94a3b8;border-color:#e2e8f0}
.status-badge.accepted{background:#ecfdf5;color:#15803d;border-color:#bbf7d0}
.status-badge.rejected{background:#fff1f2;color:#be123c;border-color:#fecdd3}
.form-top{display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;margin-bottom:18px}
.form-top label{display:flex;flex-direction:column;gap:7px;font-weight:700;color:#173a7a}
.form-top input{height:46px;border:1px solid #d7e1f2;border-radius:12px;padding:0 14px;font:inherit;box-sizing:border-box;background:#fff}
.date-auto{background:#f8fbff!important;color:#173a7a;font-weight:700}
@media(max-width:900px){
 .form-top{grid-template-columns:1fr}
 .checklist-table{min-width:1040px}
}
</style>

<div class="page-head">
  <div><h2>Input Stocker Checklist</h2></div>
  <div class="page-actions"><a class="btn-action back" href="datastockerchecklist.php">← Kembali</a></div>
</div>

<?php if ($success): ?>
<div class="alert success">Stocker Checklist berhasil disimpan.</div>
<?php endif; ?>
<?php if ($errors): ?>
<div class="alert danger"><ul><?php foreach($errors as $e): ?><li><?=htmlspecialchars($e)?></li><?php endforeach; ?></ul></div>
<?php endif; ?>

<div class="panel">
  <div class="panel-title">Form Stocker Checklist</div>
  <div class="checklist-info">
    <div class="info">Pilih Ya atau Tidak pada setiap parameter.</div>
    <div class="info">Status otomatis berdasarkan Warna, Aroma, dan Tekstur.</div>
    <div class="info">Jika salah satu parameter Tidak, status menjadi Rejected.</div>
  </div>

  <form method="post">
    <div class="form-top">
      <label>Tanggal
        <input class="date-auto" type="date" name="tanggal" value="<?=htmlspecialchars($selectedDate)?>" required>
      </label>
      <label>Dilaporkan Oleh
        <select class="yn-select" name="dilaporkan_oleh" required style="width:100%;height:46px;box-sizing:border-box;">
          <option value="">Pilih Nama Stocker</option>
          <option value="Arjuna" <?=($header['dilaporkan_oleh']==='Arjuna'?'selected':'')?>>Arjuna</option>
          <option value="Kafi" <?=($header['dilaporkan_oleh']==='Kafi'?'selected':'')?>>Kafi</option>
        </select>
      </label>
      <label>Disetujui Oleh
        <input class="date-auto" type="text" name="disetujui_oleh" value="Alvin Zakaria" readonly>
      </label>
    </div>

    <div class="checklist-table-wrap">
      <table class="checklist-table">
        <thead>
          <tr>
            <th rowspan="2" style="width:55px">No</th>
            <th rowspan="2" class="item-head">Nama</th>
            <th colspan="2">Warna</th>
            <th colspan="2">Aroma</th>
            <th colspan="2">Tekstur</th>
            <th colspan="2">Status</th>
          </tr>
          <tr>
            <th>Opening</th><th>Closing</th>
            <th>Opening</th><th>Closing</th>
            <th>Opening</th><th>Closing</th>
            <th>Opening</th><th>Closing</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach($items as $i=>$item):
              $key = md5($item);
              $row = $existing[$item] ?? [];
              $ow = array_key_exists('opening_warna',$row) && $row['opening_warna'] !== null ? (string)$row['opening_warna'] : '';
              $oa = array_key_exists('opening_aroma',$row) && $row['opening_aroma'] !== null ? (string)$row['opening_aroma'] : '';
              $ot = array_key_exists('opening_tekstur',$row) && $row['opening_tekstur'] !== null ? (string)$row['opening_tekstur'] : '';
              $cw = array_key_exists('closing_warna',$row) && $row['closing_warna'] !== null ? (string)$row['closing_warna'] : '';
              $ca = array_key_exists('closing_aroma',$row) && $row['closing_aroma'] !== null ? (string)$row['closing_aroma'] : '';
              $ct = array_key_exists('closing_tekstur',$row) && $row['closing_tekstur'] !== null ? (string)$row['closing_tekstur'] : '';
          ?>
          <tr>
            <td><?=($i+1)?></td>
            <td class="item-name"><?=htmlspecialchars($item)?></td>
            <?php
              foreach ([
                ['name'=>'warna','value'=>$ow,'shift'=>'opening'],
                ['name'=>'warna','value'=>$cw,'shift'=>'closing'],
                ['name'=>'aroma','value'=>$oa,'shift'=>'opening'],
                ['name'=>'aroma','value'=>$ca,'shift'=>'closing'],
                ['name'=>'tekstur','value'=>$ot,'shift'=>'opening'],
                ['name'=>'tekstur','value'=>$ct,'shift'=>'closing'],
              ] as $f):
            ?>
              <td>
                <select class="yn-select condition-select" name="<?=$f['shift']?>[<?=$key?>][<?=$f['name']?>]" data-row="<?=$key?>" data-shift="<?=$f['shift']?>" data-field="<?=$f['name']?>" aria-label="<?=ucfirst($f['name'])?> <?=$f['shift']?> <?=$item?>">
                  <option value="" <?=($f['value']===''?'selected':'')?>>Pilih</option>
                  <option value="1" <?=($f['value']==='1'?'selected':'')?>>Ya</option>
                  <option value="0" <?=($f['value']==='0'?'selected':'')?>>Tidak</option>
                </select>
              </td>
            <?php endforeach; ?>
            <td class="status-cell"><span class="status-badge empty" id="status_opening_<?=$key?>">—</span></td>
            <td class="status-cell"><span class="status-badge empty" id="status_closing_<?=$key?>">—</span></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

    <div class="panel-note" style="margin-top:16px">
      <strong>STATUS OTOMATIS</strong><br>
      Warna + Aroma + Tekstur semuanya <strong>Ya</strong> = <strong>Accepted</strong>.<br>
      Jika salah satu saja <strong>Tidak</strong> = <strong>Rejected</strong>.
    </div>

    <div class="page-actions" style="margin-top:22px;justify-content:flex-end">
      <a class="btn-action back" href="datastockerchecklist.php">Reset</a>
      <button class="btn-action primary" type="submit">Simpan Data</button>
    </div>
  </form>
</div>

<script>
function updateStatus(rowKey, shift){
    const fields = ['warna','aroma','tekstur'];
    const values = fields.map(field => {
        const el = document.querySelector('[data-row="'+rowKey+'"][data-shift="'+shift+'"][data-field="'+field+'"]');
        return el ? el.value : '';
    });
    const badge = document.getElementById('status_'+shift+'_'+rowKey);
    if(!badge) return;
    badge.className = 'status-badge';
    if(values.every(v => v === '')){
        badge.textContent = '—';
        badge.classList.add('empty');
    } else if(values.some(v => v === '0')){
        badge.textContent = 'Rejected';
        badge.classList.add('rejected');
    } else if(values.every(v => v === '1')){
        badge.textContent = 'Accepted';
        badge.classList.add('accepted');
    } else {
        badge.textContent = '—';
        badge.classList.add('empty');
    }
}

document.querySelectorAll('.condition-select').forEach(function(select){
    select.addEventListener('change', function(){
        updateStatus(this.dataset.row, this.dataset.shift);
    });
});

<?php foreach($items as $item): $k=md5($item); ?>
updateStatus('<?=$k?>','opening');
updateStatus('<?=$k?>','closing');
<?php endforeach; ?>
</script>

<?php require __DIR__.'/../../includes/footer.php'; ?>
