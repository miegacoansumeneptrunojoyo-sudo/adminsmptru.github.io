<?php
$pageTitle = 'Storage Inspection';
require __DIR__ . '/../../config/database.php';

$today = date('Y-m-d');
$selectedDate = trim((string)($_GET['tanggal'] ?? $today));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate)) $selectedDate = $today;

$row = null;
if (db_ready()) {
  $stmt = $conn->prepare("SELECT * FROM storage_inspections WHERE tanggal=? LIMIT 1");
  if ($stmt) {
    $stmt->bind_param('s', $selectedDate);
    $stmt->execute();
    $res = $stmt->get_result();
    $row = $res->fetch_assoc();
    $stmt->close();
  }
}

$locations = [
  ['key' => 'cold_storage', 'label' => 'COLD STORAGE'],
  ['key' => 'freezer_1', 'label' => 'FREEZER 1'],
  ['key' => 'freezer_2', 'label' => 'FREEZER 2'],
  ['key' => 'freezer_3', 'label' => 'FREEZER 3'],
  ['key' => 'chiller_1', 'label' => 'CHILLER 1'],
  ['key' => 'chiller_2', 'label' => 'CHILLER 2'],
  ['key' => 'chiller_3', 'label' => 'CHILLER 3'],
  ['key' => 'chiller_4', 'label' => 'CHILLER 4'],
];
$storage = $row ? json_decode((string)$row['storage_data'], true) : [];
$transfers = $row ? json_decode((string)$row['pindah_data'], true) : [];
$returns = $row ? json_decode((string)$row['retur_data'], true) : [];

require __DIR__ . '/../../includes/header.php';
?>
<style>
  .storage-record {
    margin-bottom: 24px;
    border: 1px solid #e1e9f6;
    border-radius: 18px;
    overflow: hidden;
    background: #fff;
    box-shadow: 0 8px 28px rgba(30, 64, 175, .05)
  }

  .storage-record-head {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 18px;
    padding: 18px 20px;
    background: linear-gradient(90deg, #f4f8ff 0%, #fff7fb 100%);
    border-bottom: 1px solid #e3eaf6
  }

  .storage-record-title {
    display: flex;
    gap: 12px;
    align-items: flex-start
  }

  .storage-record-icon {
    width: 42px;
    height: 42px;
    border-radius: 12px;
    background: linear-gradient(135deg, #eaf2ff, #fde8f3);
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 21px
  }

  .storage-record-title h3 {
    margin: 0;
    color: #173a7a;
    font-size: 18px
  }

  .storage-record-meta {
    margin-top: 4px;
    color: #64748b;
    font-size: 13px
  }

  .storage-record-actions {
    display: flex;
    gap: 8px;
    align-items: center;
    flex-wrap: wrap
  }

  .storage-filter {
    display: flex;
    align-items: center;
    gap: 10px;
    flex: none
  }

  .storage-filter input {
    height: 42px;
    border: 1px solid #d7e1f2;
    border-radius: 11px;
    padding: 0 12px;
    font: 600 14px inherit;
    color: #173a7a;
    background: #fff
  }

  .storage-filter .btn-action {
    height: 42px
  }

  .storage-table-wrap {
    overflow: auto
  }

  .storage-table {
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed
  }

  .storage-table th,
  .storage-table td {
    border-bottom: 1px solid #e6ebf2;
    padding: 10px 8px;
    text-align: center;
    vertical-align: middle
  }

  .storage-table th {
    background: #f4f8ff;
    color: #173a7a;
    font-weight: 800;
    font-size: 13px
  }

  .storage-table td {
    background: #fff;
    color: #173a7a
  }

  .storage-table td.label {
    text-align: left;
    font-weight: 700;
    white-space: nowrap
  }

  .storage-table tr:last-child td {
    border-bottom: 0
  }

  .storage-sub {
    padding: 0 20px 20px
  }

  .storage-sub h4 {
    margin: 20px 0 10px;
    color: #173a7a;
    font-size: 15px
  }

  .subtable {
    width: 100%;
    border-collapse: collapse;
    min-width: 860px
  }

  .subtable th,
  .subtable td {
    border: 1px solid #dfe6ef;
    padding: 8px;
    text-align: center
  }

  .subtable th {
    background: #f4f8fd;
    color: #143d76;
    font-size: 12px
  }

  .subtable td {
    background: #fff;
    color: #243b63;
    font-size: 12px
  }

  .storage-signature {
    display: grid;
    grid-template-columns: minmax(0, 520px) minmax(0, 520px);
    max-width: 1040px;
    margin: 4px 20px 20px
  }

  .sig-box {
    border: 1px solid #d9e2ec;
    min-height: 120px;
    background: #fff
  }

  .sig-title {
    padding: 10px;
    background: #f4f7fb;
    text-align: center;
    font-size: 12px;
    font-weight: 900;
    color: #143d76;
    border-bottom: 1px solid #d9e2ec
  }

  .sig-name {
    min-height: 75px;
    display: flex;
    align-items: flex-end;
    justify-content: center;
    padding: 10px;
    font-weight: 900;
    color: #173d76
  }

  .sig-box+.sig-box {
    border-left: 0
  }

  .empty-state {
    padding: 34px;
    text-align: center;
    color: #64748b
  }

  .empty-state strong {
    display: block;
    color: #173a7a;
    font-size: 18px;
    margin-bottom: 6px
  }

  .storage-top {
    display: flex;
    align-items: center;
    gap: 18px;
    flex-wrap: nowrap;
    margin-bottom: 18px
  }

  .storage-top .title-wrap {
    flex: 1;
    min-width: 220px
  }

  .storage-top .title-wrap h2 {
    margin: 0
  }

  .storage-top .page-actions {
    display: flex;
    gap: 8px;
    flex: none
  }

  @media(max-width:1000px) {
    .storage-top {
      display: grid;
      grid-template-columns: 1fr auto;
      align-items: center
    }

    .storage-top .title-wrap {
      grid-column: 1/-1
    }

    .storage-top .storage-filter {
      grid-column: 1/-1;
      justify-content: flex-start
    }

    .storage-top .page-actions {
      justify-content: flex-end
    }

    .storage-filter input {
      flex: 1;
      min-width: 0
    }
  }

  @media(max-width:800px) {
    .storage-record-head {
      padding: 14px;
      flex-direction: column
    }

    .storage-record-title h3 {
      font-size: 16px
    }

    .storage-record-actions {
      width: 100%;
      justify-content: flex-end
    }

    .storage-table {
      min-width: 620px
    }

    .storage-signature {
      grid-template-columns: 1fr;
      max-width: none;
      margin: 4px 14px 18px
    }

    .sig-box+.sig-box {
      border-left: 1px solid #d9e2ec;
      border-top: 0
    }

    .storage-sub {
      padding: 0 14px 16px
    }

    .storage-top {
      grid-template-columns: 1fr
    }

    .storage-top .page-actions {
      justify-content: flex-start;
      flex-wrap: wrap
    }

    .storage-filter {
      width: 100%;
      flex-wrap: wrap
    }

    .storage-filter input {
      width: 100%
    }

    .storage-filter .btn-action {
      flex: 0 0 auto
    }
  }
</style>

<div class="storage-top">
  <div class="title-wrap">
    <h2>Data Storage Inspection</h2>
  </div>
  <form method="get" class="storage-filter">
    <a class="btn-action back" href="../../stocker.php">← Kembali</a>
    <input id="tanggal" type="date" name="tanggal" value="<?= htmlspecialchars($selectedDate) ?>">
    <button class="btn-action primary" type="submit">Tampilkan</button>
  </form>
  <div class="page-actions">
    <a class="btn-action primary" href="inputstorageinspection.php?tanggal=<?= urlencode($selectedDate) ?>">＋ Input Data</a>
  </div>
</div>

<div class="panel">
  <?php if (!$row): ?>
    <div class="empty-state">
      <strong>Belum ada data Storage Inspection</strong>
    </div>
  <?php else: ?>
    <section class="storage-record">
      <div class="storage-record-head">
        <div class="storage-record-title">
          <div class="storage-record-icon">📋</div>
          <div>
            <h3>Storage Inspection — <?= htmlspecialchars(date('d/m/Y', strtotime($row['tanggal']))) ?></h3>
            <div class="storage-record-meta">Dilaporkan: <strong><?= htmlspecialchars($row['dilaporkan_oleh'] ?? '-') ?></strong> · Disetujui: <strong><?= htmlspecialchars($row['disetujui_oleh'] ?? 'Alvin Zakaria') ?></strong></div>
          </div>
        </div>
        <div class="storage-record-actions">
          <a class="btn-action" href="inputstorageinspection.php?tanggal=<?= urlencode($selectedDate) ?>">✏️ Edit</a>
        </div>
      </div>

      <div class="storage-sub" style="padding-top:20px;">
        <h4>SUHU (°C)</h4>
        <div class="storage-table-wrap">
          <table class="storage-table">
            <thead>
              <tr>
                <th>Lokasi</th>
                <th>Suhu (°C)</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($locations as $loc): $v = $storage[$loc['key']] ?? []; ?>
                <tr>
                  <td class="label"><?= htmlspecialchars($loc['label']) ?></td>
                  <td><?= htmlspecialchars((string)($v['suhu'] ?? '-')) ?></td>
                </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>

      <div class="storage-sub">
        <h4>Pindah Barang Antar Toko</h4>
        <div class="storage-table-wrap">
          <table class="subtable">
            <thead>
              <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Tgl Penerimaan</th>
                <th>Tgl Pengiriman</th>
                <th>Resto Pengirim</th>
                <th>Jml Barang</th>
                <th>Kode Lot</th>
                <th>Nama &amp; TTD Pengirim</th>
              </tr>
            </thead>
            <tbody>
              <?php $hasTransfer = false;
              foreach (($transfers ?: []) as $i => $r): if (!array_filter($r)) continue;
                $hasTransfer = true; ?><tr>
                  <td><?= ($i + 1) ?></td>
                  <td><?= htmlspecialchars($r['nama_barang'] ?? '') ?></td>
                  <td><?= htmlspecialchars($r['tgl_penerimaan'] ?? '') ?></td>
                  <td><?= htmlspecialchars($r['tgl_pengiriman'] ?? '') ?></td>
                  <td><?= htmlspecialchars($r['resto_pengirim'] ?? '') ?></td>
                  <td><?= htmlspecialchars($r['jml_barang'] ?? '') ?></td>
                  <td><?= htmlspecialchars($r['kode_lot'] ?? '') ?></td>
                  <td><?= htmlspecialchars($r['nama_ttd_pengirim'] ?? '') ?></td>
                </tr><?php endforeach;
                    if (!$hasTransfer): ?><tr>
                  <td colspan="8" style="color:#64748b;">Belum ada data.</td>
                </tr><?php endif; ?></tbody>
          </table>
        </div>
      </div>

      <div class="storage-sub">
        <h4>Retur Barang</h4>
        <div class="storage-table-wrap">
          <table class="subtable">
            <thead>
              <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Tgl Penerimaan</th>
                <th>Tgl Pengiriman</th>
                <th>Jml Barang</th>
                <th>Kode Lot</th>
                <th>Nama &amp; TTD Pengirim</th>
              </tr>
            </thead>
            <tbody>
              <?php $hasReturn = false;
              foreach (($returns ?: []) as $i => $r): if (!array_filter($r)) continue;
                $hasReturn = true; ?><tr>
                  <td><?= ($i + 1) ?></td>
                  <td><?= htmlspecialchars($r['nama_barang'] ?? '') ?></td>
                  <td><?= htmlspecialchars($r['tgl_penerimaan'] ?? '') ?></td>
                  <td><?= htmlspecialchars($r['tgl_pengiriman'] ?? '') ?></td>
                  <td><?= htmlspecialchars($r['jml_barang'] ?? '') ?></td>
                  <td><?= htmlspecialchars($r['kode_lot'] ?? '') ?></td>
                  <td><?= htmlspecialchars($r['nama_ttd_pengirim'] ?? '') ?></td>
                </tr><?php endforeach;
                    if (!$hasReturn): ?><tr>
                  <td colspan="7" style="color:#64748b;">Belum ada data.</td>
                </tr><?php endif; ?></tbody>
          </table>
        </div>
      </div>

      <div class="storage-signature">
        <div class="sig-box">
          <div class="sig-title">DILAPORKAN OLEH</div>
          <div class="sig-name"><?= htmlspecialchars($row['dilaporkan_oleh'] ?? '-') ?></div>
        </div>
        <div class="sig-box">
          <div class="sig-title">DISETUJUI OLEH</div>
          <div class="sig-name">Alvin Zakaria</div>
        </div>
      </div>
    </section>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/../../includes/footer.php'; ?>