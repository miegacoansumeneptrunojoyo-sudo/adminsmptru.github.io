<?php
$pageTitle = 'Storage Inspection';
require __DIR__ . '/../../config/database.php';

$today = date('Y-m-d');
$selectedDate = trim((string)($_POST['tanggal'] ?? $_GET['tanggal'] ?? $today));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $selectedDate)) {
    $selectedDate = $today;
}

$locations = [
    ['key'=>'cold_storage','label'=>'COLD STORAGE','range'=>'-12 SAMPAI -25'],
    ['key'=>'freezer_1','label'=>'FREEZER 1','range'=>'-12 SAMPAI -25'],
    ['key'=>'freezer_2','label'=>'FREEZER 2','range'=>'-12 SAMPAI -25'],
    ['key'=>'freezer_3','label'=>'FREEZER 3','range'=>'-12 SAMPAI -25'],
    ['key'=>'chiller_1','label'=>'CHILLER 1','range'=>'-4 SAMPAI 4'],
    ['key'=>'chiller_2','label'=>'CHILLER 2','range'=>'-4 SAMPAI 4'],
    ['key'=>'chiller_3','label'=>'CHILLER 3','range'=>'-4 SAMPAI 4'],
    ['key'=>'chiller_4','label'=>'CHILLER 4','range'=>'-4 SAMPAI 4'],
];

$emptyTransfer = function(){ return [
    'nama_barang'=>'','tgl_penerimaan'=>'','tgl_pengiriman'=>'','resto_pengirim'=>'','jml_barang'=>'','kode_lot'=>'','nama_ttd_pengirim'=>''
]; };
$emptyReturn = function(){ return [
    'nama_barang'=>'','tgl_penerimaan'=>'','tgl_pengiriman'=>'','jml_barang'=>'','kode_lot'=>'','nama_ttd_pengirim'=>''
]; };

$storage = [];
foreach ($locations as $loc) {
    $storage[$loc['key']] = ['suhu'=>''];
}
$transfers = [];
for ($i=0;$i<5;$i++) $transfers[] = $emptyTransfer();
$returns = [];
for ($i=0;$i<5;$i++) $returns[] = $emptyReturn();
$header = ['dilaporkan_oleh'=>'','disetujui_oleh'=>'Alvin Zakaria'];
$errors = [];
$success = false;

// Load existing record to allow update by date.
if (db_ready()) {
    $stmt = $conn->prepare("SELECT * FROM storage_inspections WHERE tanggal=? LIMIT 1");
    if ($stmt) {
        $stmt->bind_param('s', $selectedDate);
        if ($stmt->execute()) {
            $res = $stmt->get_result();
            if ($row = $res->fetch_assoc()) {
                $decodedStorage = json_decode((string)$row['storage_data'], true);
                $decodedTransfers = json_decode((string)$row['pindah_data'], true);
                $decodedReturns = json_decode((string)$row['retur_data'], true);
                if (is_array($decodedStorage)) {
                    foreach ($locations as $loc) {
                        if (isset($decodedStorage[$loc['key']]) && is_array($decodedStorage[$loc['key']])) {
                            $storage[$loc['key']]['suhu'] = (string)($decodedStorage[$loc['key']]['suhu'] ?? '');
                        }
                    }
                }
                if (is_array($decodedTransfers)) {
                    $transfers = array_values(array_slice(array_merge($transfers, $decodedTransfers), 0, 5));
                }
                if (is_array($decodedReturns)) {
                    $returns = array_values(array_slice(array_merge($returns, $decodedReturns), 0, 5));
                }
                $header['dilaporkan_oleh'] = (string)($row['dilaporkan_oleh'] ?? '');
                $header['disetujui_oleh'] = 'Alvin Zakaria';
            }
        }
        $stmt->close();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tanggal = $selectedDate;
    $header['dilaporkan_oleh'] = trim((string)($_POST['dilaporkan_oleh'] ?? ''));
    $header['disetujui_oleh'] = 'Alvin Zakaria';

    foreach ($locations as $loc) {
        $storage[$loc['key']]['suhu'] = trim((string)($_POST['storage'][$loc['key']]['suhu'] ?? ''));
    }

    $transfers = [];
    for ($i=0;$i<5;$i++) {
        $transfers[] = [
            'nama_barang'=>trim((string)($_POST['transfer'][$i]['nama_barang'] ?? '')),
            'tgl_penerimaan'=>trim((string)($_POST['transfer'][$i]['tgl_penerimaan'] ?? '')),
            'tgl_pengiriman'=>trim((string)($_POST['transfer'][$i]['tgl_pengiriman'] ?? '')),
            'resto_pengirim'=>trim((string)($_POST['transfer'][$i]['resto_pengirim'] ?? '')),
            'jml_barang'=>trim((string)($_POST['transfer'][$i]['jml_barang'] ?? '')),
            'kode_lot'=>trim((string)($_POST['transfer'][$i]['kode_lot'] ?? '')),
            'nama_ttd_pengirim'=>trim((string)($_POST['transfer'][$i]['nama_ttd_pengirim'] ?? '')),
        ];
    }

    $returns = [];
    for ($i=0;$i<5;$i++) {
        $returns[] = [
            'nama_barang'=>trim((string)($_POST['return'][$i]['nama_barang'] ?? '')),
            'tgl_penerimaan'=>trim((string)($_POST['return'][$i]['tgl_penerimaan'] ?? '')),
            'tgl_pengiriman'=>trim((string)($_POST['return'][$i]['tgl_pengiriman'] ?? '')),
            'jml_barang'=>trim((string)($_POST['return'][$i]['jml_barang'] ?? '')),
            'kode_lot'=>trim((string)($_POST['return'][$i]['kode_lot'] ?? '')),
            'nama_ttd_pengirim'=>trim((string)($_POST['return'][$i]['nama_ttd_pengirim'] ?? '')),
        ];
    }

    if ($header['dilaporkan_oleh'] === '') {
        $errors[] = 'Dilaporkan Oleh wajib dipilih.';
    }
    if (!$errors && !db_ready()) {
        $errors[] = 'Database belum terhubung: ' . db_error_message();
    }

    if (!$errors) {
        $storageJson = json_encode($storage, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        $transferJson = json_encode($transfers, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
        $returnJson = json_encode($returns, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);

        $sql = "INSERT INTO storage_inspections (tanggal,dilaporkan_oleh,disetujui_oleh,storage_data,pindah_data,retur_data)
                VALUES (?,?,?,?,?,?)
                ON DUPLICATE KEY UPDATE
                dilaporkan_oleh=VALUES(dilaporkan_oleh),
                disetujui_oleh=VALUES(disetujui_oleh),
                storage_data=VALUES(storage_data),
                pindah_data=VALUES(pindah_data),
                retur_data=VALUES(retur_data),
                updated_at=CURRENT_TIMESTAMP";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            $errors[] = 'Gagal menyiapkan penyimpanan data: ' . $conn->error;
        } else {
            $stmt->bind_param('ssssss', $tanggal, $header['dilaporkan_oleh'], $header['disetujui_oleh'], $storageJson, $transferJson, $returnJson);
            if ($stmt->execute()) {
                $success = true;
            } else {
                $errors[] = 'Gagal menyimpan data: ' . $stmt->error;
            }
            $stmt->close();
        }
    }
}

require __DIR__ . '/../../includes/header.php';
?>
<style>
.storage-card{background:#fff;border:1px solid #e5ebf5;border-radius:22px;padding:22px;box-shadow:0 8px 30px rgba(36,67,109,.08)}
.storage-section{margin-top:18px;border:1px solid #dfe8f3;border-radius:18px;overflow:hidden;background:#fff}
.storage-section-title{padding:14px 16px;background:#f5f9ff;border-bottom:1px solid #dfe8f3;font-weight:900;color:#123f78;text-transform:uppercase;letter-spacing:.3px}
.storage-subtitle{text-align:center;padding:10px 12px;background:#fff;font-weight:900;color:#123f78}
.storage-table-wrap{overflow-x:auto}
.storage-table{width:100%;min-width:980px;border-collapse:collapse}
.storage-table th,.storage-table td{border:1px solid #d9e2ec;padding:10px;text-align:center;vertical-align:middle}
.storage-table th{background:#f5f8fd;color:#143d76;font-weight:900;font-size:12px}
.storage-table .range{background:#fbfcfe;color:#4c607b;font-size:11px;font-weight:800}
.storage-table input,.storage-table select{width:100%;height:40px;border:1px solid #cfdceb;border-radius:10px;background:#fff;padding:0 10px;color:#173c6e;outline:none}
.storage-table input:focus,.storage-table select:focus{border-color:#1d7bea;box-shadow:0 0 0 3px rgba(29,123,234,.1)}
.storage-subgrid{display:grid;grid-template-columns:repeat(8,minmax(120px,1fr));gap:10px;padding:14px}
.storage-box{border:1px solid #dbe5f1;border-radius:14px;background:#fbfdff;padding:12px}
.storage-box h4{margin:0 0 8px;color:#153d76;font-size:12px}
.storage-box .range-text{font-size:11px;color:#6e7f95;margin-bottom:8px}
.storage-box label{display:flex;flex-direction:column;gap:5px;font-size:11px;font-weight:800;color:#5b6c82;margin-top:8px}
.storage-box input,.storage-box select{height:38px;border:1px solid #cfdceb;border-radius:10px;padding:0 10px;background:#fff}
.small-help{padding:0 16px 12px;color:#72829b;font-size:11px}
.data-table-wrap{overflow-x:auto}
.data-table{width:100%;min-width:980px;border-collapse:collapse}
.data-table th,.data-table td{border:1px solid #dce5ee;padding:8px}
.data-table th{background:#f4f8fd;color:#123f78;font-size:12px;text-transform:uppercase}
.data-table td input{width:100%;height:38px;border:1px solid #cfdceb;border-radius:9px;padding:0 9px;outline:none}
.signature-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:18px}
.signature-card{border:1px solid #d9e2ec;border-radius:14px;overflow:hidden}
.signature-card .sig-head{display:grid;grid-template-columns:1fr 1fr;background:#f4f7fb;font-weight:900;color:#143d76;font-size:12px;text-align:center}
.signature-card .sig-head div{padding:10px;border-right:1px solid #d9e2ec}.signature-card .sig-head div:last-child{border-right:0}
.signature-card .sig-body{display:grid;grid-template-columns:1fr 1fr;min-height:120px}.signature-card .sig-body>div{padding:12px;border-right:1px solid #d9e2ec}.signature-card .sig-body>div:last-child{border-right:0}
.signature-card label{font-size:11px;font-weight:800;color:#60728a;display:block;margin-top:78px}.signature-card select,.signature-card input{width:100%;height:38px;margin-top:6px;border:1px solid #cfdceb;border-radius:9px;padding:0 10px}.signature-card .sig-value{min-height:120px;display:flex;align-items:flex-end;justify-content:center;padding:12px 10px 14px;font-weight:900;color:#173d76;border-right:1px solid #d9e2ec}.signature-card .sig-body>div:last-child{border-right:0}
.form-top{display:grid;grid-template-columns:220px 1fr 1fr;gap:16px;margin-bottom:18px}.form-top label{display:flex;flex-direction:column;gap:7px;font-weight:800;color:#173d76;font-size:13px}.form-top input,.form-top select{height:45px;border:1px solid #d2deec;border-radius:12px;padding:0 13px;background:#fbfdff;outline:none}.form-top input:focus,.form-top select:focus{border-color:#1f7ced;box-shadow:0 0 0 3px rgba(31,124,237,.1)}.auto-date{background:#f6faff!important;font-weight:800;color:#173d76}.storage-actions{display:flex;justify-content:flex-end;gap:10px;margin-top:20px;padding-top:18px;border-top:1px solid #e7edf5}.btn-action{border:1px solid #d7e2ef;border-radius:12px;padding:11px 16px;font-weight:800;background:#fff;color:#173d76;display:inline-flex;align-items:center;justify-content:center}.btn-action.primary{background:linear-gradient(120deg,#1678ed,#f2499a);border-color:transparent;color:#fff}.note-box{margin-top:14px;background:#f5f9ff;border:1px solid #dce9f7;border-radius:12px;padding:11px 13px;color:#526984;font-size:12px}
@media(max-width:1000px){.storage-subgrid{grid-template-columns:repeat(4,minmax(150px,1fr))}.form-top{grid-template-columns:1fr 1fr}.form-top label:first-child{grid-column:1/-1}.signature-grid{grid-template-columns:1fr}}
@media(max-width:800px){.form-top{grid-template-columns:1fr}.form-top label:first-child{grid-column:auto}.storage-card{padding:14px}.storage-subgrid{grid-template-columns:1fr 1fr;padding:10px}.storage-table{min-width:0}.storage-table thead{display:none}.storage-table,.storage-table tbody,.storage-table tr,.storage-table td{display:block;width:100%}.storage-table tr{padding:10px;border-bottom:1px solid #dfe7f0}.storage-table td{border:0;border-bottom:1px dashed #e2e8f0;text-align:left}.storage-table td:last-child{border-bottom:0}.storage-table td::before{content:attr(data-label);display:block;font-size:11px;font-weight:900;color:#5e718a;margin-bottom:5px}.storage-section-title{font-size:14px}.data-table{min-width:1000px}.signature-grid{grid-template-columns:1fr}.storage-actions{position:sticky;bottom:68px;background:#ffffffee;backdrop-filter:blur(8px);z-index:5;padding-bottom:10px}.storage-actions .btn-action{flex:1}}
</style>

<div class="page-head">
  <div><h2>Input Storage Inspection</h2></div>
  <div class="page-actions"><a class="btn-action back" href="datastorageinspection.php">← Kembali</a></div>
</div>

<?php if ($success): ?><div class="alert success">Storage Inspection berhasil disimpan.</div><?php endif; ?>
<?php if ($errors): ?><div class="alert danger"><ul><?php foreach($errors as $e): ?><li><?=htmlspecialchars($e)?></li><?php endforeach; ?></ul></div><?php endif; ?>

<div class="storage-card">
  <div class="storage-section-title" style="margin:-22px -22px 18px;">STORAGE INSPECTION</div>

  <form method="post">
    <div class="form-top">
      <label>Tanggal
        <input class="auto-date" type="date" name="tanggal" value="<?=htmlspecialchars($selectedDate)?>" readonly>
      </label>
      <label>Dilaporkan Oleh
        <select name="dilaporkan_oleh" id="dilaporkan_oleh" required>
          <option value="">Pilih Nama Stocker</option>
          <option value="Arjuna" <?=($header['dilaporkan_oleh']==='Arjuna'?'selected':'')?>>Arjuna</option>
          <option value="Kafi" <?=($header['dilaporkan_oleh']==='Kafi'?'selected':'')?>>Kafi</option>
        </select>
      </label>
      <label>Disetujui Oleh
        <input type="text" value="Alvin Zakaria" readonly>
      </label>
    </div>

    <div class="storage-section">
      <div class="storage-section-title">SUHU (°C)</div>
      <div class="storage-table-wrap">
        <table class="storage-table">
          <thead>
            <tr>
              <?php foreach($locations as $loc): ?><th><?=htmlspecialchars($loc['label'])?></th><?php endforeach; ?>
            </tr>
            <tr class="range">
              <?php foreach($locations as $loc): ?><th><?=htmlspecialchars($loc['range'])?></th><?php endforeach; ?>
            </tr>
          </thead>
          <tbody>
            <tr>
            <?php foreach($locations as $loc): ?>
              <td data-label="<?=htmlspecialchars($loc['label'])?>">
                <div style="display:grid;gap:8px;">
                  <label style="font-size:11px;font-weight:800;color:#64748b;">Suhu (°C)
                    <input type="text" inputmode="decimal" name="storage[<?=$loc['key']?>][suhu]" value="<?=htmlspecialchars($storage[$loc['key']]['suhu'])?>" placeholder="Masukkan suhu">
                  </label>
                </div>
              </td>
            <?php endforeach; ?>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <div class="storage-section">
      <div class="storage-section-title" style="text-align:center;">PINDAH BARANG ANTAR TOKO</div>
      <div class="data-table-wrap">
        <table class="data-table">
          <thead><tr>
            <th>NO</th><th>NAMA BARANG</th><th>TGL PENERIMAAN</th><th>TGL PENGIRIMAN</th><th>RESTO PENGIRIM</th><th>JML BARANG</th><th>KODE LOT</th><th>NAMA DAN TTD PENGIRIM</th>
          </tr></thead>
          <tbody>
          <?php for($i=0;$i<5;$i++): $r=$transfers[$i]; ?>
            <tr>
              <td><?=($i+1)?></td>
              <td><input type="text" name="transfer[<?=$i?>][nama_barang]" value="<?=htmlspecialchars($r['nama_barang'])?>"></td>
              <td><input type="date" name="transfer[<?=$i?>][tgl_penerimaan]" value="<?=htmlspecialchars($r['tgl_penerimaan'])?>"></td>
              <td><input type="date" name="transfer[<?=$i?>][tgl_pengiriman]" value="<?=htmlspecialchars($r['tgl_pengiriman'])?>"></td>
              <td><input type="text" name="transfer[<?=$i?>][resto_pengirim]" value="<?=htmlspecialchars($r['resto_pengirim'])?>"></td>
              <td><input type="text" name="transfer[<?=$i?>][jml_barang]" value="<?=htmlspecialchars($r['jml_barang'])?>"></td>
              <td><input type="text" name="transfer[<?=$i?>][kode_lot]" value="<?=htmlspecialchars($r['kode_lot'])?>"></td>
              <td><input type="text" name="transfer[<?=$i?>][nama_ttd_pengirim]" value="<?=htmlspecialchars($r['nama_ttd_pengirim'])?>"></td>
            </tr>
          <?php endfor; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="storage-section">
      <div class="storage-section-title" style="text-align:center;">RETUR BARANG</div>
      <div class="data-table-wrap">
        <table class="data-table">
          <thead><tr>
            <th>NO</th><th>NAMA BARANG</th><th>TGL PENERIMAAN</th><th>TGL PENGIRIMAN</th><th>JML BARANG</th><th>KODE LOT</th><th>NAMA DAN TTD PENGIRIM</th>
          </tr></thead>
          <tbody>
          <?php for($i=0;$i<5;$i++): $r=$returns[$i]; ?>
            <tr>
              <td><?=($i+1)?></td>
              <td><input type="text" name="return[<?=$i?>][nama_barang]" value="<?=htmlspecialchars($r['nama_barang'])?>"></td>
              <td><input type="date" name="return[<?=$i?>][tgl_penerimaan]" value="<?=htmlspecialchars($r['tgl_penerimaan'])?>"></td>
              <td><input type="date" name="return[<?=$i?>][tgl_pengiriman]" value="<?=htmlspecialchars($r['tgl_pengiriman'])?>"></td>
              <td><input type="text" name="return[<?=$i?>][jml_barang]" value="<?=htmlspecialchars($r['jml_barang'])?>"></td>
              <td><input type="text" name="return[<?=$i?>][kode_lot]" value="<?=htmlspecialchars($r['kode_lot'])?>"></td>
              <td><input type="text" name="return[<?=$i?>][nama_ttd_pengirim]" value="<?=htmlspecialchars($r['nama_ttd_pengirim'])?>"></td>
            </tr>
          <?php endfor; ?>
          </tbody>
        </table>
      </div>
    </div>

    <div class="signature-grid">
      <div class="signature-card">
        <div class="sig-head"><div>DILAPORKAN OLEH</div><div>DISETUJUI OLEH</div></div>
        <div class="sig-body">
          <div class="sig-value" id="signatureReported"><?=htmlspecialchars($header['dilaporkan_oleh'] ?: '—')?></div>
          <div class="sig-value">Alvin Zakaria</div>
        </div>
      </div>
    </div>

    <div class="storage-actions">
      <a class="btn-action" href="datastorageinspection.php">Reset</a>
      <button class="btn-action primary" type="submit">Simpan Data</button>
    </div>
  </form>
</div>

<script>
(function(){
  const select = document.getElementById('dilaporkan_oleh');
  const target = document.getElementById('signatureReported');
  if(!select || !target) return;
  const syncReported = () => { target.textContent = select.value || '—'; };
  select.addEventListener('change', syncReported);
  syncReported();
})();
</script>

<?php require __DIR__ . '/../../includes/footer.php'; ?>
